%DISPUSERINIT   DISPUSERINIT displays all users indicating the different bit rates
%               by different colors and markers.
%
%Inputs:  (global) mobilestation, basestation, numBSs, numMSs, xPos, yPos,
%         xmin, xmax, ymin, ymax, resolution
%Outputs:
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   eval(['tmpInd = numBStype' num2str(layer) ';']);
   tmpInd = find([mobilestationOri.usedCarr] == layer);
   totalUsers = length(tmpInd);
   tmpMSs = [mobilestationOri(tmpInd)];
   
   colors = 'gbrgbrgbr';
   marker = '...***ooo';
   ii = 1;
   figure;
   set(gcf, 'Tag', 'tagUserFig');
   hold on
   bitRates = unique([[mobilestationOri.RUL] [mobilestationOri.RDL]]);
   if length(bitRates) > 9
      bitRates = bitRates(1:9);
   end
   numOut = [];
   userDelta = 0;
   lBitRates = [];
   for tmpRate = bitRates
      ind1 = find([tmpMSs.RUL] == tmpRate);
      plot([tmpMSs(ind1).x], [tmpMSs(ind1).y], [marker(ii) colors(ii)]);
      ii = ii+1;
      if ~isempty(ind1)
         lBitRates = [lBitRates; tmpRate];
         numOut = [numOut; length(ind1)];
         userDelta = userDelta+length(ind1);
      end
   end
   
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end   
   end
   titleText = ['USER DISTRIBUTION' layerString ' (all) (total = ' num2str(totalUsers), ' users)'];
   title(['\it{', titleText, '}']);
   axis('equal');
   BSplot(basestation, gcf, vectMap, lossData);
   hLegend = legend(strcat(num2str(lBitRates(:)/1000), ' kBit/s (', num2str(numOut(:)), ')'));
   set(hLegend, 'color', [1 1 1]);
end

clear tmpMSs ind1 ii userDelta totalUsers colors marker tmpRate layerString layer numOut lBitRates bitRates tmpInd
clear outageReason outageText titleText hLegend
