%DISPTRAFFIC   DISPTRAFFIC displays the 'sum of the datarates' map. i. e. the total bits
%              in every pixels as well as the average data rate per cell with the 
%              best server in UL. If 'combined' is 0 plots go to different figures 
%              (default), else they are all in one figure.
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Heiska (KHe),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m CalcThroughput.m

%%%%%%%%%%% total bits per pixel for operator 1%%%%%%%%%%%
if (~exist('combined'))
   combined = 0;
end

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   user1 = squeeze(user(layer, :, :));
   datarate1 = squeeze(datarate(layer, :, :));
   totalTraf = user1.*datarate1/1000;
   totalTraf(~isnan(waterArea)) = NaN;
   eval(['indBStypeX = indBStype' num2str(layer) ';']);
   
   curFig = figure;
   if combined
      set(curFig, 'Position', [1 30 990 700]);
      subplot(221);
   end
   colors = jet(64);
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          totalTraf);
   caxis([0 64]);
   colors(1, :) = [1 1 1];
   colormap(colors);
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   
   titleText = ['UL Traffic dist.' layerString  ' - ', num2str(sum(sum(user1))), ' users'];
   title(['\it{', titleText, '}']);
   axis('equal');
   shading('flat');
   hcb = colorbar('vert');
   set(get(hcb, 'Title'), 'String', 'kbits/s/pixel');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' kbits/s'));
   BSplot(basestation, gcf, vectMap, lossData); 
   drawnow;
   clear totalTraf colors titleText k l hcb
   
   aveBitRate = zeros(yPixels, xPixels);
   
   for k = 1:yPixels
      for l = 1:xPixels
         if (bestServer(layer, k, l))
            aveBitRate(k, l) = perf(squeeze(bestServer(layer, k, l))).RUL/1000;
         end
      end
   end
   
   %%%%%%%%%% average data rate %%%%%%%%%%%
   aveBitRate(~isnan(waterArea)) = NaN;
   
   maxi = max([perf(indBStypeX).RUL]);
   maxi = 11*round(maxi/10)/1000;
   
   if combined
      subplot(222)
   else
      figure;
   end
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          aveBitRate)
   caxis([0 maxi]);
   colors = jet(64);
   colors(1, :) = [1 1 1];
   colormap(colors);
   hcb = colorbar('vert');
   axis('equal');
   title(['\it{Average data rate per cell' layerString '}']);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'Ave. data rate');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' kbits/s'));
   BSplot(basestation, gcf, vectMap, lossData);
   drawnow;
   clear totalTraf colors titleText k l hcb maxi
   
   %%%%%%%%%%  throughput  %%%%%%%%%%%
   CalcThroughput;
   
   %%%%%%%%%% create map and scale %%%%%%%%%%%
   tpUL = zeros(yPixels, xPixels);
   tpDL = zeros(yPixels, xPixels);
   tpUL1 = zeros(yPixels, xPixels);
   tpDL1 = zeros(yPixels, xPixels);
   
   for k = 1:yPixels
      for l = 1:xPixels
         if (bestServer(layer, k, l))
            tpUL(k, l) = perf(squeeze(bestServer(layer, k, l))).throughputUL/1000;
            tpDL(k, l) = perf(squeeze(bestServDL(layer, k, l))).throughputDL/1000;
         end
      end
   end
   
   tpUL(~isnan(waterArea)) = NaN;
   tpDL(~isnan(waterArea)) = NaN;
   
   maxUL = max([perf(indBStypeX).RUL].*[perf(indBStypeX).mUL]);
   maxDL = max([perf(indBStypeX).RDL].*[perf(indBStypeX).mDL]);
   
   maxi = max(maxUL, maxDL);
   maxi = 10*round(maxi/10)/1000;
   
   %%%%%%%%%% display throughputUL %%%%%%%%%%%
   if combined
      subplot(223)
   else
      figure
   end
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          tpUL)
   caxis([0 maxi]);
   colors = jet(64);
   colors(1, :) = [1 1 1];
   colormap(colors);
   hcb = colorbar('vert');
   axis('equal');
   title(['\it{Throughput in UL per cell' layerString '}']);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'ThroughputUL');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' kbits/s'));
   BSplot(basestation, gcf, vectMap, lossData);
   drawnow
   
   %%%%%%%%%% display throughputDL %%%%%%%%%%%
   if combined
      subplot(224)
   else
      figure
   end
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          tpDL)
   caxis([0 maxi]);
   colors = jet(64);
   colors(1, :) = [1 1 1];
   colormap(colors);
   hcb = colorbar('vert');
   axis('equal');
   title(['\it{Throughput in DL per cell' layerString '}']);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'ThroughputDL');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' kbits/s'));
   BSplot(basestation, gcf, vectMap, lossData);
end

clear aveBitRate colors1 totalTraf userColors colors titleText k l tpUL tpDL
clear maxUL maxDL maxi user1 datarate1 layer combined
