%CalcMsTxPowRaise   txPowerRaise = CalcMsTxPowRaise(lpTables, speeds)  returns the single
%                   link average power raise caused by power control following multipath
%                   fading. This is only used in interference calculations when calculating
%                   Ioth. The MS speed is used as input and also the tables from where the
%                   power raise is interpolated.
%
%Inputs:
%   lPTables  : linkPerfTables for a channel, see e.g. pedALinkPerfTables.m	
%   speeds    : the speeds at which the headrooms are calculated.
%Outputs:
%   txPowRaise: The average power raise in the single link case  because of PC in dB
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function txPowRaise = CalcMsTxPowRaise(lPTables, speeds);

tabspeed      = lPTables.speeds;
tabpowerraise = lPTables.AvPRUL;

txPowRaise = zeros(size(speeds));
m1 = length(lPTables.speeds);
bits1 = speeds < tabspeed(1);
bits2 = speeds > tabspeed(m1);
bits3 = ~(bits1 | bits2);
if (sum(bits1) > 0)
	txPowRaise(bits1) = tabpowerraise(1);
end

if (sum(bits2) > 0)
	txPowRaise(bits2) = tabpowerraise(m1);
end

if (sum(bits3) > 0)
    txPowRaise(bits3) = interp1(tabspeed, tabpowerraise, speeds(bits3));
end
