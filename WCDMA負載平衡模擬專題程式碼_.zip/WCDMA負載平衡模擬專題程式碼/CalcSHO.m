%CALCSHO  CALCSHO calculates a matrix holding all the SHO connections. From this
%         the soft handoff overhead factor SHO
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

rxLevels1 = zeros(numBSs, numMSs);       %including the connection to the "own" cell
rxLevels2 = zeros(numBSs, numMSs);       %excluding the connection to the "own" cell

% find all the BSs to which all the mobiles are in SHO
for runType = 1:2
   eval(['indMStypeX = indMStype' num2str(runType) ';']);
   eval(['indBStypeX = indBStype' num2str(runType) ';']);
   if ~isempty(indBStypeX) & ~isempty(indMStypeX)
      tmpind = indMStypeX(find([mobilestation(indMStypeX).usedCarr]==runType));
      if ~isempty(tmpind)
         rxLevels = CPICHStrengthM(indBStypeX, tmpind);
         [maxLevel maxLevelIndex] = max(rxLevels, [], 1);
         bestServDLV(tmpind) = indBStypeX(maxLevelIndex);
         %set rxLevels1 to zero where there is no connection
         rxLevels(rxLevels<(ones([length(indBStypeX), 1])*(maxLevel+[basestation(bestServDLV(tmpind)).WINDOW_ADD]))) = 0;
         rxLevels1(indBStypeX, tmpind) = rxLevels;
         %set rxLevels2 to zero where there is no SHO connection, i.e. set also best server connections' rxLevels to zero
         rxLevels([0:length(tmpind)-1]*length(indBStypeX)+maxLevelIndex) = 0;
         rxLevels2(indBStypeX, tmpind) = rxLevels;
      end
   end
end

%find number of all SHO connections to each basestation
SHOtemp1 = sum(rxLevels1~=0, 2);
%find number of SHO only connenctions
SHOtemp2 = sum(rxLevels2~=0, 2);

numUserDL = SHOtemp1-SHOtemp2;
apu = num2cell(numUserDL);
[perf.mDL] = deal(apu{:});

%calculate SH0 factor and distribute to performance structure
%if no user is in a cell set SHO to zero
apu = zeros(1, numBSs);
ind = find([perf.mDL]~=0);
apu(ind) = SHOtemp1(ind)./[perf(ind).mDL]'-1;

apu1 = num2cell(apu);
[perf.SHO] = deal(apu1{:});

clear apu apu1 ind numUserDL SHOtemp1 SHOtemp2 rxLevels rxLevels2
