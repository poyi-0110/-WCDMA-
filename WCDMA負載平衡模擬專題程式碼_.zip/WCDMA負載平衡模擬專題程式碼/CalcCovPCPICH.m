%CALCCOVPCPICH   CALCCOVPCPICH calculates the coverage probability for common pilot channel CPICH
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

clear previousPolygonFlag tmpSeparateAnalysis ;

if (~exist('tmpEcIoThreshold'))
   tmpEcIoThreshold = CPICHEcIoThreshold;
end

if (~exist('tmpCovTarget'))
   tmpCovTarget = 95;
end

tmpLayerVector = [];

if numBStype1
   tmpLayerVector = [tmpLayerVector, 1];
end

if numBStype2
   tmpLayerVector = [tmpLayerVector, 2];
end

tmpNumLayers = length(tmpLayerVector);

if (mode == 1 & tmpNumLayers == 2)
   answer = questdlg(['Separate analysis for the ', num2str(tmpNumLayers), ' layers?'], ' ', 'Yes', 'No', 'Yes');
   tmpSeparateAnalysis = strcmp(answer, 'Yes');
else
   tmpSeparateAnalysis = 1;
end

if tmpNumLayers > 1
   if mode == 1
      layerStr = ' of Carrier ';
   else
      layerStr = ' of Operator ';
   end
else
   layerStr = '';
end

CPICHPowervec = log2lin([basestation.CPICHPower]);

for layer = tmpLayerVector
   CPICHEcIo = zeros(yPixels, xPixels);
   IownPDL   = zeros(yPixels, xPixels);
   ItotPDL1  = zeros(yPixels, xPixels);
   
   bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2)+ ...
      log2lin([basestation.CPICHPower]')+log2lin([basestation.commonChannelOther]');
   
   bestServDL1 = squeeze(bestServDL(layer, :, :));
      
   % Calculation of CPICH Ec/Io
   if layer == 1
      if (numBStype2)               
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1)+...
            log2lin(-acFilterDL(channelOffset))*sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      else 
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1));
      end
   else      
      if (numBStype1)              
         ItotPDL1 = squeeze(log2lin(-acFilterDL(channelOffset))*sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1)+...
            sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      else
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      end
   end      
      
   [hlpx, hlpy] = meshgrid([1:xPixels], [1:yPixels]);
   bestServInd_3D = (hlpx-1)*numBSs*yPixels+(hlpy-1)*numBSs+bestServDL1;
   
   % NOTE orthogonality is calculated here for wideAreaCovSpeed.
   orthFactormat = zeros(yPixels, xPixels);
   for i1 = 1:numChannels
      ind1 = find(channelMap(layer, :)==channels(i1));
      if (length(ind1) >= 1)   
         orthFactormat(ind1) = CalcOrthogonality(linkPerf(channels(i1)), wideAreaCovSpeed);
      end
   end
   
   CPICHPowermat = CPICHPowervec(bestServDL1);
   
   %Wideband interference:
   ItotPDL1 = ItotPDL1+MS_noise_power_lin;
   
   CPICHEcIo = CPICHPowermat./log2lin(linklossDL(bestServInd_3D))./ItotPDL1;
   CPICHEcIo = lin2log(CPICHEcIo);
   
   clear hlpx hlpy bestServInd_3D orthFactormat CPICHPowermat
   
   if ~tmpSeparateAnalysis
      if layer == 1
	      CPICHEcIo1 = CPICHEcIo;
      else
         CPICHEcIo2 = CPICHEcIo;
      end
   else
      lowerLimit = -25;
      upperLimit = 0;
      
      if layer == 1
         [tmphcf, tmphcb] = DispGenericCov(CPICHEcIo, tmpEcIoThreshold, 'CPICH E_c/I_0', ...
                                           mode, layer, lossData, basestation, vectMap, ...
                                           waterArea, resolution, xmin, ymin, xmax, ymax, ...
                                           numBStype2, lowerLimit, upperLimit);
      else
         [tmphcf, tmphcb] = DispGenericCov(CPICHEcIo, tmpEcIoThreshold, 'CPICH E_c/I_0', ...
                                           mode, layer, lossData, basestation, vectMap, ...
                                           waterArea, resolution, xmin, ymin, xmax, ymax, ...
                                           numBStype1, lowerLimit, upperLimit);
      end
      
      [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
      
      if (totA <= 0)
         disp('Warning: Zero area CPICH coverage probability calculation.');
         CPICHEcIoCovP = 1;
         clear CPICHEcIo ItotPDL1 IothPDL;
         clear totA inplgn plgn;
         return
      end
      
      isNotCovered = inplgn.*(CPICHEcIo < tmpEcIoThreshold);
      CPICHEcIoCovP = 1-sum(sum(isNotCovered))/totA;
      
      figure(tmphcf);
      
      xlabel(['CPICH E_c/I_0 threshold: ', num2str(tmpEcIoThreshold), ' dB    ', ...
              'CPICH E_c/I_0 coverage: ', num2str(fix(10000*CPICHEcIoCovP)/100), ' %']);
      hold on
      plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 1.5);
      hold off
      
      tmpCovVector = CPICHEcIo(find(inplgn(:)));
      tmpT = (1:length(tmpCovVector))/length(tmpCovVector);
      tmpCovVector = sort(tmpCovVector);
      [tmpClosest, tmpClosestInd] = min(abs(tmpT-(1-tmpCovTarget/100)));
      tmpCorrection = tmpEcIoThreshold-tmpCovVector(tmpClosestInd);
      layerNum = '';
      if tmpNumLayers > 1
         layerNum = num2str(layer);
      end
      if tmpCorrection >= 0
         disp(['CPICH powers', layerStr, layerNum, ' should be increased approx. by ', num2str(tmpCorrection), ' dBs to achieve the target cov. P.']); 
      else
         disp(['CPICH powers', layerStr, layerNum, ' should be decreased approx. by ', num2str(-tmpCorrection), ' dBs to achieve the target cov. P.']); 
      end
      
      figure;
      plot(tmpCovVector, tmpT);
      grid;
      hold on;
      tmpA = axis;
      tmpA(1) = max(-30, tmpA(1));
      axis(tmpA);
      tmpH1 = plot([tmpA(1) tmpCovVector(tmpClosestInd) tmpCovVector(tmpClosestInd)], ...
                   [1-tmpCovTarget/100 1-tmpCovTarget/100 tmpA(3)], 'r-');
      tmpH2 = plot([tmpA(1) tmpEcIoThreshold tmpEcIoThreshold], [1-CPICHEcIoCovP 1-CPICHEcIoCovP tmpA(3)], 'g-');
      legend([tmpH1; tmpH2], ['CPICH E_c/I_0 at target cov. P (' num2str(tmpCovTarget) '%)'], ...
                             ['CPICH cov. P at CPICH cov. threshold (' num2str(tmpEcIoThreshold) ' dB)'], 2);
      tmpH3 = text(0.5+tmpCovVector(tmpClosestInd), (1-tmpCovTarget/100)/2, [num2str(round(100*(tmpCovVector(tmpClosestInd)))/100) ' dB']);
      set(tmpH3, 'Color', 'r');
      tmpH4 = text(tmpA(1), 1-CPICHEcIoCovP, num2str(round(1000*(1-CPICHEcIoCovP))/1000));
      set(tmpH4, 'Color', 'g', 'horizontalAlignment', 'right');

      xlabel('CPICH E_c/I_0 (dB)');
      ylabel('P(CPICH E_c/I_0 < abscissa)')
      title(['CDF of CPICH E_c/I_0 ', layerStr, layerNum]);
      hold off
      
      clear CPICHEcIo ItotPDL1 isNotCovered xx1 yy1 ind11
      clear totA inplgn plgn answer
      clear orthFactorvec orthFactormat CPICHPowermat
   end
end

if ~tmpSeparateAnalysis
   layer = 0;
   CPICHEcIo = max(CPICHEcIo1, CPICHEcIo2);
   clear CPICHEcIo1 CPICHEcIo2
   lowerLimit = -25;
   upperLimit = 0;
   [tmphcf, tmphcb] = DispGenericCov(CPICHEcIo, tmpEcIoThreshold, 'CPICH E_c/I_0', ...
                                     mode, layer, lossData, basestation, vectMap, ...
                                     waterArea, resolution, xmin, ymin, xmax, ymax, ...
                                     numBStype2, lowerLimit, upperLimit);
      
   [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
      
   if (totA <= 0)
      disp('Warning: Zero area CPICH coverage probability calculation.');
      CPICHEcIoCovP = 1;
      clear CPICHEcIo ItotPDL1 IothPDL;
      clear totA inplgn plgn;
      return
   end
   
   isNotCovered = inplgn.*(CPICHEcIo < tmpEcIoThreshold);
   CPICHEcIoCovP = 1-sum(sum(isNotCovered))/totA;
   
   figure(tmphcf);
   
   xlabel(['CPICH E_c/I_0 threshold: ', num2str(tmpEcIoThreshold), ' dB    ', ...
           'CPICH E_c/I_0 coverage: ', num2str(fix(10000*CPICHEcIoCovP)/100), ' %']);
   hold on
   plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 1.5);
   hold off
   
   tmpCovVector = CPICHEcIo(find(inplgn(:)));
   tmpT = (1:length(tmpCovVector))/length(tmpCovVector);
   tmpCovVector = sort(tmpCovVector);
   [tmpClosest, tmpClosestInd] = min(abs(tmpT-(1-tmpCovTarget/100)));
   tmpCorrection = tmpEcIoThreshold-tmpCovVector(tmpClosestInd);
   layerNum = '';
   if tmpNumLayers > 1
      layerNum = num2str(layer);
   end
   if tmpCorrection >= 0
      disp(['CPICH powers should be increased approx. by ', num2str(tmpCorrection), ' dBs to achieve the target cov. P.']); 
   else
      disp(['CPICH powers should be decreased approx. by ', num2str(-tmpCorrection), ' dBs to achieve the target cov. P.']); 
   end
   
   figure
   plot(tmpCovVector, tmpT);
   grid
   hold on
   tmpA = axis;
   tmpA(1) = max(-30, tmpA(1));
   axis(tmpA);
   tmpH1 = plot([tmpA(1) tmpCovVector(tmpClosestInd) tmpCovVector(tmpClosestInd)], ...
                [1-tmpCovTarget/100 1-tmpCovTarget/100 tmpA(3)], 'r-');
   tmpH2 = plot([tmpA(1) tmpEcIoThreshold tmpEcIoThreshold], [1-CPICHEcIoCovP 1-CPICHEcIoCovP tmpA(3)], 'g-');
   legend([tmpH1; tmpH2], ['CPICH Ec/Io at target cov. P (' num2str(tmpCovTarget) ' %)'], ...
                          ['CPICH cov. P at CPICH cov. threshold (' num2str(tmpEcIoThreshold) ' dB)'], 2);
   tmpH3 = text(0.5+tmpCovVector(tmpClosestInd), (1-tmpCovTarget/100)/2, [num2str(round(100*(tmpCovVector(tmpClosestInd)))/100) ' dB']);
   set(tmpH3, 'Color', 'r');
   tmpH4 = text(tmpA(1), 1-CPICHEcIoCovP, num2str(round(1000*(1-CPICHEcIoCovP))/1000));
   set(tmpH4, 'Color', 'g', 'horizontalAlignment', 'right');
 
   xlabel('CPICH E_c/I_0 (dB)');
   ylabel('P(CPICH E_c/I_0 < abscissa)')
   title(['CDF of CPICH E_c/I_0, combined for all carriers']);
   hold off;
   
   clear CPICHEcIo ItotPDL1 isNotCovered xx1 yy1 ind11
   clear totA inplgn plgn answer
   clear orthFactorvec orthFactormat CPICHPowermat
end
