%CALCCOVPDL   CALCCOVPDL calculates the area coverage probability for a DL dedicated 
%             channel. It uses the traffic load (i.e. BS transmit powers) which has 
%             been generated in npsw downlink iteration. 
%
%             The required transmit power per link is calculated in each pixel of the wanted
%             area and this is compared to the power limits per link which are 
%             calculated based on the input 
%             parameters. If the required power exceeds the limit in a pixel this pixel is 
%             considered to be in outage.
%
%             The maximum power per link maybe limited by two parameters. In RNC there 
%             are the parameters PtxDlAbsMax and CPICHToRefRabOffset. CPICHToRefRabOffset
%             defines the maximum power per link with respect to the CPICH Tx power so that
%             CPICHToRefRabOffset is subtracted from the CPICH power. For other services
%             the maximum powers are scaled based on Eb/No and bitrate differences to 
%             the refererence power. The limit calculated by this method is compared
%             to PtxDlAbsMax and the smaller one is chosen. By this method one can have, 
%             for different services, equal coverage (PtxDlAbsMax set very high) or 
%             different coverage (PtxDlAbsMax set corresponding
%             to the most power demanding service for which full coverage is offered).
%             The reference service is in this script the one with wideAreaCovR and
%             the Eb/No for the reference service is based on wideAreaCovR and wideAreaCovSpeed.
%
%             In soft handover MRC combining is assumed. Also it is assumed that 
%             each link in SHO is transmitted with equal power with one excpetion: if 
%             the CPICH channel powers are not equal the the transmit powers are scaled
%             by the CPICH channel power differencies.
%             The wanted area is chosen by mouse by pointing two corners 
%             of a rectangle. Coverage probability is calculated by counting the pixels in 
%             coverage divided by the total number of pixels.
%
%             Finally the cumulative probability of required transmit powers is plotted
%             using two different scaling. In upper figure the scaling is done down to
%             reference RAB and CPICH power of the cells is subtracted. This is done for 
%             setting the parameter CPICHToRefRabOffset.
%
%             In the lower figure required transmit powers are plotted in the original scale.
%             This is for helping the setting of pTxDLAbsMAx.
%
%Inputs:
%   the outputs of the downlink iteration
%   basestation           : the base station data structure
%   mobilestation         : the mobile station data structure
%   yPixels, xPixels      : numbers of pixels in each direction 
%   tmpBitRate            : the bitrate of the service for which the coverage is 
%                           calculated 
%   tmpSpeed              : the MS speed for which the coverage is calculated
%   tmpAbsMax             : the maximum power per link for any service and cell
%   tmpCPICHToRefRabOffset: the offset which defines the maximum power for a reference 
%                           service with respect to the CPICH Tx power
%   tmpAbsMax             : the limit which no dedicated Tx power per link can exceed.
%                           Corresponds to the parameter PtxDlAbsMax of RNC.
%   tmpCoverageTarget     : the specified coverage probability target
%   bsTxPowerLin          : numBSs times numMSs matrix of DL transmit powers of each link
%   numBSs                : number of cells      
%   commonChannelOther    : total transmit power of common channels other than CPICH
%                           of each base station   
%   linklossDL            : numBSs x yPixels x xPixels matrix of DL linklosses from each BS 
%                           to map pixels
%   bestServDL            : yPixels x xPixels matrix of indeces of the best server in DL 
%                           in each map pixel
%   msNoisePowerLin       : noise power in MS
%   wideAreaCovR          : bitrate of the reference service
%   wideAreaCovSpeed      : MS speed for the reference service
%
%
%Outputs:
%   wideAreaCovPDL        : Area coverage probability for the wanted service
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcMSEbNoDL.m CalcShoGain.m lin2log.m, log2lin.m, BSplot.m, Polygon.m, Poly1.m

isResearchVersion = 1; %set to 0 for customer version
clear previousPolygonFlag

if numBStype1 & numBStype2
   if mode == 2
      layerString = 'OP1:';
      layerString2 = 'OP2:';
   else
      layerString = 'CA1:';
      layerString2 = 'CA2:';
   end
else 
   layerString = '';
end

if numBStype1
   if (~exist('tmpBitRate'))
      tmpBitRate = wideAreaCovR;
   end
   
   if (~exist('tmpSpeed'))
      tmpSpeed = wideAreaCovSpeed;
   end
   
   if (exist('useCommonAbsMax'))&(useCommonAbsMax)
      tmpAbsMax = ones(1, length(basestation))*tmpAbsMaxAll;
   else
      tmpAbsMax = [basestation.pTxDLAbsMax];
   end
   
   if (exist('useCommonOffset'))&(useCommonOffset)
      tmpCPICHToRefRabOffset = ones(1, length(basestation))*tmpCPICHToRefRabOffsetAll;
   else
      tmpCPICHToRefRabOffset = [basestation.CPICHToRefRabOffset];
   end
   
   if (~exist('tmpCovTarget'))
      tmpCovTarget = 95;
   end
   
   %Generation of orthogonality factors to map pixels
   orthFactormat = zeros(yPixels,xPixels);
   %Required Eb/No for the studied service to each pixel.
   tmpEbNoDL = zeros(yPixels,xPixels);
   
   for i1 = 1:numChannels
      ind1 = find(channelMap(1, :)==channels(i1));
      if (length(ind1) >= 1)   
         orthFactormat(ind1) = CalcOrthogonality(linkPerf(channels(i1)), tmpSpeed);
         tmpEbNoDL(ind1) = log2lin(CalcMsEbNoDL(linkPerf(channels(i1)), tmpSpeed, tmpBitRate));
      end
   end
   
   tmpEbNoRefRab = log2lin([basestation.wideAreaCovEbNoDL]);
   
   %Planned Eb/No of the studied service
   tmpEbNoPlanned = ones(size(tmpEbNoRefRab));
   for i1 = 1:numBSs
      tmpEbNoPlanned(i1) = log2lin(CalcMsEbNoDL(linkPerf(basestation(i1).channel), wideAreaCovSpeed, tmpBitRate));
   end
   
   %Maximum power for the reference seervice for each cell
   tmpMaxPowerRefRab = [basestation.CPICHPower]-tmpCPICHToRefRabOffset;
   %Maximum power for the studied service for each cell
   tmpPowerMax = lin2log(tmpBitRate/wideAreaCovR*log2lin(tmpMaxPowerRefRab).*tmpEbNoPlanned./tmpEbNoRefRab);
   tmpPowerMax = min(tmpPowerMax, tmpAbsMax);
   %Received C/I requirement for the studied service
   rho = tmpEbNoDL*tmpBitRate/W;
   
   disp('Calculating required tx power to each pixel...');
   
   %CPICHCorrectionM will include the power differencies of each cell if the CPICH powers 
   %of the active set are different. The cell with highest CPICH power is normalized
   %to one. CPICHCorrectionM is calculated to each cell and to each pixel and if one cell
   %is not in active set in a pixel the value will be zero.
   CPICHCorrectionM = zeros(numBSs, yPixels, xPixels);
   %tx_power_limit is the maximum allowed transmit power of the cell with highest CPICH power
   %to each pixel
   tx_power_limit = 9999*ones(yPixels, xPixels);
   tmp_max_CPICH  = -9999*ones(yPixels, xPixels);
   tmp_max_power  = tmp_max_CPICH;
   areaSHOGainsDL = zeros(yPixels, xPixels);
   CPICHLevel1    = squeeze(CPICHLevel(1, :, :));
   bestServDL1    = squeeze(bestServDL(1, :, :));
   tmp_w_add_map  = zeros(yPixels, xPixels);
   tmp_w_add_map(:) = [basestation(bestServDL1).WINDOW_ADD];
   
   for i1 = indBStype1
      CPICHCorrectionM(i1, :) = CPICHStrength(i1,:)>=(CPICHLevel1(:)+tmp_w_add_map(:))';
      ind1 = find(CPICHCorrectionM(i1, :) > 0);
      tmp_max_CPICH(ind1) = max(tmp_max_CPICH(ind1), basestation(i1).CPICHPower);
      tmp_max_power(ind1) = max(tmp_max_power(ind1), tmpPowerMax(i1));   
   end
   
   tx_power_limit = tmp_max_power;
   clear tmp_w_add_map;
   tmp_CPICH_Strength = CPICHCorrectionM.*CPICHStrength+(-999)*(~CPICHCorrectionM);
   for i1 = indBStype1
      CPICHCorrectionM(i1, :) = CPICHCorrectionM(i1, :).*log2lin(tmpPowerMax(i1)-(tmp_max_power(:))');   
   end
   
   %SHO gain calculation begins 
   [tmp_max,tmp_i] = max(tmp_CPICH_Strength,[],1);
   tmp_max = squeeze(tmp_max);
   tmp_i = squeeze(tmp_i);
   %set the best CPICH Ec to a small value
   for i1 = indBStype1
      tmp_CPICH_Strength(i1, find(tmp_i==i1)) = -999;
   end
   %find the second best CPICH Ec
   [tmp_max_2, tmp_i] = max(tmp_CPICH_Strength, [], 1);
   tmp_max_2 = squeeze(tmp_max_2);
   %find the difference between the best and the second best CPICH
   tmp_delta = abs(tmp_max-tmp_max_2);
   clear tmp_max_2 tmp_max tmp_i tmp_CPICH_Strength;
   %find the SHO gains to each pixel according to the difference between
   %the best and the second best CPICH Ec and the channel in the pixel.
   for i1 = 1:numChannels
      ind1 = find(channelMap(1, :)==channels(i1));
      if (length(ind1) >= 1)
         areaSHOGainsDL(ind1) = ...
            CalcShoGain(tmpSpeed*ones(size(tmp_delta(ind1))), tmp_delta(ind1), linkPerf(channels(i1)), 4);
      end
   end
   %SHO gain calculation ends 
   
   %Total Tx power of each cell
   bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2)+ ...
                         log2lin([basestation.CPICHPower]')+log2lin([basestation.commonChannelOther]');
   
   linkloss1 = log2lin(linklossDL);
   %Total received power in each pixel from each cell
   ItotPDL3dim = repmat(bsTxPowerTotLin, [1 yPixels xPixels])./linkloss1;               
   %Total received power in each pixel for layer 1
   if (numBStype2)
      ItotPDL1 = squeeze(sum(ItotPDL3dim(indBStype1, :, :), 1))+...
                 squeeze(sum(ItotPDL3dim(indBStype2, :, :), 1))/log2lin(acFilterDL(channelOffset));
   else
      ItotPDL1 = squeeze(sum(ItotPDL3dim(indBStype1, :, :),1));        
   end
   
   %required_tx_power will contain the required tx power per link to each pixel.
   %This is calculated for the cell with highest CPICH power in active set.
   required_tx_power = zeros(2, yPixels, xPixels);
   for i1 = indBStype1
      ind1 = CPICHCorrectionM(i1, :)>0;
      I1 = ItotPDL1(ind1)-orthFactormat(ind1).*ItotPDL3dim(i1, ind1)+MS_noise_power_lin;
      required_tx_power(1, ind1) = required_tx_power(1, ind1)+CPICHCorrectionM(i1, ind1)./(I1.*linkloss1(i1, ind1));
   end
   
   required_tx_power(1, :) = (rho(:)./log2lin(areaSHOGainsDL(:)))'./required_tx_power(1,:);
   
   %In required_tx_power1, outage pixels are put to 999.
   required_tx_power1 = squeeze(required_tx_power(1, :, :));
   ind1 = required_tx_power1 ~= 0;
   required_tx_power1(ind1) = lin2log(required_tx_power1(ind1));
   required_tx_power1(~ind1) = 999;
   required_tx_power1(required_tx_power1 > tx_power_limit) = 999;
   disp('...done');
   
   if (~exist('subplotFlag'))
      subplotFlag = 0;
   end
   if (exist('areaBasedFlag'))
      if (areaBasedFlag == 1) 
         figure;
         upperLimit = 40;
         lowerLimit = 10;
         ind = find(required_tx_power1 > tx_power_limit);
         required_tx_power1(find(required_tx_power1>upperLimit)) = upperLimit;
         required_tx_power1(find(required_tx_power1<lowerLimit)) = lowerLimit;
         required_tx_power1(ind) = lowerLimit-1;
         required_tx_power1(~isnan(waterArea)) = NaN;
         pcolor(xmin:resolution:xmax, ...
                ymin:resolution:ymax, ...
                required_tx_power1);
         caxis([lowerLimit-1 upperLimit]);
         colors1 = [[0 0 0]; jet(upperLimit-lowerLimit)];
         colormap(colors1);
         hcb = colorbar('vert'); 
         axis('equal');
         if (numBStype1 & numBStype2)
            if mode == 2
               header = ['Required transmit power per link for Operator 1'];
            else
               header = ['Required transmit power per link for Carrier 1'];  
            end
         else
            header = ['Required transmit power per link'];
         end   
         title(['\it{}' header]);
         shading('flat')
         set(get(hcb, 'Title'), 'String', 'Transmit power');
         set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' dBm'));
         BSplot(basestation, gcf, vectMap, lossData);
         
         [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
         
         if (totA <= 0) 
            disp('Warning: Zero area in wide area coverage probability calculation.');
            wideAreaCovPDL = 1;
            clear tmpEbNoDL tmpEbNoRefRab tmpEbNoPlanned tmpMaxPowerRefRab tmpPowerMax rho; 
            clear CPICHCorrectionM CPICHCorrectionV tx_power_limit required_tx_power1;
            clear linkloss1 ItotPDL3dim ItotPDL1;
            clear ind1 tmp_vect;
            clear totA inplgn plgnX plgnY plgn;
            return
         end
         
         isCovered = (required_tx_power1 >= lowerLimit).*inplgn;
         wideAreaCovPDL = sum(sum(isCovered))/totA;
         
         xlabel(['Speed: ', num2str(tmpSpeed), ' km/h    ', ...
                 'Bit-rate: ', num2str(tmpBitRate/1000), ' kbits/s    ', ...
                 'Coverage: ', num2str(100*wideAreaCovPDL), ' %']);
      
         %In required_tx_power2 the required_tx_power has been scaled to reference RAB and 
         %relative to CPICH powers of the cells.
         %required_tx_power3 is just the required_tx_power in the pixels of the chosen area
         
         ind1 = find(inplgn > 0);
         required_tx_power3 = lin2log(squeeze(required_tx_power(1, ind1)));
         required_tx_power2 = required_tx_power3-tmp_max_CPICH(ind1')-...
                              lin2log(tmpBitRate/wideAreaCovR*...
                              tmpEbNoPlanned(bestServDL1(ind1'))./tmpEbNoRefRab(bestServDL1(ind1')));
         
         required_tx_power2 = sort(required_tx_power2);
         required_tx_power3 = sort(required_tx_power3);
         
         t1 = 1:length(required_tx_power2);
         t1 = 100*t1/length(required_tx_power2);
         
         if (isResearchVersion)
            figure;
            if (subplotFlag ~= 0)
               subplot(211);
            end
            plot(required_tx_power2, t1);
            grid;
            a = axis;
            hold on;
            [dummy, ind1] = min(abs(t1-tmpCovTarget));
            requiredCPICHToRefRabOffset = -required_tx_power2(ind1);
            disp([layerString 'Required CPICHToRefRabOffset with ', num2str(tmpCovTarget), '% coverage probability: ', ...
                  num2str(requiredCPICHToRefRabOffset), ' dB']);
            h2 = plot([a(1) -requiredCPICHToRefRabOffset, -requiredCPICHToRefRabOffset], [tmpCovTarget tmpCovTarget a(3)], 'r');
            tmpH1 = text(1-requiredCPICHToRefRabOffset, tmpCovTarget/2, [num2str(round(100*(requiredCPICHToRefRabOffset))/100) ' dB']);
            set(tmpH1, 'Color', 'r');
            title(['\it{' layerString ' CDF of scaled required power per link below the CPICH power}']);
            xlabel('Scaled required Tx power below the CPICH (dB)');
            ylabel('Probability (%)');
            legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
            set(gca, 'xticklabel', num2str(-str2num(get(gca, 'xticklabel'))));
         end
         
         if (subplotFlag ~= 0)
            subplot(212);
         else
            figure
         end
         plot(required_tx_power3, t1);
         grid;
         a = axis;
         hold on;
         [dummy, ind1] = min(abs(t1-tmpCovTarget));
         requiredMaxTxPower = required_tx_power3(ind1); 
         disp([layerString 'Required Tx power with ', num2str(tmpCovTarget), '% coverage probability: ', ...
               num2str(requiredMaxTxPower), ' dBm']);
         h2 = plot([a(1) requiredMaxTxPower, requiredMaxTxPower], [tmpCovTarget, tmpCovTarget, a(3)], 'r');
         tmpH1 = text(1+requiredMaxTxPower, tmpCovTarget/2, [num2str(round(100*(requiredMaxTxPower))/100) ' dBm']);
         set(tmpH1, 'Color', 'r');
         if (numBStype1 & numBStype2)
            if mode == 2
               title('\it{CDF of required power per link for Operator 1}');
            else
               title('\it{CDF of required power per link for Carrier 1}');
            end
         else
            title('\it{CDF of required power per link}');
         end
         xlabel('Required Tx power (dBm)');
         ylabel('Probability (%)');
         legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
         
         hold off;   
      end
   end
end

clear whatever

runOp2 = 0;
if numBStype2
   if mode == 2
      answer = questdlg('Do analysis for Operator 2 ?', 'Operator 2 Analysis', 'Yes', 'No', 'Yes');
   else
      answer = questdlg('Do analysis for Carrier 2 ?', 'Carrier 2 Analysis', 'Yes', 'No', 'Yes');
   end   
   runOp2 = strcmp(answer, 'Yes');
   
   if runOp2  
      
      clear previousPolygonFlag
      
      if (~exist('tmpBitRate'))
         tmpBitRate = wideAreaCovR;
      end
      
      if (~exist('tmpSpeed'))
         tmpSpeed = wideAreaCovSpeed;
      end
      
      if (exist('useCommonAbsMax'))&(useCommonAbsMax)
         tmpAbsMax = ones(1, length(basestation))*tmpAbsMaxAll;
      else
         tmpAbsMax = [basestation.pTxDLAbsMax];
      end
      
      if (exist('useCommonOffset'))&(useCommonOffset)
         tmpCPICHToRefRabOffset = ones(1, length(basestation))*tmpCPICHToRefRabOffsetAll;
      else
         tmpCPICHToRefRabOffset = [basestation.CPICHToRefRabOffset];
      end
      
      if (~exist('tmpCovTarget'))
         tmpCovTarget = 95;
      end
      
      %Generation of orthogonality factors to map pixels
      orthFactormat = zeros(yPixels,xPixels);
      %Required Eb/No for the studied service to each pixel.
      tmpEbNoDL = zeros(yPixels,xPixels);
      
      for i1 = 1:numChannels
         ind1 = find(channelMap(2,:)==channels(i1));
         if (length(ind1) >= 1)   
            orthFactormat(ind1) = CalcOrthogonality(linkPerf(channels(i1)),tmpSpeed);
            tmpEbNoDL(ind1) = log2lin(CalcMsEbNoDL(linkPerf(channels(i1)), tmpSpeed, tmpBitRate));
         end
      end
      
      tmpEbNoRefRab = log2lin([basestation.wideAreaCovEbNoDL]);
      tmpEbNoPlanned = ones(size(tmpEbNoRefRab));
      for i1 = 1:numBSs,
         tmpEbNoPlanned(i1) = ...
            log2lin(CalcMsEbNoDL(linkPerf(basestation(i1).channel), wideAreaCovSpeed, tmpBitRate));
      end
      
      %Maximum power for the reference seervice for each cell
      tmpMaxPowerRefRab = [basestation.CPICHPower]-tmpCPICHToRefRabOffset;
      tmpPowerMax = lin2log(tmpBitRate/wideAreaCovR*log2lin(tmpMaxPowerRefRab).*tmpEbNoPlanned./tmpEbNoRefRab);
      tmpPowerMax = min(tmpPowerMax, tmpAbsMax);
      %Received C/I requirement for the studied service
      rho = tmpEbNoDL*tmpBitRate/W;
      
      disp('Calculating required tx power to each pixel...');
      
      %CPICHCorrectionM will include the power differencies of each cell if the CPICH powers 
      %of the active set are different. The cell with highest CPICH power is normalized
      %to one. CPICHCorrectionM is calculated to each cell and to each pixel and if one cell
      %is not in active set in a pixel the value will be zero.
      
      %tx_power_limit is the maximum allowed transmit power of the cell with highest CPICH power
      %to each pixel
      tx_power_limit = 9999*ones(yPixels, xPixels);
      tmp_max_CPICH = -9999*ones(yPixels, xPixels);
      tmp_max_power = tmp_max_CPICH;
      areaSHOGainsDL = zeros(yPixels, xPixels);
      CPICHLevel1 = squeeze(CPICHLevel(2, :, :));
      bestServDL1 = squeeze(bestServDL(2, :, :));
      
      tmp_w_add_map = zeros(yPixels, xPixels);
      tmp_w_add_map(:) = [basestation(bestServDL1).WINDOW_ADD];      
      
      for i1 = indBStype2
         CPICHCorrectionM(i1, :)=CPICHStrength(i1, :) >= (CPICHLevel1(:)+tmp_w_add_map(:))';
         ind1=find(CPICHCorrectionM(i1, :) > 0);
         tmp_max_CPICH(ind1) = max(tmp_max_CPICH(ind1), basestation(i1).CPICHPower);
         tmp_max_power(ind1) = max(tmp_max_power(ind1), tmpPowerMax(i1));   
      end
      
      tx_power_limit = tmp_max_power;
      clear tmp_w_add_map;
      tmp_CPICH_Strength = CPICHCorrectionM.*CPICHStrength + (-999)*(~CPICHCorrectionM);
      
      if numBStype1
         tmp_CPICH_Strength(indBStype1,:) = -999;
      end
         
      for i1 = indBStype2,
         CPICHCorrectionM(i1, :) = CPICHCorrectionM(i1, :).*log2lin(tmpPowerMax(i1)-(tmp_max_power(:))');   
      end
      
      %SHO gain calculation begins 
      [tmp_max, tmp_i] = max(tmp_CPICH_Strength,[],1);
      tmp_max = squeeze(tmp_max);
      tmp_i = squeeze(tmp_i);
      %set the best CPICH Ec to a small value
      for i1 = indBStype2
         tmp_CPICH_Strength(i1, find(tmp_i==i1)) = -999;
      end
      %find the second best CPICH Ec
      [tmp_max_2, tmp_i] = max(tmp_CPICH_Strength, [], 1);
      tmp_max_2 = squeeze(tmp_max_2);
      %find the difference between the best and the second best CPICH
      tmp_delta = abs(tmp_max-tmp_max_2);
      clear tmp_max_2 tmp_max tmp_i tmp_CPICH_Strength;
      %find the SHO gains to each pixel according to the difference between
      %the best and the second best CPICH Ec and the channel in the pixel.
      for i1 = 1:numChannels
         ind1 = find(channelMap(2, :)==channels(i1));
         if (length(ind1) >= 1)
            areaSHOGainsDL(ind1) = ...
               CalcShoGain(tmpSpeed*ones(size(tmp_delta(ind1))), tmp_delta(ind1), linkPerf(channels(i1)), 4);
         end
      end
      %SHO gain calculation ends 
      
      %Total Tx power of each cell
      bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2)+ ...
                        log2lin([basestation.CPICHPower]')+log2lin([basestation.commonChannelOther]');
      
      linkloss1 = log2lin(linklossDL);               
      %Total received power in each pixel from each cell
      ItotPDL3dim = repmat(bsTxPowerTotLin, [1 yPixels xPixels])./linkloss1;               
      %Total received power in each pixel for layer 1
      if numBStype1
         ItotPDL1 = squeeze(sum(ItotPDL3dim(indBStype1, :, :), 1))/log2lin(acFilterDL(channelOffset))+...
            squeeze(sum(ItotPDL3dim(indBStype2, :, :), 1));
      else
         ItotPDL1 = squeeze(sum(ItotPDL3dim(indBStype2, :, :), 1));
      end
         
      %required_tx_power will contain the required tx power per link to each pixel.
      %This is calculated for the cell with highest CPICH power in active set.
      for i1 = indBStype2
         ind1 = CPICHCorrectionM(i1, :)>0;
         I1 = ItotPDL1(ind1)-orthFactormat(ind1).*ItotPDL3dim(i1, ind1)+MS_noise_power_lin;
         required_tx_power(2, ind1) = required_tx_power(2, ind1)+CPICHCorrectionM(i1, ind1)./(I1.*linkloss1(i1, ind1));
      end
      
      required_tx_power(2, :) = (rho(:)./log2lin(areaSHOGainsDL(:)))'./required_tx_power(2, :);
      
      %In required_tx_power1, outage pixels are put to 999.
      required_tx_power1 = squeeze(required_tx_power(2, :, :));
      ind1 = required_tx_power1~=0;
      required_tx_power1(ind1) = lin2log(required_tx_power1(ind1));
      required_tx_power1(~ind1) = 999;
      required_tx_power1(required_tx_power1 > tx_power_limit) = 999;
      disp('...done');
      
      if (~exist('subplotFlag'))
         subplotFlag = 0;
      end
      
      if (exist('areaBasedFlag'))
         if (areaBasedFlag == 1) 
            figure;
            upperLimit = 40;
            lowerLimit = 10;
            ind = find(required_tx_power1 > tx_power_limit);
            required_tx_power1(find(required_tx_power1>upperLimit)) = upperLimit;
            required_tx_power1(find(required_tx_power1<lowerLimit)) = lowerLimit;
            required_tx_power1(ind) = lowerLimit-1;
            required_tx_power1(~isnan(waterArea)) = NaN;
            pcolor(xmin:resolution:xmax, ...
                   ymin:resolution:ymax, ...
                   required_tx_power1);
            caxis([lowerLimit-1 upperLimit]);
            colors1 = [[0 0 0]; jet(upperLimit-lowerLimit)];
            colormap(colors1);
            hcb = colorbar('vert'); 
            axis('equal');
            if mode == 2
               header = ['Required transmit power per link for Operator 2'];
            else
               header = ['Required transmit power per link for Carrier 2'];
            end
            title(['\it{}' header]);
            shading('flat')
            set(get(hcb, 'Title'), 'String', 'Transmit power');
            set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' dBm'));
            BSplot(basestation, gcf, vectMap, lossData);
            
            if (~exist('previousPolygonFlag'))
               if mode == 2
                  [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 2);
               else
                  [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 3);
               end
            end
           
            if (totA <= 0) 
               disp('Warning: Zero area in wide area coverage probability calculation.');
               wideAreaCovPDL = 1;
               clear tmpEbNoDL tmpEbNoRefRab tmpEbNoPlanned tmpMaxPowerRefRab tmpPowerMax rho; 
               clear CPICHCorrectionM CPICHCorrectionV tx_power_limit required_tx_power1;
               clear linkloss1 ItotPDL3dim ItotPDL1;
               clear ind1 tmp_vect;
               clear totA inplgn plgnX plgnY plgn;
               return
            end
            
            isCovered = (required_tx_power1 >= lowerLimit).*inplgn;
            wideAreaCovPDL = sum(sum(isCovered))/totA;
            
            xlabel(['Speed: ', num2str(tmpSpeed), ' km/h    ', ...
                    'Bit-rate: ', num2str(tmpBitRate/1000), ' kbits/s    ', ...
                    'Coverage: ', num2str(100*wideAreaCovPDL), ' %']);
            
            %In required_tx_power2 the required_tx_power has been scaled to reference RAB and 
            %relative to CPICH powers of the cells.
            %required_tx_power3 is just the required_tx_power in the pixels of the chosen area
            
            ind1 = find(inplgn > 0);
            required_tx_power3 = lin2log(squeeze(required_tx_power(2, ind1)));
            required_tx_power2 = required_tx_power3-tmp_max_CPICH(ind1')-...
                                 lin2log(tmpBitRate/wideAreaCovR*...
                                 tmpEbNoPlanned(bestServDL1(ind1'))./tmpEbNoRefRab(bestServDL1(ind1')));
            
            required_tx_power2 = sort(required_tx_power2);
            required_tx_power3 = sort(required_tx_power3);
            
            t1 = 1:length(required_tx_power2);
            t1 = 100*t1/length(required_tx_power2);
            
            if (isResearchVersion)
               figure;
               if (subplotFlag ~= 0)
                  subplot(211);
               end
               plot(required_tx_power2, t1);
               grid;
               a = axis;
               hold on;
               [dummy, ind1] = min(abs(t1-tmpCovTarget));
               requiredCPICHToRefRabOffset = -required_tx_power2(ind1);
               disp([layerString2 'Required CPICHToRefRabOffset with ', num2str(tmpCovTarget), '% coverage probability: ', ...
                     num2str(requiredCPICHToRefRabOffset), ' dB']);
               
               h2 = plot([a(1) -requiredCPICHToRefRabOffset, -requiredCPICHToRefRabOffset], ...
                         [tmpCovTarget tmpCovTarget a(3)], 'r');
               tmpH1 = text(1-requiredCPICHToRefRabOffset, tmpCovTarget/2, [num2str(round(100*(requiredCPICHToRefRabOffset))/100) ' dB']);
               set(tmpH1, 'Color', 'r');
               title(['\it{' layerString2 ' CDF of scaled required power per link below the CPICH power}']);
               xlabel('Scaled required Tx power below the CPICH (dB)');
               ylabel('Probability (%)');
               legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
               set(gca, 'xticklabel', num2str(-str2num(get(gca, 'xticklabel'))));
            end
            
            if (subplotFlag ~= 0)
               subplot(212);
            else
               figure;
            end
            plot(required_tx_power3, t1);
            grid;
            a = axis;
            hold on;
            [dummy, ind1] = min(abs(t1-tmpCovTarget));
            requiredMaxTxPower = required_tx_power3(ind1); 
            disp([layerString2 'Required Tx power with ', num2str(tmpCovTarget), '% coverage probability: ', ...
                  num2str(requiredMaxTxPower), ' dBm']);
            h2 = plot([a(1) requiredMaxTxPower, requiredMaxTxPower], [tmpCovTarget, tmpCovTarget, a(3)], 'r');
            tmpH1 = text(1+requiredMaxTxPower, tmpCovTarget/2, [num2str(round(100*(requiredMaxTxPower))/100) ' dBm']);
            set(tmpH1, 'Color', 'r');
            if mode == 2
               title('\it{CDF of required power per link for Operator 2}');
            else
               title('\it{CDF of required power per link for Carrier 2}');
            end
            xlabel('Required Tx power (dBm)');
            ylabel('Probability (%)');
            legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
            
            hold off;   
         end
      end
   end
end

if (exist('wantedBSs'))
   if (~isempty(wantedBSs))
      requiredMaxTxPowerBS = -999*ones([numBSs, 1]);
      requiredCPICHToRefRabOffsetBS = -999*ones([numBSs, 1]);
      for i1 = 1:length(wantedBSs)
         if (ismember(wantedBSs(i1), indBStype1) | (ismember(wantedBSs(i1), indBStype2) & runOp2))
            i2 = wantedBSs(i1);
            if (numBStype2 > 0 & numBStype2 > 0 & ismember(i2, indBStype2))
               layer = 2;
            else
               layer = 1;
            end
            ind1 = CPICHCorrectionM(i2, :) > 0;
            
            required_tx_power3 = lin2log(squeeze(required_tx_power(layer, ind1)).*CPICHCorrectionM(i2, ind1));
            required_tx_power2 = required_tx_power3-basestation(i2).CPICHPower-...
                                 lin2log(tmpBitRate/wideAreaCovR*tmpEbNoPlanned(i2)/tmpEbNoRefRab(i2));
                        
            required_tx_power2 = sort(required_tx_power2);
            required_tx_power3 = sort(required_tx_power3);
            
            t1 = 1:length(required_tx_power2);
            t1 = 100*t1/length(required_tx_power2);
            
            figure
            
            if (subplotFlag ~= 0)
               subplot(211);
            end
            plot(required_tx_power2, t1);
            grid;
            a = axis;
            hold on;
            [dummy, ind1] = min(abs(t1-tmpCovTarget));
            
            requiredCPICHToRefRabOffsetBS(i2) = -required_tx_power2(ind1);
            
            disp(['Required CPICHToRefRabOffset at BS', num2str(i2), ' with ', num2str(tmpCovTarget), '% coverage probability: ', ...
                  num2str(requiredCPICHToRefRabOffsetBS(i2)), ' dB']);
            h2 = plot([a(1) -requiredCPICHToRefRabOffsetBS(i2) -requiredCPICHToRefRabOffsetBS(i2)], ...
                      [tmpCovTarget tmpCovTarget a(3)], 'r');
            tmpH1 = text(1-requiredCPICHToRefRabOffsetBS(i2), tmpCovTarget/2, [num2str(round(100*(requiredCPICHToRefRabOffsetBS(i2)))/100) ' dB']);
            set(tmpH1, 'Color', 'r');
            titleText = ['CDF of scaled required power per link below the CPICH power at ' char(basestation(i2).nameLong)];
            title(['\it{' titleText '}']);
            xlabel('Scaled required Tx power below the CPICH (dB)');
            ylabel('Probability (%)');
            set(gca, 'xticklabel', num2str(-str2num(get(gca, 'xticklabel'))));
            legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
            
            if (subplotFlag ~= 0)
               subplot(212);
            else
               figure
            end
            plot(required_tx_power3, t1);
            grid;
            a = axis;
            hold on;
            [dummy, ind1] = min(abs(t1-tmpCovTarget));
            requiredMaxTxPowerBS(i2) = required_tx_power3(ind1); 
            disp(['Required Tx power at BS', num2str(i2), ' with ', num2str(tmpCovTarget), '% coverage probability: ', ...
                  num2str(requiredMaxTxPowerBS(i2)), ' dBm']);
            h2 = plot([a(1) requiredMaxTxPowerBS(i2) requiredMaxTxPowerBS(i2)], [tmpCovTarget tmpCovTarget a(3)], 'r');
            tmpH1 = text(1+requiredMaxTxPowerBS(i2), tmpCovTarget/2, [num2str(round(100*(requiredMaxTxPowerBS(i2)))/100) ' dBm']);
            set(tmpH1, 'Color', 'r');
            titleText = ['CDF of required power per link at ' char(basestation(i2).nameLong)];
            title(['\it{' titleText '}']);
            xlabel('Required Tx power (dBm)');
            ylabel('Probability (%)');
            legend([h2], ['Target coverage probability (' num2str(tmpCovTarget) ' %)'], 0);
            
            hold off;   
         end
      end
   end
end

clear tmpEbNoDL tmpEbNoRefRab tmpEbNoPlanned tmpMaxPowerRefRab tmpPowerMax rho 
clear CPICHCorrectionM CPICHCorrectionV tx_power_limit required_tx_power1 required_tx_power2
clear linkloss1 ItotPDL3dim ItotPDL1 required_tx_power3 tmp_max_CPICH
clear ind1 tmp_vect subplotFlag answer layerString modeString
