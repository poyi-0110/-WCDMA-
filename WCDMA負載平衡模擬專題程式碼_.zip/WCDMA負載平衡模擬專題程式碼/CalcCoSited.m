%CALCCOSITED   ISCOSITED = CALCCOSITED(BASESTATION, DELTALOCALLOWED) calculate cells in the
%              basestation structure, which are co-sited. Co-sited cells are cells which are 
%              not more afar each other than DELTALOCALLOWED.
%              If DELTALOCALLOWED is ommitted, the map resolution is taken instead
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: ReduceBStxPower.m

function isCosited = CalcCoSited(basestation, deltaLocAllowed)

if nargin == 0
   error('CalcCoSited needs at least the BS structure !');
elseif nargin == 1
   deltaLocAllowed = evalin('base', 'resolution');
elseif nargin > 2
   error('Too many input arguments for CalcCoSited!');
end

numBSs = length(basestation);
deltaX = zeros(numBSs);
deltaY = zeros(numBSs);

for k = 1:numBSs-1
   for l = k+1:numBSs
      deltaX(k, l) = basestation(k).x-basestation(l).x;
      deltaY(k, l) = basestation(k).y-basestation(l).y;
   end
end

dist = abs(deltaX+j*deltaY);
%make "dist" symmetrical
dist = dist+dist';

isCosited = dist<deltaLocAllowed;
     
