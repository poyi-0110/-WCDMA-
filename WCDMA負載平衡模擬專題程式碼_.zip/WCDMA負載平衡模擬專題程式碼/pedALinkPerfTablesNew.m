%PEDALINKPERFTABLESNEW   PEDALINKPERFTABLESNEW consists of the Eb/No, SHO gain etc. tables,
%                        as a function of used MS speed. The tables have been written based
%                        on link level simulation results. When this script is run, a structure
%                        linkPerfTables will be formed which has all the information from the
%                        tables.
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%Used bit rates (64k, 144k, 512k packet data)
linkPerfTables.bitRates = ...
   [8000 12200 64000 144000 512000];

%Voice activity factors for the different bit rates 
% 	in uplink
linkPerfTables.vUL = ...
   [0.67 0.67 1.0 1.0 1.0];
%	in downlink
linkPerfTables.vDL = ...
   [0.67 0.67 1.0 1.0 1.0];

%Specified speeds. Other speeds will be interpolated.
linkPerfTables.speeds = ...
   [3 20 120];

linkPerfTables.orthogonality = ...
   [0.9 0.8 0.7];

%Rows: specified bit rates
%Columns: specified speeds
%Dimensions must match to dimensions of linkPerfTables.bitRates 
%and linkPerfTables.speeds.

linkPerfTables.EbNoUL = ...
   [5.0 6.0 6.6;
    4.0 5.0 5.6;   
    2.5 3.5 4.1;
    2.0 3.0 3.6;
    1.5 2.5 3.1];

linkPerfTables.EbNoDL = ...
   [12.0 10.5 9.0;
    11.0  9.5 8.0;
     9.5  8.0 7.0;
     8.5  7.0 6.5;
     8.0  6.5 6.0];
   
linkPerfTables.AvPRUL = ...
   [2.1 1.6 0.2];

linkPerfTables.AvPRDL = ...
   [5.0 4.5 2.5];

linkPerfTables.HRUL = ...
   [8.2 3.7 0.2]; 

linkPerfTables.shoDifferences = ...
   [0 3 6 10]';

linkPerfTables.RxPowSHOgainUL = ...
   [1.55 1.65 1.31;  % 0 dB diff
    0.7  0.79 0.14;  % 3 dB diff
    0.3  0.25 0.14;  % 6 dB diff
    0.05 0.03 0.00]; %10 dB diff
 
 linkPerfTables.TxPowSHOgainUL = ...
   [2.68 2.39 1.34;  % 0 dB diff
    1.43 1.21 0.14;  % 3 dB diff
    0.64 0.46 0.14;  % 6 dB diff
    0.13 0.06 0.00]; %10 dB diff

linkPerfTables.HRSHOgainUL = ...
   [4.5 3.2 1.5;  % 0 dB diff
    2.9 1.7 0.5;  % 3 dB diff
    1.8 0.8 0.1;  % 6 dB diff
    0.8 0.0 0.0]; %10 dB diff

linkPerfTables.TxPowSHOgainDL = ...
   [3.3 3.0 1.0;  % 0 dB diff
    2.8 2.5 0.7;  % 3 dB diff
    1.8 1.5 0.4;  % 6 dB diff
    0.6 0.3 0.1]; %10 dB diff
