%CALCCOVPUL   CALCCOVPUL calculates the area coverage probability for wanted
%             service (bit-rate) and wanted MS speed. It uses the traffic distribution
%             which has been generated in npsw uplink-iteration. The bestServer map is
%             with black dots corresponding to outage.
%
%             NOTE: The result indicates the cov. probability only according to
%             the traffic distribution generated in MS input file and npsw uplink iteration.
%             for high bit-rates the result may change a lot when the high bitrate MS:s which
%             were used in the iteration would have been put to different places.
%
%Inputs:
%   the outputs of the uplink iteration
%   tmpBitRate : the bit-rate (service) to be used in bits/s
%   tmpSpeed   : the MS speed to be used in km/h
%   activeSetT : activeSet matrix for the map, see CalcActiveSet.m
%   Note: if tmpBitRate and tmpSpeed are not defined beforehand, wideAreaCovBitRate
%         and wideAreaCovSpeed will be used.
%Outputs:
%   wideAreaCovP: Area coverage probability for a mobile having "tmpSpeed" and "tmpBitRate"
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BestServerULarea.m, DispBestServUL.m, PolygonGame.m, DispCompCovUL.m

clear previousPolygonFlag;
oldBestServerUL = bestServer;
if (~exist('previousService.mat'))
   bitrate = wideAreaCovR;
   speed = wideAreaCovSpeed;
   color = [1 0 0];
   txMaxPower = 21;
else
   load previousService; %loads bitrate, speed, color and txMaxPower vectors
end

numServices = length(bitrate);
tmpPow = zeros(numServices, yPixels, xPixels);
tmpCov = tmpPow;

for layer = 1:1+(numBStype2~=0)
   if layer == 2   
      if mode == 2
         answer = questdlg('Do analysis for Operator 2 ?', 'Operator 2 Analysis', 'Yes', 'No', 'Yes');
      else
         answer = questdlg('Do analysis for Carrier 2 ?', 'Carrier 2 Analysis', 'Yes', 'No', 'Yes');
      end
      runOp2 = strcmp(answer, 'Yes');
      if ~runOp2
         break
      end
   end
   
   for runService = 1:length(bitrate)
      tmpBitRate    = bitrate(runService);
      tmpSpeed      = speed(runService);
      tmpTxMaxPower = txMaxPower(runService);
      
      [tmpMsTxPower bestServer] = BestServerULArea(perf, linklossUL, tmpTxMaxPower, tmpSpeed, tmpBitRate, ...
                                                   activeSetT);
      DispBestServUL;
      tmpBestServer = squeeze(bestServer(layer, :, :));
      tmpPow(runService, :, :) = squeeze(tmpMsTxPower(layer, :, :));                                                       
      tmpCov(runService, :, :) = tmpBestServer~=0;
      
      if (~exist('previousPolygonFlag'))
         if (layer == 1)
            [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
         else 
            if mode == 2
               [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 2);
            else
               [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 3);
            end
         end
         previousPolygonFlag = 1;
      else
         hold on;
         plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 2);
         hold off
      end
      
      if (totA <= 0)
         disp('Warning: Zero area in wide area coverage probability calculation.');
         wideAreaCovP = 1;
         clear tmpBestServer tmpDominance tmpMsTxPower totA inplgn plgnX plgnY plgn;
         return
      end
      
      isCovered = (tmpBestServer ~= 0).*inplgn;
      wideAreaCovP = sum(sum(isCovered))/totA;
      
      xlabel(['Speed: ', num2str(tmpSpeed), ' km/h    ', ...
              'Bit-rate: ', num2str(tmpBitRate/1000), ' kbits/s    ', ...
              'Coverage: ', num2str(100*wideAreaCovP), ' %']);
   end
   DispCompCovUL
   clear previousPolygonFlag
end

%restore best server
bestServer = oldBestServerUL;

clear tmpBestServer tmpDominance tmpMsTxPower totA plgnX plgnY plgn isCovered previousPolygonFlag
clear oldBestServerUL

clear layer %this is important, don't delete or comment out !!!
