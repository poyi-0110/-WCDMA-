%SAVERESULTS   SAVERESULTS writes the specified outputs to a file
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%filename = ['CO211_' num2str(100*0.5) '_' num2str(1) '.txt'];

%tmpResult = [sum(bsTxPowerLin, 2)/1000 lin2log(sum(bsTxPowerLin, 2)) Ueta' [perf.mUL]' [perf.mDL]' [perf.SHO]' [perf.i]'];
%eval(['save ' filename ' tmpResult -ascii -tabs']);
