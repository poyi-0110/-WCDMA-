%BSDEFAULT   DEFAULTBS = BSDEFAULT() returns a base station having default parameters
%
%Inputs:
%   none
%Outputs:
%   DEFAULTBS: default BS
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function defaultBS = BSdefault()

defaultBS.x = 0;
defaultBS.y = 0;
defaultBS.groundHeight = 0;
defaultBS.antennaHeight = 35;
defaultBS.txMaxPower = 43.0;
defaultBS.txMaxPowerPerLink = 30.0;
defaultBS.txMinPowerPerLink = -999.0;
defaultBS.pTxDLAbsMax = 30.0;
defaultBS.CPICHPower = 30.0;
defaultBS.commonChannelOther = 30.0;
defaultBS.CPICHToRefRabOffset = 7.0;
defaultBS.antennaType = '65deg';
defaultBS.antennaDir = 0;
defaultBS.antennaTilt = 0;
defaultBS.cableLosses = 3;
defaultBS.mhaGain = 0;
defaultBS.rfHeadGain = 0;
defaultBS.channel = 1;
defaultBS.WINDOW_ADD = -3;
defaultBS.numCarr = 1;
defaultBS.usedCarr = 1;
defaultBS.excessLoadOwn = 0.5;
defaultBS.excessLoadTotal = 0.8;
