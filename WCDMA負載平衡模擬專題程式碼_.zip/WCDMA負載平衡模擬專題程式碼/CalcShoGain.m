%CalcShoGain   shoGain = CalcShoGain(speed, deltaSHO, linkPerfTables, type)
%              calculates the uplink SHO gain in average received  power (in the home
%              cell), or average transmitted power or headroom required for PC. The
%              gain is a function of speed and difference between two best SHO links.
%
%Inputs:
%   speed         : speed of the mobile station in km/h, (1, m) vector
%   deltaSHO      : difference between bestserver and next bestserver in dB, (1, m) vector
%   linkPerfTables: link performance tables including SHO gains as function of speed and
%                   deltaSHO 
%   type          : 1, indicates average received power gain
%                   2, indicates average transmitted power gain
%                   3, indicates headroom gain	
%Outputs:
%   shoGain       : the uplink SHO gain for the particular mobiles in the having "speed" and
%                   "deltaSHO" 
%
%Authors: Kari Sipil� (KSi)  Achim Wacker (AWa) 
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function shoGain = CalcShoGain(speed, deltaSHO, linkPerfTables, type)

m1 = length(linkPerfTables.speeds);
m2 = length(linkPerfTables.shoDifferences);
shoGain = zeros(size(speed));

if (size(speed) ~= size(deltaSHO)) 
	disp('ERROR in CalcShoGain. Speed and deltaSHO should be the same size.');
	return
end

if (type == 1)
	sho_gain_table = linkPerfTables.RxPowSHOgainUL;
elseif (type == 2)
	sho_gain_table = linkPerfTables.TxPowSHOgainUL;
elseif (type == 3)
	sho_gain_table = linkPerfTables.HRSHOgainUL;
elseif (type == 4)
   sho_gain_table = linkPerfTables.TxPowSHOgainDL;
else
	disp('ERROR in CalcShoGain. type - argument not valid');
	return
end

if (size(sho_gain_table) ~= [m2, m1])
	disp('ERROR in CalcShoGain. Gain, speed, shoDifference tables not consistent.');
	disp('                        Check LoadLinkPerfTables.m');
	return;
end	

bits1 = speed<linkPerfTables.speeds(1);
bits2 = speed>linkPerfTables.speeds(m1);
bits3 = deltaSHO<linkPerfTables.shoDifferences(1);
bits4 = deltaSHO>linkPerfTables.shoDifferences(m2);

bits = bits1 & bits3;
if sum(bits) > 0
   shoGain(bits) = sho_gain_table(1, 1);
end

bits = bits1 & bits4;
if sum(bits) > 0
   shoGain(bits) = 0;
end

bits = bits2 & bits3;
if sum(bits) > 0
   shoGain(bits) = sho_gain_table(1, m1);
end

bits = bits2 & bits4;
if sum(bits) > 0
   shoGain(bits) = 0;
end

bits = bits1 & ~(bits3 | bits4);
if sum(bits) > 0
   shoGain(bits) = interp1(linkPerfTables.shoDifferences, sho_gain_table(:, 1), ...
                           deltaSHO(bits));
end

bits = bits2 & ~(bits3 | bits4);

if sum(bits) > 0
   shoGain(bits) = interp1(linkPerfTables.shoDifferences, sho_gain_table(:, m1), ...
                           deltaSHO(bits));
end

bits = bits3 & ~(bits1 | bits2);
if sum(bits) > 0
   shoGain(bits) = interp1(linkPerfTables.speeds, sho_gain_table(1, :), ...
                           speed(bits));
end

bits = bits4 & ~(bits1 | bits2);
if sum(bits) > 0
   shoGain(bits) = 0;
end

bits = ~(bits1 | bits2 | bits3 | bits4);

if sum(bits) > 0
   shoGain(bits) = interp2(linkPerfTables.speeds, linkPerfTables.shoDifferences, ...
                           sho_gain_table, speed(bits), deltaSHO(bits));
end
