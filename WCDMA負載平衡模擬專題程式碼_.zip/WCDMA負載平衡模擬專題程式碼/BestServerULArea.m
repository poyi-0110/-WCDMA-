%BESTSERVERULAREA   [NEEDEDMSTXPOWER BESTSERVER DOMINANCE] = BESTSERVERVULAREA(PERF, 
%                   LINKLOSS, MSMAXTXPOW, SPEED, BITRATE, ACTIVESETT)
%                   calculates dominance, best servers and MStxPowers in uplink to each
%                   pixel. Calculation is done by using the coverage threshold found in
%                   rlbul. This is corrected to the wanted bit-rate and MS speed assuming
%                   that perf.covth was for wideAreaCovSpeed and wideAreaCovR.
%				  
%Inputs:
%   PERF            : structure holding the performances of the BSs.
%   LINKLOSS        : (NumBSs * yPixels * xPixels) matrix holding the link loss of BS, 
%                     1...NumBSs, to the map pixels.
%   MSMAXTXPOW      : maximum transmit power of the mobiles (currently all mobiles have
%                     same max. TX power).
%   ACTIVESETT      : (k, j, i), k=1, ..., numBSs, j=1, ..., yPixels, i=1, ..., xPixels, matrix
%                     holding 1 if BS(k) is in the active set in pixel (j, i) and 0 if not.
%                     This is only if perchPowerSwitch == 3. Otherwise an empty matrix.
%	 SPEED:            The MS speed for which the calculations are done.
%	 BITRATE:          Bit-rate (service) that MS is using.
%Outputs:
%   NEEDEDMSTXPOWER : (xPixels x yPixels) matrix holding the minimum needed average 
%                     (over multi-path fading) transmit powers needed in each pixel, 999
%                     if outage.
%   BESTSERVER      : (xPixels x yPixels) matrix where element [i, j] is the best server
%                     at pixel (i, j), 0 if outage.
%   DOMINANCE       : (xPixels x yPixels) matrix where element [i, j] is signal strength
%                     from best server, -999 if outage
%Comment:
%   Best server in this context is that BS to which mobile has to transmit with the
%   smallest power.
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcMsEbNoUL.m, CalcMsHeadRoom.m, CalcShoGain.m, CalcVoiceActivityUL.m

function [neededMsTxPower, bestServer, dominance] = BestServerULArea(perf, linkloss, ...
                                                                     msMaxTxPower, speed, bitrate, ...
                                                                     activeSetT);

%Copy global variables
linkPerf        = evalin('base', 'linkPerf');
channels        = evalin('base', 'channels');
numChannels     = evalin('base', 'numChannels');
channelMap      = evalin('base', 'channelMap');
wideAreaCovEbNo = evalin('base', 'wideAreaCovEbNo');
wideAreaCovR    = evalin('base', 'wideAreaCovR');
W               = evalin('base', 'W');
Ueta            = evalin('base', 'Ueta');
BS_noise_power  = evalin('base', 'BS_noise_power');
xPixels         = evalin('base', 'xPixels');
yPixels         = evalin('base', 'yPixels');
numBStype1      = evalin('base', 'numBStype1');
numBStype2      = evalin('base', 'numBStype2');
numMStype1      = evalin('base', 'numMStype1');
numMStype2      = evalin('base', 'numMStype2');
indBStype1      = evalin('base', 'indBStype1');
indBStype2      = evalin('base', 'indBStype2');
indMStype1      = evalin('base', 'indMStype1');
indMStype2      = evalin('base', 'indMStype2');

ebNo = -999*ones(2, yPixels, xPixels);
v = ones(2, yPixels, xPixels);

for i1 = 1:numChannels
   if numBStype1
      ind1 = find(channelMap(1, :)==channels(i1));
      if (length(ind1) >= 1)
         ebNo(1, ind1) = CalcMsEbNoUL(linkPerf(channels(i1)), speed, bitrate);
         v(1, ind1) = CalcVoiceActivityUL(linkPerf(channels(i1)), bitrate);
      end  
   end
   if numBStype2
      ind1 = find(channelMap(2, :)==channels(i1));
      if (length(ind1) >= 1)
         ebNo(2, ind1) = CalcMsEbNoUL(linkPerf(channels(i1)), speed, bitrate);
         v(2, ind1) = CalcVoiceActivityUL(linkPerf(channels(i1)), bitrate);
      end   
   end   
end

numBSs = length(perf);

tmp = 1.0./(1+W./(bitrate*log2lin(ebNo).*v));
tmpDB = lin2log(tmp);

minNeededRxPower = zeros(size(linkloss));

if numBStype1
   for k = indBStype1
      minNeededRxPower(k, :, :) = squeeze(tmpDB(1, :, :))+ ...
                                  squeeze(BS_noise_power-lin2log(v(1, :, :)*(1-Ueta(k)))); 
   end
end

if numBStype2
   for k = indBStype2
      minNeededRxPower(k, :, :) = squeeze(tmpDB(2, :, :))+...
                                  squeeze(BS_noise_power-lin2log(v(2, :, :)*(1-Ueta(k)))); 
   end
end   
   
minNeededTxPower = minNeededRxPower+linkloss;
clear minNeededRxPower

%Put to 9999 those BS which are not in active set, for each pixel.
minNeededTxPower = activeSetT.*minNeededTxPower+9999*(~activeSetT);

if numBStype1
   [neededMsTxPower(1, :, :)  bestServer(1, :, :)] = min(minNeededTxPower(indBStype1, :, :), [], 1);
   bestServer(1, :, :) = indBStype1(bestServer(1, :, :));
end
if numBStype2
   [neededMsTxPower(2, :, :)  bestServer(2, :, :)] = min(minNeededTxPower(indBStype2, :, :), [], 1);
   bestServer(2, :, :) = indBStype2(bestServer(2, :, :));
end

if numBStype1
   tmp_i = mean([perf(indBStype1).i]);
   for k = indBStype1
      ind1 = find(bestServer(1, :)==k);
      if (length(ind1) >= 1)
         if (max(tmp(1, ind1))*(1+tmp_i) > Ueta(k))
            disp(['WARNING: The test MS could alone cause more loading that was simulated at BS ', num2str(k)])
         end
      end
   end
end

if numBStype2
   tmp_i = mean([perf(indBStype2).i]);
   for k = indBStype2
      ind1 = find(bestServer(2, :)==k);
      if (length(ind1) >= 1)
         if (max(tmp(2, ind1))*(1+tmp_i) > Ueta(k))
            disp(['WARNING: The test MS could alone cause more loading that was simulated at BS ', num2str(k)])
         end
      end
   end
end

%Put the needed TxPower of the best cell to large number to see the next bestserver
for k = indBStype1
   minNeededTxPower(k, find(bestServer(1, :, :)==k)) = 9999;
end
for k = indBStype2
   minNeededTxPower(k, find(bestServer(2, :, :)==k)) = 9999;
end

%The next best server
if numBStype1
   [tmpMsTxPower(1, :, :) tmpbestServer(1, :, :)] = min(minNeededTxPower(indBStype1, :, :), [], 1);
   tmpbestServer(2, :, :) = indBStype1(tmpbestServer(1, :, :));
end
if numBStype2
   [tmpMsTxPower(2, :, :) tmpbestServer(2, :, :)] = min(minNeededTxPower(indBStype2, :, :), [], 1);
   tmpbestServer(2, :, :) = indBStype2(tmpbestServer(2, :, :));
end

%Difference between best and next best server
deltaSHO = abs(tmpMsTxPower-neededMsTxPower);

headRoom = zeros([1, yPixels, xPixels]);
sHOgainPeak = zeros([1, yPixels, xPixels]);
for i1 = 1:numChannels
   ind1 = find(channelMap(1, :)==channels(i1));
   if (length(ind1) >= 1)
      % Required headRoom in transmitted power for multipath fading
		headRoom(1, ind1) = CalcMsHeadRoom(linkPerf(channels(i1)), speed);
      % SHO gain in headroom
      sHOgainPeak(1, ind1) = CalcShoGain(speed*ones(size(deltaSHO(1, ind1))), deltaSHO(1, ind1), linkPerf(channels(i1)), 3);
   end   
end

if numBStype2
   headRoom(2, :, :) = zeros([1, yPixels, xPixels]);
   sHOgainPeak(2, :, :) = zeros([1, yPixels, xPixels]);
   for i1 = 1:numChannels
      ind1 = find(channelMap(2, :)==channels(i1));
      if (length(ind1) >= 1)
         %Required headRoom in transmitted power for multipath fading
         headRoom(2, ind1) = CalcMsHeadRoom(linkPerf(channels(i1)), speed);
         %SHO gain in headroom
         sHOgainPeak(2, ind1) = CalcShoGain(speed*ones(size(deltaSHO(2, ind1))), deltaSHO(2, ind1), linkPerf(channels(i1)), 3);
      end   
   end
end   
   
%Checking outage
ind1 = find(neededMsTxPower+headRoom-sHOgainPeak > msMaxTxPower);

if numBStype1
   sHOgainRx = zeros([1, yPixels, xPixels]);
   for i1 = 1:numChannels
      ind2 = find(channelMap(1, :)==channels(i1));
      if (length(ind2) >= 1)
         %SHO gain in received EbNo
         sHOgainRx(1, ind2) = CalcShoGain(speed*ones(size(deltaSHO(1, ind2))), deltaSHO(1, ind2), linkPerf(channels(i1)), 1);
      end   
   end
end

if numBStype2
   sHOgainRx(2, :, :) = zeros([1, yPixels, xPixels]);
   for i1 = 1:numChannels
      ind2 = find(channelMap(2, :)==channels(i1));
      if (length(ind2) >= 1)
         %SHO gain in received EbNo
         sHOgainRx(2, ind2) = CalcShoGain(speed*ones(size(deltaSHO(2, ind2))), deltaSHO(2, ind2), linkPerf(channels(i1)), 1);
      end
   end
end
   
neededMsTxPower = neededMsTxPower-sHOgainRx;

neededMsTxPower(ind1) = +999;
bestServer(ind1) = 0;

%calculate the dominance only if there are 3 output arguments
if nargout == 3
   signalStrength = msMaxTxPower-linkloss;
   if numBStype1
      dominance(1, :, :) = max(signalStrength(indBStype1, :, :), [], 1);
   end
   if numBStype2
      dominance(2, :, :) = max(signalStrength(indBStype2, :, :), [], 1);
   end
   dominance1 = squeeze(dominance(1, :, :));
end
bestServer1 = squeeze(bestServer(1, :, :));
neededMsTxPower1 = squeeze(neededMsTxPower(1, :, :));
