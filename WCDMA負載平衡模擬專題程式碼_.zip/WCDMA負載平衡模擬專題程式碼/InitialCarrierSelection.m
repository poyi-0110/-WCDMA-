%INITIALCARRIERSELECTION   INITIALCARRIERSELECTION reselects the carrier for mobiles
%                          in multicarrier mode
%Input:
%   doInitialCarrierSelection: 1 = checks whether the MSs can hear the CPICH on the
%                                  initially assigned carrier from MS file. If not,
%                                  the other carrier is assigned in case it's CPICH
%                                  can be heard.
%                              2 = MSs reselect carrier with highest CPICH Ec/Io
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files:   None

if mode ~= 1
   error('Error - check mode !!!');
end

if doInitialCarrierSelection == 1
   for runType = 1:2
      tmpIndFromXToY = [];
      
      eval(['indBStypeX = indBStype' num2str(runType) ';']);
      eval(['indBStypeY = indBStype' num2str(mod(runType, 2)+1) ';']);
      
      tmpMsInd = find([mobilestation.usedCarr]==runType);
      
      if length(indBStypeX) >= 1 & length(tmpMsInd) >= 1
         %Find the highest CPICHEcIo 
         [tmpMaxEcIo, tmpMaxEcIoInd] = max(CPICHEcIoM(indBStypeX, tmpMsInd), [], 1);
         %Find the MS:s below the CPICHEcIoThreshold 
         tmpIndCPICHOutage = find(tmpMaxEcIo < CPICHEcIoThreshold);
         if length(tmpIndCPICHOutage >= 1)
            tmpIndCPICHOutage = tmpMsInd(tmpIndCPICHOutage);
            if length(indBStypeY) >= 1
               [tmpMaxEcIo, tmpMaxEcIoInd] = max(CPICHEcIoM(indBStypeY, tmpIndCPICHOutage), [], 1);
               tmpIndCPICHIntage = find(tmpMaxEcIo >= CPICHEcIoThreshold);
               if length(tmpIndCPICHIntage >= 1)
                  tmpIndFromXToY = tmpIndCPICHOutage(tmpIndCPICHIntage);
                  [mobilestation(tmpIndFromXToY).usedCarr] = deal(mod(runType, 2)+1);
               end
            end
         end
      end
   end
else 
   if doInitialCarrierSelection == 2 %Optimal selection
      [tmpMaxEcIo, tmpMaxEcIoInd] = max(CPICHEcIoM, [], 1);
      tmpUsedCarr = num2cell([basestation(tmpMaxEcIoInd).usedCarr]);
      [mobilestation.usedCarr] = deal(tmpUsedCarr{:});
   end
end

indMStype1 = find([mobilestation.usedCarr] == 1);
indMStype2 = find([mobilestation.usedCarr] == 2);
numMStype1 = length(indMStype1);
numMStype2 = length(indMStype2);

clear tmpMsInd tmpMaxEcIo tmpMaxEcIoInd tmpIndCPICHOutage tmpIndCPICHIntage
clear tmpIndFromXToY
