%NPSW   Network planning strategies for wideband CDMA
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil?(KSi),
%         Kari Heiska (KHe), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed  m-files: AdjustBsTxPowers.m         Calcm_RDL.m                DoIFHO.m
%                 AntPattern.m               Calcm_RUL.m                DoSaattohoito.m
%                 AntRead.m                  CheckCPICHCoverage.m       InitialCarrierSelection.m
%                 BSdefault.m                CreateChannelMap.m         InitializeIteration.m
%                 BSedit.m                   CreateLinkPerf.m           LPdist.m
%                 BSplot.m                   CreateLinklosses.m         MSgener3.m
%                 BSpos.m                    CreateTraf.m               MSread.m
%                 BSread.m                   DispBSconn.m               MSselect.m
%                 BSselect.m                 DispBestServDL.m           MSwrite.m
%                 BSshow.m                   DispBestServUL.m           PedALinkPerfTablesNew.m
%                 BStxPowAlloc.m             DispBsTxPower.m            PerfDefault.m
%                 BSwrite.m                  DispCCPCHCovParamMenu.m    PerfWrite.m
%                 BestServerDL.m             DispCPICHCovParamMenu.m    Poly1.m
%                 BestServerUL.m             DispCPICHCoverage.m        Polygon.m
%                 BestServerULArea.m         DispCarr.m                 PolygonGame.m
%                 CPICHPowerAlloc.m          DispCompCovUL.m            ReduceBStxPower.m
%                 CalcActiveSet.m            DispDLCovParamMenu.m       ReduceLinks.m
%                 CalcCoSited.m              DispDLEbNo.m               ReduceLoad.m
%                 CalcCovPCCPCH.m            DispD_SHO.m                RlbDL.m
%                 CalcCovPCPICH.m            DispGenericCov.m           RlbUL.m
%                 CalcCovPDL.m               DispLinkloss.m             SHOproba.m
%                 CalcCovPUL.m               DispLoad.m                 SaveResults.m
%                 CalcEcIoM.m                DispLoadOwn.m              Scaling.m
%                 CalcIntDL.m                DispMSTraceParamMenu.m     SelectServices.m
%                 CalcIntUL.m                DispMSconn.m               Trace.m
%                 CalcLinksPerService.m      DispMsRxPower.m            TwoTapLinkPerfTables.m
%                 CalcMStx.m                 DispMsTxPower.m            UpdateChannelMatrices.m
%                 CalcMsEbNoDL.m             DispPPMenu.m               VehALinkPerfTablesNew.m
%                 CalcMsEbNoUL.m             DispRxLev.m                lin2log.m
%                 CalcMsHeadRoom.m           DispSHO.m                  log2lin.m
%                 CalcMsSHOGainsDL.m         DispStatus.m               mapini.m
%                 CalcMsTxPowRaise.m         DispTraffic.m              mapwin.m
%                 CalcOrthogonality.m        DispULCovParamMenu.m       mob_inside.m
%                 CalcSHO.m                  DispULEbNo.m               npsw.m
%                 CalcSHO2.m                 DispUserAll.m              npswini.m
%                 CalcSHOarea.m              DispUserDeltaGeneric.m     npswsys.m
%                 CalcShoGain.m              DispUserInit.m             
%                 CalcSiteLinks.m            DispUserLeft.m             
%                 CalcThroughput.m           DispUserNotServed.m        
%                 CalcULPowerMap.m           DispUserServed.m
%                 CalcVoiceActivityDL.m      Disp_i.m
%                 CalcVoiceActivityUL.m      DistTraf.m
%
%needed mat-files: (optionally) mapfile, linklossfile, waterareafile, vectorfile         
%                               previousPolygon.mat, previousService.mat         
%
%WARNING!!! Runs only with Matlab 5.3 (Matlab Release R11), Matlab 6.0 (Matlab Release R12) preferred

%clear variables;

clear variables;
close all hidden;
format compact;

versio = version;
if ((str2num(versio(1)) < 5) & (str2num(versio(3) < 3)))
   error('Sorry, needs Matlab version 5.3 or higher, version 6.0 is preferred');
end

%initialise system parameters
npswsys;

%initialise general parameters
npswini;

acFilterUL  = -lin2log(log2lin(-aciFilterUL)+log2lin(-acpFilterUL));
acFilterDL  = -lin2log(log2lin(-aciFilterDL)+log2lin(-acpFilterDL));

%initialise map parameters
mapini;

%display main window
hMainWnd = mapwin;
axis('equal');
axis(area);
statusText = ('Initialising general parameters');
DispStatus(statusText);

%create map grid
xPixels = fix((xmax-xmin)/resolution)+1;
yPixels = fix((ymax-ymin)/resolution)+1;
[xx yy] = meshgrid(1:xPixels, 1:yPixels);
xx = (xx-1)*resolution+xmin;
yy = (yy-1)*resolution+ymin;

if (~exist('waterAreaFile') | isempty(waterAreaFile))
   waterArea = NaN*ones(yPixels, xPixels);
else
   load(waterAreaFile)
   waterArea = waterArea(1:end-1, 1:end-1);
end

%some more initialisation
randn('state',0); %randn('state',sum(100*clock));
rand('state',0);  %rand('state',sum(100*clock));
rxLevMin = -130;  %used for plot scaling only
lambda = 3e8/(frequency*1e6);

statusText = str2mat(statusText, 'Loading link performance tables');
DispStatus(statusText);
CreateLinkPerf;

%EbNoUL, UL and DL voice activity for wide area coverage parameters
wideAreaCovEbNo = CalcMsEbNoUL(wideAreaCovLinkPerf, wideAreaCovSpeed, wideAreaCovR);
vUL = CalcVoiceActivityUL(wideAreaCovLinkPerf, wideAreaCovR);
vDL = CalcVoiceActivityDL(wideAreaCovLinkPerf, wideAreaCovR);

statusText = str2mat(statusText, 'Loading BS data');
DispStatus(statusText);

%load base station parameters
try
   [basestation, numBSs, indBStype1, indBStype2, numBStype1, numBStype2] = BSread(...
      bsParamFile, pathlossModel, lossData, useImportedAntennaInfo, channelFiles, numBStype1, numBStype2, mode);
catch
   close all;
   errordlg(lasterr);
   return
end
currentBS = numBSs;
bsPosition = [[basestation.x]' [basestation.y]'];
if (numBSs)
   BSplot(basestation, hMainWnd, vectMap, lossData);
end

%XXX if wanted, here should go adjustment of the scenario and then replot

if numBStype1 == 0
   numMStype1 = 0;
   mode = 2;
   set(hMainWnd, 'Name', ['npsw 5.0.0 single carrier version - Main Map Window']);
end
if numBStype2 == 0
   numMStype2 = 0;
   mode = 2;
   set(hMainWnd, 'Name', ['npsw 5.0.0 single carrier version - Main Map Window']);
end

%create the default perf structure on the fly
defaultPerf = PerfDefault;

perf(1:numBSs) = defaultPerf;
numPerfs = numBSs;

%load user (mobile station) parameters
statusText = str2mat(statusText, 'Loading MS data');
DispStatus(statusText);
numMSs = numMStype1+numMStype2;
try
   MSread;
catch
   close all;
   errordlg(lasterr);
   return
end

%calculate the mobile location indices
xPos = fix(([mobilestation.x]-xmin)/resolution)+1;
yPos = fix(([mobilestation.y]-ymin)/resolution)+1;

%get all antennas in current directory
statusText = str2mat(statusText, 'Loading antenna data');
DispStatus(statusText);
antlist = dir('*.ant');
antlist = char(antlist.name);
antName = [];
for k = 1:size(antlist, 1)
   antName = strvcat(antName, strtok(antlist(k,:),'.'));
end

if (numBSs)
   BSplot(basestation, hMainWnd, vectMap, lossData);
end
DispStatus('To start simulation, hit <Calculate> !');
  uiwait(hMainWnd);

delete(findobj(hMainWnd, 'Label', '&BS Options'));

  delete(findobj(hMainWnd, 'Label', '&Calculate'));

delete(findobj(hMainWnd, 'Label', '&Display users'));

%adjust perf structures
if (numPerfs ~= numBSs)
   for (ii = numPerfs:numBSs)
      perf(ii) = PerfDefault;
   end
end
numPerfs = numBSs;

%create link losses
CreateLinklosses;

%create channel map and MS link performance fields.
DispStatus('Creating channel matrices');
msIndGeneric = 1:numMSs;
UpdateChannelMatrices;

%set sensitivity difference for different mobiles.
tmpvul = [mobilestation.vUL];
deltaSensitivity = lin2log(vUL*(1+W/(vUL*log2lin(wideAreaCovEbNo)*wideAreaCovR)) ...
                   ./(tmpvul.*(1+W./(tmpvul.*log2lin([mobilestation.EbNoUL]).*[mobilestation.RUL]))));
clear tmpvul;
                
InitializeIteration;

while (1)
   oldThreshold = [perf.covth];
   iteration = iteration+1
   text1 = str2mat(['UL iteration ' num2str(iteration)], text1(2:6, :));
   DispStatus(text1);
   
   %calculate uplink link budget
   indexHL = [];
   RlbUL;
  
   newThreshold = [perf.covth];
   
   deltaCTnew = abs(oldThreshold-newThreshold);
   disp(['max difference in threshold: ' num2str(max(abs(oldThreshold-newThreshold)))]);
   text1 = str2mat(text1(1, :), ['max difference in threshold: ' num2str(max(abs(oldThreshold-newThreshold)))], text1(3:6, :));
   DispStatus(text1);
   max(abs(deltaCTold-deltaCTnew));
      
   %calculate best server for each MS and the radio distance from the next best server.
   [msTxPowerV bestServerV deltaSHOV] = BestServerUL(perf, linklossULM, activeSetM);

   %Calculate the real transmitted power needed for each MS and check outage   
   outageULold = outageUL;
   CalcMStx;
      
   %calculate the received powers at BSs and the interference in UL -> perf.i
   CalcIntUL;  
   
   %display for BS number one
   disp('')
   disp(['i = ' num2str(perf(1).i*100) ' %']);
   text1 = str2mat(text1(1:2, :), ['i(1) = ' num2str(perf(1).i*100) ' %'], text1(4:6, :));
   DispStatus(text1)
   
   %Downlink 
   text1 = str2mat(text1(1:4, :), ['DL iteration ' num2str(iteration)], text1(6, :));
   DispStatus(text1)
        
   %Calculate C/I
   CalcIntDL;
         
   %Calculate the SHO gains in DL
   CalcMsSHOGainsDL;
   
   %calculate the difference in target and actual C/I
   deltaCI = targetCI-msSHOGainsDL-C_over_I;
   
   disp(['maximum difference in C/I: ' num2str(max(abs(deltaCI)))]);
   text1 = str2mat(text1(1:5, :), ['maximum difference in C/I: ' num2str(max(abs(deltaCI)))]);
   DispStatus(text1);
   
   %break criterion
   if (((max(deltaCTnew) <= limitCT | max(abs(deltaCTold-deltaCTnew)) < limitDeltaCT) & ...
       (iteration>1) & (~loadJustReduced) & (max(outageUL-outageULold) == 0) & ...
       (sum(hardBlockCells) == 0 | hardBlocking == 0)) & ...
       ((max(abs(deltaCI)) < limitCI) | (max(abs(deltaCI-deltaCIold)) < limitDeltaCI)))
      break
   end
   
   AdjustBsTxPowers;
   
   deltaCTold = deltaCTnew;
   deltaCIold = deltaCI;
end

DispStatus('Doing the post processing');
calcPixel = 1;
CalcActiveSet;
CreateTraf;
Calcm_RUL;
Calcm_RDL;
CreateChannelMap;

%Once more to see widearea cov.
[msTxPower bestServer dominance] = BestServerULArea(perf, linklossUL, wideAreaCovMsTxMax, ...
                                                    wideAreaCovSpeed, wideAreaCovR, activeSetT);

%clear not anymore needed variables
clear outageULold bsRxPowerLin IownUL IothUL calcPixel
close(findobj(allchild(0), 'flat', 'Tag', 'tagStatus'));

%Calculate Noise rise
noiseRiseDL = lin2log((sum(IownDL+IothDL)+MS_noise_power_lin)/MS_noise_power_lin);

%save results (specified in SaveResults.m)
SaveResults;

DispPPMenu(hMainWnd, numBSs);
DispStatus('Ready');
