% CALCSITELINKS   Calculates the number of links per site and adds a site ID to the
%                 basestation structure
% 
%Authors: Kari Heiska (KHe), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

tempzer = find([mobilestation(:).usedCarr] < 1);
linksUplink(:, tempzer) = zeros(numBSs, length(tempzer));
noUsers = sum(linksUplink, 2);
hardBlockCells = zeros(1, numBSs);
sites = zeros(1, numBSs);
ii = 0;
for k = 1:numBSs
   if sites(k) == 0
      ii = ii+1;
      for l = 1:numBSs
         if (basestation(l).x == basestation(k).x) & ...
            (basestation(l).y == basestation(k).y)
            sites(l) = ii;
         end
      end
   end
end

[basestation.channels] = deal(basestationChannels);

for site_ind = 1:length(sites)
   cell_ind = find(sites == site_ind);
   hardBlockCells(cell_ind) = sum(noUsers(find(sites == site_ind))) > sum([basestation([find(sites == site_ind)]).channels]);
end

for ii = 1:numBSs
   basestation(ii).site = sites(ii);
end

clear sites noUsers tempzer cell_ind site_temp site_ind ii
