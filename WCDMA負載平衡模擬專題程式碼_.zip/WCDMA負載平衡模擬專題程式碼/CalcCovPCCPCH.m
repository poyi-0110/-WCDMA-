%CALCCOVPCCPCH   CALCCOVPCCPCH calculates the coverage probability (Eb/Nt) for channels mapped on the
%                primary or secondary CCPCH
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

if (~exist('tmpCcpchEbNtThreshold'))
   tmpCcpchEbNtThreshold = bchEbNo;
end

if (~exist('tmpCcpchCpichOffset'))
   tmpCcpchCpichOffset = bchCpichOffset;
end

if (~exist('tmpCovTarget'))
   tmpCovTarget = 95;
end

if (~exist('tmpBitRate'))
   tmpBitRate = bchBitRate;
end

tmpLayerVector = [];

if numBStype1
   tmpLayerVector = [tmpLayerVector, 1];
end

if numBStype2
   tmpLayerVector = [tmpLayerVector, 2];
end

tmpProcessingGain = 10*log10(W/tmpBitRate);

tmpNumLayers = length(tmpLayerVector);

if (mode == 1 & tmpNumLayers == 2)
   answer = questdlg(['Separate analysis for the ', num2str(tmpNumLayers), ' layers?'], ' ', 'Yes', 'No', 'Yes');
   tmpSeparateAnalysis = strcmp(answer, 'Yes');
else
   tmpSeparateAnalysis = 1;
end

if tmpNumLayers > 1
   if mode == 1
      layerStr = ' of Carrier ';
   else
      layerStr = ' of Operator ';
   end
else
   layerStr = '';
end

ccpchPowervec = log2lin([basestation.CPICHPower]-tmpCcpchCpichOffset);

for layer = tmpLayerVector
   ccpchEbNt = zeros(yPixels, xPixels);
   IownPDL   = zeros(yPixels, xPixels);
   IothPDL   = zeros(yPixels, xPixels);
   ItotPDL1  = zeros(yPixels, xPixels);
   ItotPDL2  = zeros(yPixels, xPixels);
   
   bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2)+ ...
                     log2lin([basestation.CPICHPower]')+ ...
                     log2lin([basestation.commonChannelOther]');
   
   bestServDL1 = squeeze(bestServDL(layer, :, :));
      
   %Calculation of CPICH Eb/Nt and BCCH Eb/Nt to each pixel
   
   if layer == 1
      if (numBStype2)               
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1)+...
            log2lin(-acFilterDL(channelOffset))*sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      else 
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1));
      end
   else      
      if (numBStype1)              
         ItotPDL1 = squeeze(log2lin(-acFilterDL(channelOffset))*sum(repmat(bsTxPowerTotLin(indBStype1), [1 yPixels xPixels])./log2lin(linklossDL(indBStype1, :, :)), 1)+...
            sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      else
         ItotPDL1 = squeeze(sum(repmat(bsTxPowerTotLin(indBStype2), [1 yPixels xPixels])./log2lin(linklossDL(indBStype2, :, :)), 1));
      end
   end
      
   [hlpx, hlpy] = meshgrid([1:xPixels], [1:yPixels]);
   bestServInd_3D = (hlpx-1)*numBSs*yPixels+(hlpy-1)*numBSs+bestServDL1;
   
   %NOTE orthogonality is calculated here for wideAreaCovSpeed.
   orthFactormat = zeros(yPixels, xPixels);
   for i1 = 1:numChannels
      ind1 = find(channelMap(layer, :)==channels(i1));
      if (length(ind1) >= 1)   
         orthFactormat(ind1) = CalcOrthogonality(linkPerf(channels(i1)), wideAreaCovSpeed);
      end
   end
   
   ccpchPowermat = ccpchPowervec(bestServDL1);
    
   P1 = bsTxPowerTotLin(bestServDL1);
   IownPDL = (1-orthFactormat).*P1./log2lin(linklossDL(bestServInd_3D));
   %IothPDL here includes already interference from second operator
   IothPDL = ItotPDL1-bsTxPowerTotLin(bestServDL1)./log2lin(linklossDL(bestServInd_3D));
   
   %Wideband interference:
   ItotPDL1 = ItotPDL1+MS_noise_power_lin;
   %Narrowband interference:
   ItotPDL2 = IownPDL+IothPDL+MS_noise_power_lin;
      
   ccpchEbNt = ccpchPowermat./log2lin(linklossDL(bestServInd_3D))./ItotPDL2;
   ccpchEbNt = lin2log(ccpchEbNt)+tmpProcessingGain;
      
   clear hlpx hlpy bestServInd_3D orthFactormat ccpchPowermat
   
   if ~tmpSeparateAnalysis
      if layer == 1
	      ccpchEbNt1 = ccpchEbNt;
      else
         ccpchEbNt2 = ccpchEbNt;
      end
   else
      lowerLimit = tmpProcessingGain-25;
      upperLimit = tmpProcessingGain;
      
      if layer == 1
         [tmphcf, tmphcb] = DispGenericCov(ccpchEbNt, tmpCcpchEbNtThreshold, 'CCPCH E_b/N_t', ...
                                           mode, layer, lossData, basestation, vectMap, ...
                                           waterArea, resolution, xmin, ymin, xmax, ymax, numBStype2, ...
                                           lowerLimit, upperLimit);
      else
         [tmphcf, tmphcb] = DispGenericCov(ccpchEbNt, tmpCcpchEbNtThreshold, 'CCPCH E_b/N_t', ...
                                           mode, layer, lossData, basestation, vectMap, ...
                                           waterArea, resolution, xmin, ymin, xmax, ymax, numBStype1, ...
                                           lowerLimit, upperLimit);
      end
      
      [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
      
      if (totA <= 0)
         disp('Warning: Zero area coverage probability calculation.');
         ccpchEbNtCovP = 1;
         clear ccpchEbNt IownPDL ItotPDL1 ItotPDL2 IothPDL;
         clear totA inplgn plgn;
         return
      end
      
      isNotCovered = inplgn.*(ccpchEbNt < tmpCcpchEbNtThreshold);
      ccpchEbNtCovP = 1-sum(sum(isNotCovered))/totA;
      
      figure(tmphcf);
      
      xlabel(['CCPCH E_b/N_t threshold: ', num2str(tmpCcpchEbNtThreshold), ' dB    ', ...
              'CCPCH E_b/N_t coverage: ', num2str(fix(10000*ccpchEbNtCovP)/100), ' %']);
      hold on
      plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 1.5);
      hold off
      
      tmpCovVector = ccpchEbNt(find(inplgn(:)));
      tmpT=(1:length(tmpCovVector))/length(tmpCovVector);
      tmpCovVector = sort(tmpCovVector);
      [tmpClosest, tmpClosestInd] = min(abs(tmpT-(1-tmpCovTarget/100)));
      tmpCorrection = tmpCcpchEbNtThreshold-tmpCovVector(tmpClosestInd);
      layerNum = '';
      if tmpNumLayers > 1
         layerNum = num2str(layer);
      end
      if tmpCorrection >= 0
         disp(['CCPCH powers', layerStr, layerNum, ' should be increased approx. by ', num2str(tmpCorrection), ' dBs to achieve the target cov. P.']); 
      else
         disp(['CCPCH powers', layerStr, layerNum, ' should be decreased approx. by ', num2str(-tmpCorrection), ' dBs to achieve the target cov. P.']); 
      end   
      
      figure;
      plot(tmpCovVector, tmpT);
      grid
      hold on
      tmpA = axis;
      tmpA(1) = max(-30+tmpProcessingGain, tmpA(1));
      axis(tmpA);
      tmpH1 = plot([tmpA(1) tmpCovVector(tmpClosestInd) tmpCovVector(tmpClosestInd)], ...
                   [1-tmpCovTarget/100 1-tmpCovTarget/100 tmpA(3)], 'r-');
      tmpH2 = plot([tmpA(1) tmpCcpchEbNtThreshold tmpCcpchEbNtThreshold], [1-ccpchEbNtCovP 1-ccpchEbNtCovP tmpA(3)], 'g-');
      legend([tmpH1; tmpH2], ['CCPCH E_b/N_t at target cov. P (' num2str(tmpCovTarget) '%)'], ...
                             ['CCPCH cov. P at CCPCH cov. threshold (' num2str(tmpCcpchEbNtThreshold) ' dB)'], 2);
      tmpH3 = text(0.5+tmpCovVector(tmpClosestInd), (1-tmpCovTarget/100)/2, [num2str(round(100*(tmpCovVector(tmpClosestInd)))/100) ' dB']);
      set(tmpH3, 'Color', 'r');
      tmpH4 = text(tmpA(1), 1-ccpchEbNtCovP, num2str(round(1000*(1-ccpchEbNtCovP))/1000));
      set(tmpH4, 'Color', 'g', 'horizontalAlignment', 'right');

      xlabel('CCPCH E_b/N_t (dB)');
      ylabel('P(CCPCH E_b/N_t < abscissa)')
      title(['CDF of CCPCH E_b/N_t ', layerStr, layerNum]);
      hold off
      
      clear ccpchEbNt ItotPDL1 isNotCovered xx1 yy1 ind11
      clear totA inplgn plgn answer
      clear orthFactorvec orthFactormat ccpchPowermat
   end
end

if ~tmpSeparateAnalysis
   layer = 0;
   ccpchEbNt = max(ccpchEbNt1, ccpchEbNt2);
   clear ccpchEbNt1 ccpchEbNt2
   lowerLimit = tmpProcessingGain-25;
   upperLimit = tmpProcessingGain;
   [tmphcf, tmphcb] = DispGenericCov(ccpchEbNt, tmpCcpchEbNtThreshold, 'CCPCH E_b/N_t', ...
                                     mode, layer, lossData, basestation, vectMap, ...
                                     waterArea, resolution, xmin, ymin, xmax, ymax, ...
                                     numBStype2, lowerLimit, upperLimit);
      
   [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
      
   if (totA <= 0)
      disp('Warning: Zero area coverage probability calculation.');
      ccpchEbNtCovP = 1;
      clear ccpchEbNt IownPDL ItotPDL1 ItotPDL2 IothPDL;
      clear totA inplgn plgn;
      return
   end
   
   isNotCovered = inplgn.*(ccpchEbNt < tmpCcpchEbNtThreshold);
   ccpchEbNtCovP = 1-sum(sum(isNotCovered))/totA;
   
   figure(tmphcf);
   
   xlabel(['CCPCH E_b/N_t threshold: ', num2str(tmpCcpchEbNtThreshold), ' dB    ', ...
           'CCPCH E_b/N_t coverage: ', num2str(fix(10000*ccpchEbNtCovP)/100), ' %']);
   hold on
   plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 1.5);
   hold off
   
   tmpCovVector = ccpchEbNt(find(inplgn(:)));
   tmpT = (1:length(tmpCovVector))/length(tmpCovVector);
   tmpCovVector = sort(tmpCovVector);
   [tmpClosest, tmpClosestInd] = min(abs(tmpT-(1-tmpCovTarget/100)));
   tmpCorrection = tmpCcpchEbNtThreshold-tmpCovVector(tmpClosestInd);
   if tmpCorrection >= 0
      disp(['CCPCH powers should be increased approx. by ', num2str(tmpCorrection), ' dBs to achieve the target cov. P.']); 
   else
      disp(['CCPCH powers should be decreased approx. by ', num2str(-tmpCorrection), ' dBs to achieve the target cov. P.']); 
   end   
   
   figure;
   plot(tmpCovVector, tmpT);
   grid
   hold on
   tmpA = axis;
   tmpA(1) = max(-30+tmpProcessingGain, tmpA(1));
   axis(tmpA);
   tmpH1 = plot([tmpA(1) tmpCovVector(tmpClosestInd) tmpCovVector(tmpClosestInd)], ...
                [1-tmpCovTarget/100 1-tmpCovTarget/100 tmpA(3)], 'r-');
   tmpH2 = plot([tmpA(1) tmpCcpchEbNtThreshold tmpCcpchEbNtThreshold], [1-ccpchEbNtCovP 1-ccpchEbNtCovP tmpA(3)], 'g-');
   
   legend([tmpH1; tmpH2], ['CCPCH E_b/N_t at target cov. P (' num2str(tmpCovTarget) '%)'], ...
                          ['CCPCH cov. P at CCPCH cov. threshold (' num2str(tmpCcpchEbNtThreshold) ' dB)'], 2);
   tmpH3 = text(0.5+tmpCovVector(tmpClosestInd), (1-tmpCovTarget/100)/2, [num2str(round(100*(tmpCovVector(tmpClosestInd)))/100) ' dB']);
   set(tmpH3, 'Color', 'r');
   tmpH4 = text(tmpA(1), 1-ccpchEbNtCovP, num2str(round(1000*(1-ccpchEbNtCovP))/1000));
   set(tmpH4, 'Color', 'g', 'horizontalAlignment', 'right');

   xlabel('CCPCH E_b/N_t (dB)');
   ylabel('P(CCPCH E_b/N_t < abscissa)')
   title(['CDF of CCPCH E_b/N_t, combined for all carriers']);
   hold off
   
   clear ccpchEbNt IownPDL ItotPDL1 ItotPDL2 IothPDL;
   clear isNotCovered xx1 yy1 ind11
   clear totA inplgn plgn answer
   clear orthFactorvec orthFactormat ccpchPowermat
end
