%CREATELINKLOSSES   CREATELINKLOSSES either calculates the linkloss matrices or loads precalculated data.
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil?(KSi)
%         Kari Heiska (KHe),  Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed  m-files: CalcCosited.m, AntPattern.m, AntRead.m

%pre-allocate most of the memory
pathloss    = zeros(yPixels, xPixels);
pathloss1   = zeros(yPixels, xPixels);
linkloss    = zeros(numBSs, yPixels, xPixels);
linklossUL  = zeros(numBSs, yPixels, xPixels);
linklossDL  = zeros(numBSs, yPixels, xPixels);
linklossULM = zeros(numBSs, numMSs);
linklossDLM = zeros(numBSs, numMSs);

%calculate the pathloss according the OH model - at the moment, some parameters
%are fixed (frequency, MS height) for execution speed reasons
DispStatus('Creating link losses');
%hwb = waitbar(0, 'Creating path and link losses ...');

a = sqrt(siteCorr);
b = sqrt(abs(sectCorr-siteCorr));
c = sqrt(1-a*a-b*b);

%find cosited BSs in case fading is added
if sigmaLogNorm
   isCosited = CalcCoSited(basestation);
   [dummy lowestCosited] = max(isCosited, [], 1);
   for k = 1:numBSs
      if k == lowestCosited(k)
         linkloss(k, :, :) = b.*sigmaLogNorm*randn(yPixels, xPixels);
      else
         linkloss(k, :, :) = linkloss(lowestCosited(k), :, :);
      end
   end
end

shadowing1 = a.*sigmaLogNorm*randn(yPixels, xPixels);    %corr. part of shadowing

for k = 1:numBSs
  % waitbar(k/numBSs);
   
   if (sigmaLogNorm)
      shadowing3 = c.*sigmaLogNorm*randn(yPixels, xPixels); %uncorr. part of shadowing
   end
   
   distance = sqrt((xx-basestation(k).x).^2+(yy-basestation(k).y).^2)+1; %+1 -> no log(0)
   if (sigmaLogNorm)
      pathloss = shadowing1+shadowing3+area_correction;
   else
      pathloss = area_correction;
   end
   
   switch pathlossModel,
   case 1,
      %OH
      pathloss1 = 158.235-13.82*log10(basestation(k).antennaHeight) + ...
                  (44.9-6.55*log10(basestation(k).antennaHeight))*log10(distance/1000);
   case 2,
      %UMTS 30.03 models: pedestrian eli micro
      pathloss1 = 40*log10(distance/1000) + 30*log10(frequency)+49;
   case 3,
      %UMTS 30.03 models: vehicular_a eli macro
      pathloss1 = 40*(1-4e-3*deltaHb)*log10(distance/1000)- ...
                  18*log10(deltaHb)+21*log10(frequency)+80;
   case 4,
      % dto. for deltaHb = 15m, f = 2000MHz
      pathloss1 = 128.1+37.6*log10(distance/1000);
   case 5,
      %OH with bsHeight = 35m
      pathloss1 = 136.866+34.786*log10(distance/1000);
   case 6,
      %for testing only (path loss exponent = 4):
      pathloss1 = 136.866+40*log10(distance/1000);
   case {7, 8}
      pathloss1 = flipud(lossData(k).totloss);
   end
   pathloss = pathloss+pathloss1;
   freeLoss = 20*log10(4*pi*sqrt(basestation(k).antennaHeight^2 + distance.^2)/lambda);
   pathloss = max(pathloss, freeLoss);
   
   %calculate link loss (path loss including antenna gains and other losses)
   %and received power from each basestation at each map pixel
   %(common MS gains and losses are assumed here)
   
   if ((pathlossModel ~= 7) & (pathlossModel ~= 8))
      antFile  = [basestation(k).antennaType '.ant'];
      [basestation(k).antennaGain antenna1] = AntRead(antFile);
      antLoss = AntPattern(basestation(k), xx, yy, antenna1);
      linkloss(k, :, :) = squeeze(linkloss(k, :, :))+pathloss+ ...
                          mobilestationBodyLoss-mobilestationAntennaGain+ ...
                          basestation(k).cableLosses-basestation(k).antennaGain+antLoss;
   else %imported case
      if lossData(k).model == 3  %microcellular model 
         linkloss(k, :, :) = squeeze(linkloss(k, :, :))+pathloss+ ...
                             basestation(k).cableLosses+mobilestationBodyLoss- ...
                             mobilestationAntennaGain;
      else
      %if isotropical antenna used in the external tool then the antenna pattern is read from 
      %the basestation-file   !!! ckeck the gains!!! if lossData(k).Ga  != 0 don't use
      %basestaion(k).antennaGain
         antFile  = [basestation(k).antennaType '.ant'];
         [basestation(k).antennaGain antenna1] = AntRead(antFile);
         antLoss = AntPattern(basestation(k), xx, yy, antenna1);
         linkloss(k, :, :) = squeeze(linkloss(k, :, :))+pathloss+...
                             mobilestationBodyLoss-mobilestationAntennaGain+ ...
                             basestation(k).cableLosses-basestation(k).antennaGain+antLoss;
      end;
   end;
   linklossUL(k, :, :) = linkloss(k, :, :)-basestation(k).mhaGain;
   linklossDL(k, :, :) = linkloss(k, :, :)-basestation(k).rfHeadGain;
   linklossULM(k, :)   = linklossUL(k, (xPos-1)*yPixels+yPos);         
   linklossDLM(k, :)   = linklossDL(k, (xPos-1)*yPixels+yPos);         
end

%clear not anymore needed variables
clear pathloss pathloss1 antLoss antFile antenna1 freeLoss distance shadowing1 shadowing3 linkloss

%close(hwb);
drawnow
