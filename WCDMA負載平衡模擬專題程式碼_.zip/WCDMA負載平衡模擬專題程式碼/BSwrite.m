%BSWRITE   BSWRITE(BASESTATION, FILENAME) writes base stations to parameter file
%
%Inputs:
%   BASESTATION: array of base station structures to be saved
%   FILENAME   : name of the output file (optional, default=BSparam.txt)
%Outputs:
%   none
%
%Author : Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function BSwrite(basestation, bsFilename)

if (nargin == 0)
   bsFilename = 'BSparam.txt';
end

if (exist(bsFilename) == 2)
   bakName = strcat(strtok(bsFilename, '.'), '.bak');
   if (computer == 'PCWIN')
      command = ['copy ' bsFilename ' ' bakName ' > NUL'];
      dos(command);
   elseif (computer == 'HP900')
      command = ['cp ' bsFilename ' ' bakName];
      unix(command);
   else
      %add here possible other systems and their specific command
   end
end

bsFID = fopen(bsFilename, 'w');

numBSs = length(basestation);
fprintf(bsFID, '%s\n', 'xPos	yPos	groundHeight	antHeight	txMaxPower	txMaxPowerPerLink	txMinPowerPerLink	pTxDLAbsMax	CPICHPower	commonChannelOther	CPICHToRefRabOffset	antType	antDir	antTilt	cableLosses	channel	windowADD	numCarr  usedCarr excessLoadOwn	excessLoadTotal');
for k = 1:numBSs
   fprintf(bsFID, '%7.2f\t', basestation(k).x);
   fprintf(bsFID, '%7.2f\t', basestation(k).y);
   fprintf(bsFID, '%d\t', basestation(k).groundHeight);
   fprintf(bsFID, '%d\t', basestation(k).antennaHeight);
   fprintf(bsFID, '%5.2f\t', basestation(k).txMaxPower);
   fprintf(bsFID, '%5.2f\t', basestation(k).txMaxPowerPerLink);
   fprintf(bsFID, '%5.2f\t', basestation(k).txMinPowerPerLink);
   fprintf(bsFID, '%5.2f\t', basestation(k).pTxDLAbsMax);
   fprintf(bsFID, '%5.2f\t', basestation(k).CPICHPower);
   fprintf(bsFID, '%5.2f\t', basestation(k).commonChannelOther);
   fprintf(bsFID, '%5.2f\t', basestation(k).CPICHToRefRabOffset);
   fprintf(bsFID, '%8s\t', basestation(k).antennaType);
   fprintf(bsFID, '%5.2f\t', basestation(k).antennaDir);
   fprintf(bsFID, '%5.2f\t', basestation(k).antennaTilt);
   fprintf(bsFID, '%5.2f\t', basestation(k).cableLosses);
   fprintf(bsFID, '%5.2f\t', basestation(k).mhaGain);
   fprintf(bsFID, '%5.2f\t', basestation(k).rfHeadGain);
   fprintf(bsFID, '%d\t', basestation(k).channel);
   fprintf(bsFID, '%5.2f\t', basestation(k).WINDOW_ADD);
   fprintf(bsFID, '%d\t',  basestation(k).numCarr);
   fprintf(bsFID, '%d\t',  basestation(k).usedCarr);
   fprintf(bsFID, '%5.2f\t', basestation(k).excessLoadOwn);
   fprintf(bsFID, '%5.2f\n', basestation(k).excessLoadTotal);
end
fclose(bsFID);
return
