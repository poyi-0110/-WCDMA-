%BESTSERVERDL   [CPICHLEVEL BESTSERVDL CPICHSTRENGTH BESTSERVDLV] = BESTSERVERDL(BASESTATION, LINKLOSS)
%               calculates best servers for DL, CPICH level (strongest) and CPICH strength
%               (all)
%
%Inputs:
%   BASESTATION  : array of structures holding BS info
%   LINKLOSS     : 3 dim matrix holding the linkloss from each BS to each pixel
%Outputs:
%   CPICHLEVEL   : (yPixels x xPixels) matrix where element [i, j] is signal strength from
%                  the maximum received CPICH
%   BESTSERVDL   : (yPixels x xPixels) matrix where element [i, j] is best server at pixel
%                  (i, j)
%   CPICHSTRENGTH: (numBSs x yPixels x xPixels) matrix where element [k, i, j] is the 
%                  level of the CPICH from BS k at pixel (i, j)
%   BESTSERVDLV  : vector with the best server DL for all MSs
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function [CPICHLevel, bestServDL, CPICHStrength, bestServDLV] = BestServerDL(basestation, linkloss);

numMSs     = evalin('base', 'numMSs');
xPos       = evalin('base', 'xPos');
yPos       = evalin('base', 'yPos');
indMStype1 = evalin('base', 'indMStype1');
indMStype2 = evalin('base', 'indMStype2');
indBStype1 = evalin('base', 'indBStype1');
indBStype2 = evalin('base', 'indBStype2');

CPICHStrength = zeros(size(linkloss));
bestServDLV   = zeros(1, numMSs);

for k = 1:length(basestation)
   CPICHStrength(k, :, :) = basestation(k).CPICHPower-linkloss(k, :, :);
end

for k = 1:2
   eval(['indBStypeX = indBStype' num2str(k) ';']);
   eval(['indMStypeX = indMStype' num2str(k) ';']);
   if ~isempty(indBStypeX)
      %calculate the received CPICH level and bestServDL for each pixel
      [CPICHLevel(k, :, :) bestServDL(k, :, :)] = max(CPICHStrength(indBStypeX, :, :), [], 1);
      bestServDL(k, :, :) = indBStypeX(squeeze(bestServDL(k, :, :)));
      %calculate the bestServDL for each mobile
      for m = indMStypeX
         bestServDLV(m) = bestServDL(k, yPos(m), xPos(m));
      end
   end
end
