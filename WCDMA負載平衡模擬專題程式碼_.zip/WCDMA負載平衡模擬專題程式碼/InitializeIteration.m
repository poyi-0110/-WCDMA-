%INITIALIZEITERATION   INITIALIZEITERATION initializes uplink and downlink iterations
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BestServerDL.m, BStxPowAlloc.m, CalcEcIoM.m, CalcSHO2.m, CPICHPowerAlloc.m,
%                RlbDL.m, InitialCarrierSelection.m, DispStatus.m 

DispStatus('Allocating memory');
IownUL         = zeros(1, numBSs);
IothUL         = zeros(1, numBSs);
IothOpUL       = zeros(1, numBSs);
outageUL       = zeros(1, numMSs);
outageULold    = zeros(1, numMSs);
outageCPICH    = zeros(1, numMSs);
linksUplink    = zeros(numBSs, numMSs);
hardBlockCells = [];
ifhoCounter    = zeros(1, numMSs);
addCarrNeeded  = zeros(1, numBSs);

%allocate CPICH powers
basestation = CPICHPowerAlloc(basestation, perf, maxCPICHPower, CPICHPowerSwitch);      

%calculate best server in DL, max CPICH level (CPICHLevel) and all CPICH levels (CPICHStrength)
[CPICHLevel, bestServDL, CPICHStrength, bestServDLV] = BestServerDL(basestation, linklossDL);

%calculate mobilestation sensitivities
RlbDL;

msIndGeneric = (1:numMSs);
bsTxPower = zeros(numBSs, numMSs);
CalcEcIoM;

if mode == 1 & doInitialCarrierSelection >= 1
   InitialCarrierSelection;
end
   
CalcSHO2;

%Allocate TX power of the BSs to each MS
BStxPowAlloc;

targetCI = [mobilestation.EbNoDL]+lin2log([mobilestation.RDL]/W);

%if MS in outage, set targetCI = 0
targetCI(find([mobilestation.usedCarr] < 1)) = 0;

text1 = str2mat(' ', ' ', ' ', ' ', ' ', ' ');
iteration  = 0;
deltaCTold = 999;
deltaCIold = 10000*ones(1, numMSs);
