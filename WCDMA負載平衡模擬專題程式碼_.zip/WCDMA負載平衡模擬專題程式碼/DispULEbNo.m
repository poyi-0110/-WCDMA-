%DISPULEBNO   DISPULEBNO displays the UL Eb/Noss of iterated MS after DL iteration as a histogram
%
%Inputs:
%Outputs:
%
%Authors: Kari Sipil?(KSi), Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: lin2log.m, log2lin.m

v_tmp = [mobilestation.vUL]';
tmpPerm = eye(numBSs);
tmpPerm = tmpPerm(:, bestServerV);

v_tmp = [mobilestation.vUL]';
bsRxPowerLinV =       (log2lin(-linklossULM).*tmpPerm)*(v_tmp.*log2lin(msTxPowerV)'.*(usedCarrV==1)');
bsRxPowerLinRaisedV = (log2lin(-linklossULM).*(~tmpPerm)) * ...
                      (v_tmp.*log2lin(msTxPowerRaisedV)'.*(usedCarrV >= 1')');
bsRxPowerLinV1 =     (((log2lin(-linklossULM)+log2lin(-100)).*tmpPerm)*(v_tmp.*log2lin(msTxPowerV)'.*(usedCarrV==1)'))';

%bsRxPowerLinVn=(log2lin(-linklossULM).*tmpPerm)*(usedCarrV==1)'
clear v_tmp;

% If there is no own cell interference, perf.i will remain zero
IownUL = bsRxPowerLinV';
IothUL = bsRxPowerLinRaisedV';

for i1 = 1:numMSs
	tmpMsRxPower(i1)=log2lin([mobilestation(i1).txPower]-linklossULM(bestServerV(i1),i1));
end

ulEbNo = lin2log(W./[mobilestation.RUL].*tmpMsRxPower)-...
         lin2log(IownUL(bestServerV)-tmpMsRxPower+IothUL(bestServerV)+log2lin(BS_noise_power));

tmpN = hist(ulEbNo,-5:1:20);
%figure
%bar(-5:1:20, tmpN);
%xlabel('UL Eb/No');
%ylabel('Number of MSs');
%grid

%clear tmpPerm tmpMsRxPower tmpN
