%DISPRXLEV   DISPRXLEV displays the reception level from all MSs at BS 'wantedBS'
%
%Inputs:
%   none, evaluates in Matlab workspace
%Outputs:
%   none
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed functions: CalcULPowerMap.m, BSplot.m

if (~exist('bsRxPower'))
   bsRxPower    = zeros(numBSs, yPixels, xPixels);
   bsRxPowerLin = zeros(numBSs, yPixels, xPixels);
   CalcULPowerMap;
end

maxLev = -100;

for wantedBS = wantedBSs
   figure
   bsRxPower1 = squeeze(bsRxPower(wantedBS, :, :));
   ind1 = find(indBStype2 == wantedBS);
   if ~isempty(ind1)
      usertmp = squeeze(user(2,:,:));
   else 
      usertmp = squeeze(user(1,:,:));
   end
   bsRxPower1(find(bsRxPower1 < maxLev-63)) = maxLev-63;
   bsRxPower1(find(usertmp == 0)) = maxLev-64;
   bsRxPower1(~isnan(waterArea)) = NaN;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          bsRxPower1)
   colors1 = jet(64);
   colors1(1, :) = [1 1 1];
   colormap(colors1);
   caxis([maxLev-64 maxLev]);
   hcb = colorbar('vert');
   axis('equal');
   if mode == 1
      layerString  = [' carrier '];
      layerString1 = ['CA'];
   elseif mode == 2
      layerString  = [' operator '];
      layerString1 = ['OP'];
   end
   if (numBStype2 > 0 & numBStype1 > 0)
      if ismember(wantedBS, indBStype1)
         layer = 1;
      else
         layer = 2;
      end
   else
      layer = 1;
   end
   header = ['Received signal strengths from all the users at ' char(basestation(wantedBS).nameLong)];
   title(['\it{}' header]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'Signal strength');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' dBm'));
   BSplot(basestation, gcf, vectMap, lossData);
   clear header hcb ks bsRxPower1 colors1 layerString ind1
end
