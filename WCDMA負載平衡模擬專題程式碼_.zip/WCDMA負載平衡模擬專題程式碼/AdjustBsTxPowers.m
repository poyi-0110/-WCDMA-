%ADJUSTBSTXPOWERS    ADJUSTBSTXPOWERS adjusts the BS TX powers according to deltaCI
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files:   None

for i1 = 1:numMSs
   tmpind = find(bsTxPower(:, i1)~=0);
   if ~isempty(tmpind)
      [tmpmaxP, tmpmaxPind] = max([basestation(tmpind).CPICHPower]);
      tmpmaxPind = tmpind(tmpmaxPind);
      %adjust the best server link by deltaCI
      bsTxPower(tmpmaxPind, i1) = bsTxPower(tmpmaxPind, i1)+deltaCI(i1);
      %set powers of SHO links to best server power scaled by difference in CPICHs
      bsTxPower(tmpind, i1) = bsTxPower(tmpmaxPind, i1)+[basestation(tmpind).CPICHPower]'-tmpmaxP;
   end
end
clear tmp* i1
