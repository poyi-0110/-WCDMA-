%NPSWSYS   this file contais all the system realated paramters needed.
%
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%%%%%%%%%%%%%%%%%%%%%%% general %%%%%%%%%%%%%%%%%%%%%%
frequency = 2000;     %MHz
channelSpacing = 5e6; %Hz
channelOffset = 1;    %Offset for the second carrier (multiple of the channelSpacing)
W = 3.84e6;           %Hz - CDMA bandwidth

%%%%%%%%%%%%%%%%% BS parameters %%%%%%%%%%%%%%%%%%%%%%
BS_noise_figure = 5;         % dB
Thermal_noise_density = -174;% dBm/Hz

%%%%%%%%%%%%%%%%%% MS parameters %%%%%%%%%%%%%%%%%%%%%
msHeight = 1.5;       %m
MS_noise_figure = 8;  %dB