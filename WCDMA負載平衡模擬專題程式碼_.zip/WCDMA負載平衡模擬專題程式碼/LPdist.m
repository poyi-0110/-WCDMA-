%LPDIST   LPDISP sorts all the link powers according the distance between the MS and 
%         the BS having this link and plots this curve
%
%Inputs:
%   bsTxPowerLin  : all the link powers
%   basestation   : the basestation structure
%   mobilestation : the mobilestation structure
%Outputs:
%   the plot
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

figure
[bss mss linkPow] = find(bsTxPowerLin);
bssPos = [basestation(bss).x]+j*[basestation(bss).y];
mssPos = [mobilestation(mss).x]+j*[mobilestation(mss).y];
linkDist = abs(mssPos-bssPos);
[linkDistSorted dInd] = sort(linkDist);
linkPowSorted = linkPow(dInd);
plot(linkDistSorted, linkPowSorted, 'x');
xlabel('distance / m')
ylabel('power / mW')
title('link powers')

clear bss mss bssPos mssPos linkDist linkDistSorted dInd linkPow linkPowSorted
