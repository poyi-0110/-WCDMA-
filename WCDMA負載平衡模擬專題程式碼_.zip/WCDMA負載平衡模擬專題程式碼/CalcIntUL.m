%CALCINTUL   CALCINTUL calculates the received signal level from each mobile
%            to each base station and estimates own and other cell interference
%            and determines the perf.i
%
%Inputs:
%   linklossULM     : (numBSs*numMSs) matrix of the UL linklosses from every BS to every MS
%   msTxPowerV      : numMSs vector of MS transmit powers used to calculate IownUL
%   msTxPowerRaisedV: numMSs vector of MS transmit powers used to calculate IothUL
%Outputs:
%   IownUL          : Interference from own cell
%   IothUL          : Interference from other cells
%   perf.i          : other-cell-to-own-cell interference ratio
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi), Jaana Laiho-Steffens (jls)
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

v_tmp = [mobilestation.vUL]';
tmpPerm = eye(numBSs);
tmpPerm = tmpPerm(:, bestServerV);

%Only those not in outage nor in other carriers are included.
bsRxPowerLinV = (log2lin(-linklossULM).*tmpPerm)*(v_tmp.*log2lin(msTxPowerV)'.*(usedCarrV>=1)');

% If there is no own cell interference, perf.i will remain zero
IownUL = bsRxPowerLinV';

%first index BS operator, second index MS operator
rxRaised = zeros([numBSs, 1]);
if (length(indBStype1) >= 1 & length(indMStype1) >= 1)
   rxRaised(indBStype1) = ...
      (log2lin(-linklossULM(indBStype1, indMStype1)).*(~tmpPerm(indBStype1, indMStype1))) * ...
      (v_tmp(indMStype1).*log2lin(msTxPowerRaisedV(indMStype1))'.*(usedCarrV(indMStype1)>=1')');
end

if (length(indBStype2) >= 1 & length(indMStype2) >= 1)
   rxRaised(indBStype2) = ...
      (log2lin(-linklossULM(indBStype2, indMStype2)).*(~tmpPerm(indBStype2, indMStype2))) * ...
      (v_tmp(indMStype2).*log2lin(msTxPowerRaisedV(indMStype2))'.*(usedCarrV(indMStype2)>=1')');
end

if (channelOffset > (length(acFilterUL)-1))
   errordlg('Honey - how about a longer filter ??? ;-)')
end

rxRaisedCross = zeros([numBSs, 1]);

if (length(indBStype1) >= 1 & length(indMStype2) >= 1)
   rxRaisedCross(indBStype1) = ...
      log2lin(-linklossULM(indBStype1, indMStype2)) * ...
      (v_tmp(indMStype2).*max(log2lin(msTxPowerRaisedV(indMStype2))'*log2lin(-acFilterUL(channelOffset)), log2lin(acMinPowUL))...
      .*(usedCarrV(indMStype2)>=1')');
end

if (length(indBStype2) >= 1 & length(indMStype1) >= 1)
   rxRaisedCross(indBStype2) = ...
      log2lin(-linklossULM(indBStype2, indMStype1)) * ...
      (v_tmp(indMStype1).*max(log2lin(msTxPowerRaisedV(indMStype1))'*log2lin(-acFilterUL(channelOffset)), log2lin(acMinPowUL))...
      .*(usedCarrV(indMStype1)>=1')');
end

clear v_tmp;

%for historical reasons
bsRxPowerLinRaisedV = rxRaised;
IothUL   = bsRxPowerLinRaisedV';
IothOpUL = rxRaisedCross';

tmpi = zeros(size(IothUL));
tmpi(IownUL>0) = (IothUL(IownUL>0)+IothOpUL(IownUL>0))./IownUL(IownUL>0);
tmpi = num2cell(tmpi);
[perf.i] = deal(tmpi{:});

clear tmpi tmpPerm rxRaised rxRaisedCross
