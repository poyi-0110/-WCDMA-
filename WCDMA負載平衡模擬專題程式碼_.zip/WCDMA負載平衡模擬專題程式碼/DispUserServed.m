%DISPUSERDSERVED   DISPUSERSERVED displays the 'user' map, i.e. users which after DL iteration are
%                  using carrier 1 or 2.
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   figure
   set(gcf, 'Tag', 'tagUserFig');
   userColors = [1 1 1; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.5 0.5 0.5];
   userDL = zeros(yPixels, xPixels);
   eval(['indMStypeX = indMStype' num2str(layer) ';']);
   for m = indMStypeX
      if mobilestation(m).usedCarr == layer
         userDL(yPos(m), xPos(m)) = userDL(yPos(m), xPos(m))+1;
      end
   end
   totalUsers = sum(sum(userDL));
   
   userDL(~isnan(waterArea)) = NaN;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          userDL);
       
   caxis([0 8]);
   colormap(userColors);
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   titleText = ['USER DISTRIBUTION' layerString ' (served) (total = ' num2str(totalUsers), ' users)'];
   title(['\it{', titleText, '}']);
   axis('equal');
   shading('flat');
   hcb = colorbar('vert');
   set(get(hcb, 'Title'), 'String', '# of users');
   tlabel = get(hcb, 'yticklabel');
   set(hcb, 'yticklabel', tlabel);
   set(hcb, 'Ytick', get(hcb, 'Ytick')+0.5);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
end
clear userColors tlabel hcb userDL layer layerString
