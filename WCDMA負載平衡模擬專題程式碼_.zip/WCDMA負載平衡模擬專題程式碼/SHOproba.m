%SHOPROBA  SHOPROBA creates the SHO probabilities and plots them as a bar graph
%          and as an area plot
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Kari Sipil� (KSi), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcSHOarea.m, BSplot.m

%%%%% for mobiles only %%%%%
tmpLayer = [];
tmpRun = 0;
if numBStype1 & numMStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2 & numMStype2
   tmpLayer = [tmpLayer 2];
end

for SHOprobaRun = tmpLayer
   tmpRun = tmpRun+1;
   eval(['indBStypeX = indBStype' num2str(SHOprobaRun) ';']);
   eval(['indMStypeX = indMStype' num2str(SHOprobaRun) ';']);
   eval(['numBStypeX = numBStype' num2str(SHOprobaRun) ';']);
   eval(['numMStypeX = numMStype' num2str(SHOprobaRun) ';']);
   
   SHOtot = sum(bsTxPowerLin(indBStypeX, indMStypeX)~=0, 1);
   
   [a b] = hist(SHOtot(:), 0:10);
   
   a = a/max(sum(a(2:end)),1)*100;
   
   ind1 = max(find(a~=0));
   
   figure;
   bar(b(2:ind1), a(2:ind1));
   
   for k = 2:ind1
      text(b(k)-0.3, a(k)+1, [num2str(round(10*a(k))/10) '%']);
   end
   
   if (numBStype1 > 0 & numBStype2 > 0)
      if mode == 2
         title(['\it{SHO probability for all served users of Operator ' num2str(SHOprobaRun) '}'])    
      else
         title(['\it{SHO probability for all served users of Carrier ' num2str(SHOprobaRun) '}']) 
      end
   else
      title(['\it{SHO probability for all served users.}'])    
   end
   
   xlabel('number of BSs to which MSs have connection')
   ylabel('probability in %')
   xLab = [];
   for k = 1:ind1-1
      xLab = strvcat(xLab, [num2str(k) ' conn.']);
   end
   set(gca, 'xTickLabel', xLab);
   set(gca, 'Ylim', [0 100])
   
   %check for softer HO
   if numBStypeX == 1
      softerHO = (bsTxPowerLin(indBStypeX, indMStypeX) ~= 0); %set softerHO to 1 where there is a connection
   else
      softerHO = (bsTxPowerLin(indBStypeX, indMStypeX) ~= 0); %set softerHO to 1 where there is a connection
      
      %set softerHO to 2 where there are more connections (soft)
      %set softerHO to 3 where there is a "softer" connection
      MSind = find(SHOtot > 1); 
      %for m = MSind
      for m = MSind
         BSind = find(softerHO(:, m) ~= 0)'; %here transpose is important !!!
         for k = BSind
            if softerHO(k, m) ~= 3 %don't reset any softer connections
               softerHO(k, m) = 2;
            end
            for l = BSind
               if ((l > k) & (basestation(indBStypeX(l)).x == basestation(indBStypeX(k)).x) & ...
                             (basestation(indBStypeX(l)).y == basestation(indBStypeX(k)).y))
                  softerHO(k, m) = 3;
                  softerHO(l, m) = 3;
               end
            end
         end
      end
   end
   
   connPerMS = sum(softerHO>0, 1);
   
   %find MSs in outage
   numConnMS(1) = sum(connPerMS == 0);
   %find MSs with one connection
   numConnMS(2) = sum(connPerMS == 1);
   %find MSs with 4 or more connections
   numConnMS(8) = sum(connPerMS >=4);
   %find 2 way soft
   ind1 = find(connPerMS == 2);
   numConnMS(3) = sum(sum(softerHO(:, ind1)) == 4);
   %find 2 way softer 
   ind1 = find(connPerMS == 2);
   numConnMS(4) = sum(sum(softerHO(:, ind1)) == 6);
   %find soft/softer 
   ind1 = find(connPerMS == 3);
   numConnMS(5) = sum(sum(softerHO(:, ind1)) == 8);
   %find 3 way soft 
   ind1 = find(connPerMS == 3);
   numConnMS(6) = sum(sum(softerHO(:, ind1)) == 6);
   %find 3 way softer 
   ind1 = find(connPerMS == 3);
   numConnMS(7) = sum(sum(softerHO(:, ind1)) == 9);
   
   numConnMS = numConnMS/max(sum(numConnMS(2:end)), 1)*100;
   
   figure
   
   bar(numConnMS(2:end));
   
   xLab = str2mat('1 conn.', '2 soft', '2 softer', ...
      '3 soft/er', '3 soft', '3 softer', '>3 conn.');
   set(gca, 'xTickLabel', xLab);
   xlabel('connection type');
   ylabel('probability in %');
   set(gca, 'Ylim', [0 100])
   
   if (numBStype1 > 0 & numBStype2 > 0)
      if mode == 2
         title(['\it{SHO probability for all served users of Operator ' num2str(SHOprobaRun) '}'])    
      else
         title(['\it{SHO probability for all served users of Carrier ' num2str(SHOprobaRun) ' }']) 
      end
   else
      title(['\it{SHO probability for all served users.}'])    
   end
   
   for k = 2:length(numConnMS)
      text(k-1.3, numConnMS(k)+1.1, [num2str(round(10*numConnMS(k))/10) '%']);
   end
   
   %%%%% SHO probability for area %%%%%
   if (exist('SHOarea') ~= 1)
      CalcSHOarea;
   end
   
   if numBStype1 & numBStype2 & SHOprobaRun == 2
      SHOareacnt1 = SHOareacnt(1+yPixels:end, :);
   else
      SHOareacnt1 = SHOareacnt(1:yPixels, :);
   end
   SHOareacnt1 = SHOareacnt1+1;
   
   SHOareacnt1(find(bestServer(SHOprobaRun, :, :)==0)) = 0;
   SHOareacnt1(~isnan(waterArea)) = NaN;
   
   %%%%% area plot %%%%%
   figure;
   
   maxServers = 5;
   SHOareacnt1(find(SHOareacnt1 > maxServers)) = maxServers;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          squeeze(SHOareacnt1));
   
   connColors = [1 1 1; 0.7 0.7 0.7; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1];
   connColors = connColors(1:maxServers+1, :);    
   colormap(connColors);
   caxis([0 maxServers+1]);
   shading('flat')
   hcb = colorbar('vert');
   set(get(hcb, 'Title'), 'String', 'SHO connections');
   tlabel = [0:maxServers]';
   tlabelstr = str2mat(num2str(tlabel(1:maxServers)));
   tmpstr = ['>= ' num2str(maxServers)];
   tlabelstr = str2mat(tlabelstr, tmpstr);
   tpos = tlabel+0.5;
   set(hcb, 'Ytick', tpos);
   set(hcb, 'yticklabel', tlabelstr);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
   title(['\it{SHO conn. - based on rec. CPICH power, WINDOW\_ADD_1 = ' num2str(basestation(1).WINDOW_ADD), ' dB}'])
   
   % Probability calculated in a polygon
   clear previousPolygonFlag
   
   if (~exist('previousPolygonFlag'))
      if (tmpRun == 1)
         [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 1);
      else
         if mode == 2
            [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 2);
         else
            [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, 3);
         end
      end
   end
   
   SHOareacnt1(find(~inplgn)) = 0;
   
   [c b] = hist(SHOareacnt1(:), 0:10);
   c = c/max(sum(c(2:end)), 1)*100;
   
   ind1 = max(find(c~=0));
   
   figure;
   bar(b(2:ind1), c(2:ind1));
   for k = 2:ind1
      text(b(k)-0.3, c(k)+1, [num2str(round(10*c(k))/10) '%']);
   end
   
   if (numBStype1 > 0 & numBStype2 > 0)
      if mode == 2
         title(['\it{SHO probability (area) for Operator ' num2str(SHOprobaRun) ' in polygon. Pixels in UL outage excluded.}'])    
      else
         title(['\it{SHO probability (area) for Carrier ' num2str(SHOprobaRun) ' in polygon. Pixels in UL outage excluded.}']) 
      end
   else
      title(['\it{SHO probability (area). Pixels in UL outage excluded.}'])    
   end
   
   xlabel('number of received CPICHs within WINDOW\_ADD')
   ylabel('probability in %')
   xLab = [];
   for k = 1:ind1-1
      xLab = strvcat(xLab, [num2str(k) ' conn.']);
   end
   set(gca, 'xTickLabel', xLab);
   set(gca, 'Ylim', [0 100])
   
   clear SHOtot a b MSind BSind SHOareacnt1 tlabel tpos maxServers hcb k l m tmpstr tlabelstr
   clear plgnX plgnY inplgn numMStype numBStype indMStype indBStype
end
