%DISPLOAD   DISPLOAD creates the loading map and plots it
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   loading = zeros(yPixels, xPixels);
   
   for k = 1:yPixels
      for l = 1:xPixels
         if (bestServer(layer, k, l))
            loading(k, l) = Ueta(bestServer(layer, k, l));
         end
      end
   end
   
   if layer == 1
      if (~exist('loadFig1'))
         loadFig1 = 1;
         hFig = figure;
         set(hFig, ...
            'DeleteFcn', 'clear loadFig1', ...
            'Tag', 'loadFig1');
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', 0.2, 'maxValue', 0.8, 'stepSize', 0.02, ...
            'curColMap', 'jet', 'curFig', hFig, 'curFun', 'DispLoad');
      else
         figure(findobj('Tag', 'loadFig1'));
         ud = get(gca, 'userdata');
      end
   else
      if (~exist('loadFig2'))
         loadFig2 = 1;
         hFig = figure;
         set(hFig, ...
            'DeleteFcn', 'clear loadFig2', ...
            'Tag', 'loadFig2');
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', 0.2, 'maxValue', 0.8, 'stepSize', 0.02, ...
            'curColMap', 'jet', 'curFig', hFig, 'curFun', 'DispLoad');
      else
         figure(findobj('Tag', 'loadFig2'));
         ud = get(gca, 'userdata');
      end
   end
   
   loading((loading<ud.minValue) & (loading>0)) = ud.minValue+eps;
   loading(loading == 0) = -1;
   loading(~isnan(waterArea)) = NaN;
   
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          loading)
   set(gca, 'userdata', ud); %don't delete - pcolor clears the userdata
   caxis([ud.minValue-ud.stepSize ud.maxValue]);
   eval(['colors1 = ' ud.curColMap ,'(round((ud.maxValue-ud.minValue)/ud.stepSize));']);
   colormap([[1 1 1]; colors1]);
   hcb = colorbar;
   axis('equal');
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   title(['\it{}' ['Cell loading from all users' layerString]]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'Cell loading');
   set(hcb, 'yticklabel', strcat(num2str(100*str2num(get(hcb, 'yticklabel'))), ' %'));
   BSplot(basestation, gcf, vectMap, lossData);
   clear loading colors1 hcb k l
end
