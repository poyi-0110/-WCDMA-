%CALCSHOAREA   CALCSHOAREA calculates (and plots) the soft handover areas
%             
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Heiska (KHe), 
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%do stuff only if necessary
if numBStype1
   if (~exist('SHOareacnt') | ~exist('SHOarea'))
      if numBStype2 == 0
         hwb = waitbar(0, 'Calculating SHO regions ...');
      else
         if mode == 2
            hwb = waitbar(0, 'Calculating SHO regions for Operator 1...');
         elseif mode == 1
            hwb = waitbar(0, 'Calculating SHO regions for Carrier 1...');
         end
      end
      SHOarea1 = zeros(yPixels, xPixels);
      SHOareacnt1 = zeros(yPixels, xPixels);
      bsWindowAdd = zeros(yPixels, xPixels);
      for kk = 1:yPixels
         for ll = 1:xPixels
            bsWindowAdd(kk, ll) = basestation(bestServDL(1, kk, ll)).WINDOW_ADD;
         end
      end
      tmp1 = squeeze(CPICHLevel(1, :, :))+bsWindowAdd;
      clear bsWindowAdd
      
      %calculate SHO area according received CPICH power in downlink
      kk = 1;
      for n = indBStype1
         waitbar(kk/numBStype1);
         tmp2 = squeeze(CPICHStrength(n, :, :)) > tmp1;
         SHOareacnt1 = SHOareacnt1+tmp2;
         kk = kk+1;
      end
      close(hwb);
      
      SHOareacnt1 = SHOareacnt1-1;
      SHOarea1 = squeeze(SHOareacnt1 > 0);
      
      %more clean up
      clear bsTadd tmp1 tmp2
   end
end

if numBStype2
   if (~exist('SHOareacnt') | ~exist('SHOarea'))
      if numBStype1 == 0
         hwb = waitbar(0, 'Calculating SHO regions ...');
      else
         if mode == 2
            hwb = waitbar(0, 'Calculating SHO regions for Operator 2...');
         elseif mode == 1
            hwb = waitbar(0, 'Calculating SHO regions for Carrier 2...');
         end
      end
      SHOarea2 = zeros(yPixels, xPixels);
      SHOareacnt2 = zeros(yPixels, xPixels);
      bsWindowAdd = zeros(yPixels, xPixels);
      for kk = 1:yPixels
         for ll = 1:xPixels
            bsWindowAdd(kk, ll) = basestation(bestServDL(2, kk, ll)).WINDOW_ADD;
         end
      end
      tmp1 = squeeze(CPICHLevel(2, :, :))+bsWindowAdd;
      clear bsWindowAdd
      
      %calculate SHO area according received CPICH power in downlink
      kk = 1;
      for n = indBStype2
         waitbar((kk)/numBStype2);
         tmp2 = squeeze(CPICHStrength(n, :, :)) > tmp1;
         SHOareacnt2 = SHOareacnt2+tmp2;
         kk = kk+1;
      end
      close(hwb);
      
      SHOareacnt2 = SHOareacnt2-1;
      SHOarea2 = squeeze(SHOareacnt2 > 0);
      
      %more clean up
      clear bsTadd tmp1 tmp2 
   end
end

if numBStype1 & numBStype2
   SHOareacnt = [SHOareacnt1; SHOareacnt2];
   SHOarea = [SHOarea1; SHOarea2];
   clear SHOarea1 SHOarea2 SHOareacnt1 SHOareacht2
elseif numBStype1 & ~numBStype2
   SHOareacnt = SHOareacnt1;
   SHOarea = SHOarea1;
elseif ~numBStype1 & numBStype2
   SHOareacnt = SHOareacnt2;
   SHOarea = SHOarea2;
end
clear SHOarea1 SHOareacnt1 SHOarea2 SHOareacnt2
