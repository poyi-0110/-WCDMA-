%DISPMSCONN   [BS NUMCONN] = DISPMSCONN(MSNR) displays all the connections the mobile
%             station MSNR is having
%
%Inputs:
%   msNr          : all the link powers
%  form evalin:
%   basestation   : the basestation structure
%   mobilestation : the mobilestation structure
%   bsTxPowerLin  : the link powers (to determine the connections)
%   area          : the borders of the network area
%   resolution    : the resolution of the map
%Outputs:
%   bs            : the bs's to which the ms has connections
%   numconn       : the number of connections
%
%Author : Achim Wacker (AWa), Kari Heiska (KHe), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

function [bs, numconn] = DispMSconn(msNr)

basestation   = evalin('base', 'basestation');
bsTxPowerLin  = evalin('base', 'bsTxPowerLin');
mobilestation = evalin('base', 'mobilestation');
area          = evalin('base', 'area');
resolution    = evalin('base', 'resolution');
vectMap       = evalin('base', 'vectMap');
lossData      = evalin('base', 'lossData');
indBStype1    = evalin('base', 'indBStype1');
indBStype2    = evalin('base', 'indBStype2');
numBStype1    = evalin('base', 'numBStype1');
numBStype2    = evalin('base', 'numBStype2');
numBSs        = length(basestation);
mode          = evalin('base', 'mode');

if mode == 1
   layerString = ['CA'];
elseif mode == 2
   layerString = ['OP'];
end

for kk1 = 1:length(msNr)
   kk2 = msNr(kk1);
   figure
   BSplot(basestation, gcf, vectMap, lossData);
   hold on
   bs      = find(bsTxPowerLin(:, kk2));
   numconn = length(bs);
   if numconn
      offset = max(area(2)-area(1), area(4)-area(3))/25;
      
      hl2 = line([[basestation(bs).x]; [basestation(bs).x]+offset*cos((90-[basestation(bs).antennaDir])*pi/180)], ...
                 [[basestation(bs).y]; [basestation(bs).y]+offset*sin((90-[basestation(bs).antennaDir])*pi/180)]);
      
      offset = offset*1.25;
      hl1 = line([repmat(mobilestation(kk2).x, 1, numconn); [basestation(bs).x]+offset/2*cos((90-[basestation(bs).antennaDir])*pi/180)], ...
                 [repmat(mobilestation(kk2).y, 1, numconn); [basestation(bs).y]+offset/2*sin((90-[basestation(bs).antennaDir])*pi/180)]);
      ht  = text([basestation(bs).x]+offset*cos((90-[basestation(bs).antennaDir])*pi/180), ...
                 [basestation(bs).y]+offset*sin((90-[basestation(bs).antennaDir])*pi/180), ...
                 [basestation(bs).name]);
      
      for kk = 1:numconn
         set(ht(kk), 'FontSize', 9);
         set(ht(kk), 'FontWeight', 'bold')
         set(ht(kk), 'Color', get(hl1(kk), 'Color'));
      end
      titleText = ['MS ' num2str(kk2) ' is connected to BS(s) ' ];
      for kk = 1:numconn
         titleText = [titleText char(basestation(bs(kk)).nameLong) ' '];
      end
   else
      titleText = ['MS ' num2str(kk2) ' has no connections'];
   end
   plot(mobilestation(kk2).x, mobilestation(kk2).y, 'r.');
   title(['\it{' titleText '}']);
   text(mobilestation(kk2).x+3*resolution, mobilestation(kk2).y, ['MS ' num2str(kk2)], 'Color', 'r', 'FontSize', 9);
   hold off
   axis equal
   axis(area);
end
