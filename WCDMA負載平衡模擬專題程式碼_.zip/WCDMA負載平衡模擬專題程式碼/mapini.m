%MAPINI   MAPINI defines the map parameters
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Kari Sipil?(KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

if (~exist('mapFile') | pathlossModel <= 6)
   mapFile = [];
end

if (~exist('waterAreaFile') | pathlossModel <= 6)
   waterAreaFile = [];
end

if ((pathlossModel == 7) | (pathlossModel == 8)) % The map generated from nps/x 
   load(linklossFile);                           % loads the linkloss-data
   resolution = lossData(1).resolution;          % meters
   area = lossData(1).area;
   if (pathlossModel == 8)
      load(vectFile);                            % loads the building vector info
   else
      vectMap = [];
   end
else
   resolution = 50;
   area = [-2500 2500 -2500 2500]; % meters %�t�XMSparam_2tier.txt�BBSparam_2tier.txt�ק�
   lossData = [];
   vectMap = [];
end
xmin = area(1);
xmax = area(2);
ymin = area(3);
ymax = area(4);