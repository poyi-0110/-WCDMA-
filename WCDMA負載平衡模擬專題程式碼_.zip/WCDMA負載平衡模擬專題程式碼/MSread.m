%MSREAD   MSREAD reads the mobile station parameter file specified as msParamFile
%         in npswini.m
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Sipil?(KSi), Jaana Laiho-Steffens (jls)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files:   none

if (~exist('msParamFile'))
   msParamFile = 'MSparam.txt';
end
load(msParamFile);
value = eval(msParamFile(1:end-4));

if exist('randomizeMSfile') & exist('usePrevRandStateInMsRead')
   if (randomizeMSfile) 
      tmp_state1 = rand('state');
      
      tmp_state2 = randn('state');
      
      if usePrevRandStateInMsRead & exist('msReadRandState.mat')
         load msReadRandState;
         rand('state', msReadPrevRandState);
      else 
         if exist('msReadDefRandState')
	         rand('state', msReadDefRandState);
         else
	         rand('state', 0);
         end
      end
      [m1, n1] = size(value);
      value = value(randperm(m1), :);
      msReadPrevRandState = rand('state');
      save msReadRandState.mat msReadPrevRandState;
      rand('state', tmp_state1);
      randn('state', tmp_state2);
      clear tmp_state1;
      clear tmp_state2;
   end
end

if size(value, 1) < numMSs
   button = questdlg( ...
      ['Too few MSs in ' msParamFile ' . Automatically reduce number according ' msParamFile ' or Exit ?'], ...
      'MS error', 'Reduce', 'Exit', 'Reduce');
   if strcmp(button, 'Reduce')
      numMSs = size(value, 1);
   else
      error(['npsw terminated due to too few MSs in ' msParamFile]);
   end
end

value = value(1:numMSs, :);
value = num2cell(value);

fields = {'x', 'y', 'groundHeight', 'antennaHeight', 'txMaxPower', 'txMinPower', 'antennaGain', ...
          'bodyLoss', 'RUL', 'RDL', 'usedCarr', 'speed'};

mobilestation = cell2struct(value, fields, 2);

%some sanity checking
indMStype1  = find([mobilestation.usedCarr] == 1);
indMStype2  = find([mobilestation.usedCarr] == 2);
numMStype1a = length(indMStype1);
numMStype2a = length(indMStype2);
if (mode == 1 & doInitialCarrierSelection < 1) | mode == 2
   if (numMStype1a~=numMStype1) | (numMStype2a~=numMStype2)
      button = questdlg([ ... 
            'Mismatch in number of MSs for each type in npswini.m and ' msParamFile '. ' ...
            'Automatically adjust numbers according info from ' msParamFile ...
            ' and continue or Exit ?'], ...
         'MS error', 'Continue', 'Exit', 'Continue');
      if strcmp(button, 'Continue')
         numMStype1 = numMStype1a;
         numMStype2 = numMStype2a;
         numMSs = numMStype1+numMStype2;
      else
         error('npsw terminated due to error in numbers for MS types');
      end
   end
end

%2 operator case and all MSs are assigned to Operator 1/2 but there are no BSs for Operator 1/2
case1 = (numBStype1 == 0 & numBStype2 ~= 0 & numMStype1 ~= 0 & numMStype2 == 0); %only BSs type 1 and MSs type 2
case2 = (numBStype1 ~= 0 & numBStype2 == 0 & numMStype1 == 0 & numMStype2 ~= 0); %only BSs type 2 and MSs type 1
if (mode == 2) & (case1 | case2)
   error('All MSs are assigned to Operator with no BSs!');
end

currentMS = numMSs;

%save original MS list for later plotting;
mobilestationOri = mobilestation;

clear fields value numMStype1a numMStype2a case1 case2
eval(['clear ' msParamFile(1:end-4)]);
