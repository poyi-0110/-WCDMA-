%TRACE   TRACE Traces one MS along a specified route for certain parameters
%
%Inputs (globals):
%   tmpBitRate      : the bit-rate (service) to be used in bits/s
%   tmpSpeed        : the MS speed to be used in km/h 
%   tmpDist         : the resolution for the route
%   area            : the dimensions of the network
%   numBSs          : the number of base stations
%   wideAreaCovR    : the reference bit rate
%   wideAreaCovSpeed: the reference speed
%   resolution      : the resolution of the map
%   CPICHStrength   : the received CPICHs from each BS at each pixel
%Outputs:
%   none
%
%Authors: Kari Heiska (KHe), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m
%
%Note: if tmpBitRate, tmpSpeed and tmpDist are not defined beforehand, wideAreaCovBitRate,
%      wideAreaCovSpeed and resolution will be used.

h_route = figure;

if (~exist('tmpdist'))
   tmpdist = resolution;
end;
if (~exist('numTraces'))
   numTraces = 2;
end

axis('equal');
axis(area);
if (numBSs)
   BSplot(basestation, h_route, vectMap, lossData);
end

disp('Input the desireded route by mouse (<enter> terminates)');
[msx, msy] = ginput;

hold on 
ms_trace = [];
for k = 2:length(msx);
   vect_line = [msx(k)-msx(k-1) msy(k)-msy(k-1)];
   vect_pit = sqrt(sum(vect_line.^2));
   nmb_points = fix(vect_pit/tmpdist);
   ms_trace = [ms_trace; ones(nmb_points, 1)*[msx(k-1) msy(k-1)]+cumsum(ones(nmb_points, 1)*vect_line/vect_pit*tmpdist)];
end
plot(ms_trace(:, 1), ms_trace(:, 2), '.r');
lms = length(ms_trace(:, 1));
trace_pix = [fix((ms_trace(:, 1)-area(1))/resolution) fix((ms_trace(:, 2)-area(3))/resolution)];
trace_CPICH = zeros(lms, numBSs);
for bs = 1:numBSs
   for i1 = 1:lms
      trace_CPICH(i1, bs) = CPICHStrength(bs, trace_pix(i1, 2), trace_pix(i1, 1));
   end
end
h_trace = figure;
trace_dist = [0; cumsum(sqrt(sum((diff(ms_trace).^2)'))')];

%sort received CPICHes according average level
%[tr_mx, tr_mx_ind] = sort(mean(trace_CPICH));
%tr_mx = flipud(tr_mx');
%tr_mx_ind = flipud(tr_mx_ind');
%trace_CPICH = trace_CPICH(:, tr_mx_ind);
%BSlist = '';

%sort acc. currently strongest CPICH
[tr_mx, tr_mx_ind] = sort(trace_CPICH,2);
tr_mx = fliplr(tr_mx);
tr_mx_ind = fliplr(tr_mx_ind);
BSlist = '';

bestPilotColors = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.9 0.9 0.9];
bestPilotColors = [bestPilotColors' 0.8*bestPilotColors' ...
                    0.6*bestPilotColors(1:5, :)' 0.4*bestPilotColors(1:5, :)']';
while (size(bestPilotColors, 1) < numBSs)
   bestPilotColors = [bestPilotColors' bestPilotColors']';
end

bestPilotColors = [[0 0 0]' bestPilotColors']';
%plot maximum the six strongest ones
for i2 = 1:min(6, length(tr_mx_ind))
   BSlist_str = ['BS ' num2str(tr_mx_ind(i2))];
   BSlist(i2, 1:length(BSlist_str)) = BSlist_str;
end
grid;
for i1 = 1:numTraces
   for i2 = 1:size(tr_mx_ind,1)-1
      line([i2 i2+1]*tmpdist, [tr_mx(i2,i1) tr_mx(i2+1,i1)], 'Color', bestPilotColors(tr_mx_ind(i2, i1)+1, :));
   end
end

xlabel('distance along the route (m)')
ylabel('CPICH strength (dBm)')
title('\it{Received CPICH level along traced route}')

clear msx msy h_route ms_trace vect_line vect_pit nmb_points k lms trace_pix trace_CPICH ...
i1 i2 bs h_trace trace_dist tr_mx tr_mx_ind trace_CPICH BSlist BSlist_str tmpSpeed tmpBitRate
