%BSPLOT   [HL, HT] = BSPLOT(BASESTATION, hFig, VECTMAP, LOSSDATA) plots all base stations
%
%Inputs:
%   BASESTATION: array of all base station structre
%   hFig       : handle to current figure
%   VECTMAP    : map of vector data
%   LOSSDATA   : info structure for nps/x case
%Outputs:
%   HL         : handle to BS lines
%   HT         : handle to BS texts
%
%Authors: Achim Wacker (AWa) NTC, Kari Heiska (KHe) NTC, Jaana Laiho-Steffens (jls) NTC
%         Kari Sipil� (KSi) NET, Kai Heikkinen (KHeik), NET
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function [hl, ht] = BSplot(basestation, hFig, vectMap, lossData);

xmin          = evalin('base', 'xmin');
xmax          = evalin('base', 'xmax');
ymin          = evalin('base', 'ymin');
ymax          = evalin('base', 'ymax');
pathlossModel = evalin('base', 'pathlossModel');
resolution    = evalin('base', 'resolution');
mapFile       = evalin('base', 'mapFile');
waterAreaFile = evalin('base', 'waterAreaFile');
indBStype1    = evalin('base', 'indBStype1');
indBStype2    = evalin('base', 'indBStype2');
numBStype1    = evalin('base', 'numBStype1');
numBStype2    = evalin('base', 'numBStype2');
area          = [xmin xmax ymin ymax];
numBSs        = length(basestation);
mode          = evalin('base', 'mode');

lineWidth = 2.0;
hold on
if ~isempty(vectMap)
   % Plots the vectormap 
   corner = lossData(1).corner; %lower left corner of the map area
   ii = find(vectMap(:, 1) ~= 0);
   area = lossData(1).area;
   vectMap(ii, [1 3]) = (vectMap(ii, [1 3])-ones(length(ii), 1)*corner([1 1]))+area(1);
   vectMap(ii, [2 4]) = (vectMap(ii, [2 4])-ones(length(ii), 1)*corner([2 2]))+area(3);
   
   hmap = plot(vectMap(ii, [1 3])', vectMap(ii, [2 4])', 'k');
   set(hmap, 'LineWidth', 1.5);
   lineWidth = 2;
end
       
offset = max(xmax-xmin, ymax-ymin)/25;
hl1 = line([[basestation(indBStype1).x]; [basestation(indBStype1).x]+offset*cos((90-[basestation(indBStype1).antennaDir])*pi/180)], ...
           [[basestation(indBStype1).y]; [basestation(indBStype1).y]+offset*sin((90-[basestation(indBStype1).antennaDir])*pi/180)], ...
            'color', 'g');
hl2 = line([[basestation(indBStype2).x]; [basestation(indBStype2).x]+offset*cos((90-[basestation(indBStype2).antennaDir])*pi/180)], ...
           [[basestation(indBStype2).y]; [basestation(indBStype2).y]+offset*sin((90-[basestation(indBStype2).antennaDir])*pi/180)], ...
            'color', 'r');
hl = [hl1; hl2];
set(hl, 'LineWidth', lineWidth);
hbase = plot([basestation.x], [basestation.y], '.');     
set(hbase, 'MarkerSize', 10);
offset = offset*ones(1, numBSs)*1.25;
ht = text([basestation.x]+offset.*cos((90-[basestation.antennaDir])*pi/180), ...
          [basestation.y]+offset.*sin((90-[basestation.antennaDir])*pi/180), ...
          [basestation.name], 'color', 'k');
for kk = 1:numBSs
   set(ht(kk), 'FontSize', 9)
   set(ht(kk), 'FontWeight', 'bold')
end
hold off
xlabel('X-coordinate [m]')
ylabel('Y-coordinate [m]')
axis equal;
axis([area]);

hold on
if (pathlossModel == 7 | pathlossModel == 8) & ~isempty(mapFile)
   hcb = findobj(gcf, 'Tag', 'TMW_COLORBAR');
   set(gca, 'Color', [0.5 0.75 1.0]);
   if hcb
      %nothing here
   else
      eval(['load ' mapFile]);
      load(waterAreaFile);
      waterArea = digiMap;
      colormap(cMap*.6+.4);
      pcolor(xmin:resolution:xmax, ...
             ymin:resolution:ymax, ...
             waterArea(1:end-1, 1:end-1));
      shading flat
   end
end
grid on
set(gca, 'Layer', 'top')
box on
