%DISPCOMPCOVUL   DISPCOMPCOVUL plots composite coverage for uplink
%
%Inputs:
%Outputs:   
%Comment:
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

if numBStype2 == 0
   layerString = [];
else
   if mode == 1
      layerString = [' for carrier ' num2str(layer)];
   elseif mode == 2
      layerString = [' for operator ' num2str(layer)];
   end
end   
tmpPow(find(tmpPow==999)) = -999;
[covV covI] = max(tmpPow, [], 1);
covI(find(covV == -999)) = NaN;
covI = squeeze(covI);

%sort services according required txPower, order should be same in each pixel ???
%- find a pixel, where all services are covered
[covV1 dummy] = min(tmpPow, [], 1);
indAllCov = find(covV1 > -999);

[dummy serviceOrder] = sort(tmpPow(1:numServices, indAllCov(1)));
%serviceOrder = flipud(serviceOrder);

%reorder the covI values
tmpCovI = NaN*ones(size(covI));
for kk = 1:numServices
   tmpCovI(find(covI == serviceOrder(kk))) = kk;
end
tmpCovI(isnan(tmpCovI)) = -999;
tmpCovI(~isnan(waterArea)) = NaN;

%create the label texts and label positions in the colorbar
tlabel = ['no coverage'];
plabel = [0.5];
for kk = 1:numServices
   tlabel = strvcat(tlabel, [num2str(speed(serviceOrder(kk))) ' km/h']);
   tlabel = strvcat(tlabel, [num2str(bitrate(serviceOrder(kk))/1000) ' kbps, ']);
   plabel = [plabel kk+.4 kk+.6];
end

%set the colors
color1 = color(serviceOrder, :);

%finally plot the whole stuff
figure
pcolor(xmin:resolution:xmax, ...
       ymin:resolution:ymax, ...
       tmpCovI);
colormap([[0 0 0]; color1]);
caxis([0 numServices+1]);
hcb = colorbar('vert');
titleText = ['Composite UL coverage' layerString];
title(['\it{', titleText, '}']);
shading('flat');
axis('image');
set(get(hcb, 'Title'), 'String', 'Service');
set(hcb, 'ytick', plabel);
set(hcb, 'yticklabel', tlabel);
set(hcb, 'ticklength', [0 0]);
BSplot(basestation, gcf, vectMap, lossData);
clear tlabel plabel dummy tmpCovI covI covV1 covV indAllCov serviceOrder color1 layerString hcb
