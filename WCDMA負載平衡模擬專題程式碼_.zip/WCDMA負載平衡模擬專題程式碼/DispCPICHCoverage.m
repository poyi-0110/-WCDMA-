%DISPCPICHCOVERAGE   DISPCPICHCOVERAGE displays the CPICH coverage
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m BSselect.m

if (~exist('coverageFig')&~exist('compCPICHCovFlag')&~exist('allCPICHCovFlag'))
   h0 = BSselect(4);
   uiwait(h0);
   %if no BS has been selected and mistakenly comp. coverage for selected cells is ticked
   if isempty(wantedBSs)
      clear compCPICHCovFlag;
   end
   %if nothing has been selected
   if (~exist('coverageFig')&~exist('compCPICHCovFlag')&~exist('allCPICHCovFlag'))
      msgbox('Nothing to do - returning !!!');
      return
   end
else
   ud1 = get(gca, 'userdata');
end

if (~exist('coverageFig')&~isempty(wantedBSs))
   coverageFig = 1;
   hFigs = [];
   hAxes = [];
   for wantedBS = wantedBSs
      hFig = figure;
      hFigs = [hFigs hFig];
      hAxis = gca;
      hAxes = [hAxes hAxis];
      set(hFig, ...
         'deletefcn', ['figure(gcbo), hFigs = setdiff(hFigs, gcbo); ' ...
            'hAxes = setdiff(hAxes, gca); ' ...
            'ud = get(gca, ''userdata'');' ...
            'wantedBSs = setdiff(wantedBSs, ud.actBS);' ...
            'if ~isempty(hFigs),' ...
            '   for axisNr = hAxes' ...
            '      ud = get(axisNr, ''userdata'');' ...
            '      ud.wantedBSs = wantedBSs;' ...
            '      set(axisNr, ''userData'', ud);' ...
            '   end,' ...
            'else,'...
            '   hTemp = (findobj(''Tag'', ''allCPICHCovFig1''));' ...
            '   if ~isempty(hTemp), ' ...
            '      tmpUd = get(hTemp, ''userData'');' ... 
            '      tmpUd.wantedBSs = [];' ...
            '      set(hTemp, ''userData'', tmpUd);' ...
            '   end,'...
            '   hTemp = (findobj(''Tag'', ''allCPICHCovFig2''));' ...
            '   if ~isempty(hTemp), ' ...
            '      tmpUd = get(hTemp, ''userData'');' ... 
            '      tmpUd.wantedBSs = [];' ...
            '      set(hTemp, ''userData'', tmpUd);' ...
            '   end,'...
            '   clear compCPICHCovFlag coverageFig hTemp tmpUd;', ...
            '   clear coverageFig;', ...
            'end,', ...
            'if isempty(intersect(wantedBSs, indBStype1)),', ...
            '   hTemp = (findobj(''Tag'', ''compCPICHCovFig1''));' ...
            '   if ~isempty(hTemp), ' ...
            '      close(hTemp);' ...
            '   end,'...
            'end,', ...
            'if isempty(intersect(wantedBSs, indBStype2)),', ...
            '   hTemp = (findobj(''Tag'', ''compCPICHCovFig2''));' ...
            '   if ~isempty(hTemp), ' ...
            '      close(hTemp);' ...
            '   end,'...
            'end,', ...
            'if exist(''hcAxis''),' ...
            '   ud = get(hcAxis, ''userdata'');' ...
            '   ud.wantedBSs = wantedBSs;' ...
            '   set(hcAxis, ''userData'', ud);' ...
            'end,' ...
            'if exist(''haAxis''),' ...
            '   ud = get(haAxis, ''userdata'');' ...
            '   ud.wantedBSs = wantedBSs;' ...
            '   set(haAxis, ''userData'', ud);' ...
            'end,'], ...
         'Tag', 'coverageFig');
      hMenu = uimenu(...
         'Parent', hFig, ...
         'Label', '&Scaling', ...
         'Tag', 'tagScaling', ...
         'Callback', 'Scaling');
      ud = struct(...
         'minValue', -110, ...
         'maxValue', -60, ...
         'stepSize', 5, ...
         'curColMap', 'jet', ...
         'curFig', hFig, ...
         'curAxis', hAxis, ...
         'curFun', 'DispCPICHCoverage', ...
         'actBS', wantedBS, ...
         'wantedBSs', wantedBSs);
      set(gca, 'userdata', ud);
     ud1 = ud;
  end
elseif (exist('coverageFig')&~isempty(wantedBSs))
   wantedBSs = ud1.wantedBSs;
else 
   clear coverageFig
end

figNr = 1;
for wantedBS = wantedBSs
   figure(hFigs(figNr));
   ud = get(gca, 'userdata');
   if (exist('coverageFig'))
      ud.minValue = ud1.minValue;
      ud.maxValue = ud1.maxValue;
      ud.stepSize = ud1.stepSize;
      ud.curColMap = ud1.curColMap;
   end
   
   CPICHStrength1 = squeeze(CPICHStrength(wantedBS, :, :));
   CPICHStrength1(find(CPICHStrength1 < ud.minValue)) = ud.minValue-ud.stepSize;
   CPICHStrength1(~isnan(waterArea)) = NaN;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          CPICHStrength1);
   set(gca, 'userdata', ud); %don't delete - pcolor clears the userdata - heck why?
   ud = get(gca, 'userdata');
   caxis([ud.minValue-ud.stepSize ud.maxValue]);
   eval(['colors1 = ' ud.curColMap ,'(round((ud.maxValue-ud.minValue)/ud.stepSize));']);
   colormap([[1 1 1]; colors1]);
   hcb = colorbar;
   axis('equal');
   str1 = num2str(wantedBS);
   ks = num2str(wantedBS);
   header = ['CPICH coverage of BS_' ks(1)];
   if (wantedBS >= 10)
      header = [header '_' ks(2)];
   end
   title(['\it{}' header]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'RX Lev CPICH');
   set(hcb, 'Ytick', [ud.minValue-ud.stepSize:ud.stepSize:ud.maxValue]);
   set(hcb, 'yticklabel', strcat(num2str(str2num(get(hcb, 'yticklabel'))), ' dBm'));
   tlabel = get(hcb, 'yticklabel');
   set(hcb, 'yticklabel', str2mat(['no coverage'], tlabel(2:end, :)));
   BSplot(basestation, gcf, vectMap, lossData);
   drawnow
   figNr = figNr+1;
end

%composite coverage for selected cells only
tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for runLayer = tmpLayer
   if runLayer == 1
      tmpWantedBSs = intersect(wantedBSs, indBStype1);
   else
      tmpWantedBSs = intersect(wantedBSs, indBStype2);
   end
   if isempty(tmpWantedBSs)
      break
   end
   
   if exist('compCPICHCovFlag') & compCPICHCovFlag
      if (~exist(['compCPICHCovFig' num2str(runLayer)]))
         eval(['compCPICHCovFig' num2str(runLayer) ' = 1;']);
         hFig = figure;
         hcAxis = gca;
         tagString  = ['compCPICHCovFig' num2str(runLayer)];
         deleteFunc = [...
               'clear hcAxis compCPICHCovFig' num2str(runLayer) ' ' ...
               'compCPICHCovFlag' num2str(runLayer) ';' ...
               'if ~exist(''compCPICHCovFig1'')&~exist(''compCPICHCovFig1''),' ...
               '   clear compCPICHCovFlag;' ...
               'end'];
         set(hFig, ...
            'DeleteFcn', deleteFunc, ...
            'Tag', tagString);
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', -110, ...
            'maxValue', -60, ...
            'stepSize', 5, ...
            'curColMap', 'jet', ...
            'curFig', hFig, ...
            'curAxis', hcAxis, ...
            'curFun', 'DispCPICHCoverage', ...
            'actBS', [], ...
            'wantedBSs', wantedBSs);
         set(gca, 'userdata', ud);
         ud1 = ud;
      else
         figure(findobj('Tag', ['compCPICHCovFig' num2str(runLayer)]));
      end
      
      ud = get(gca, 'userdata');
      if (exist(['compCPICHCovFig' num2str(runLayer)]))
         ud.minValue = ud1.minValue;
         ud.maxValue = ud1.maxValue;
         ud.stepSize = ud1.stepSize;
         ud.curColMap = ud1.curColMap;
      end
      
      if runLayer == 1
         tmpWantedBSs = intersect(wantedBSs, indBStype1);% wantedBSs(wantedBSs<=numBSsOp1);
      else
         tmpWantedBSs = intersect(wantedBSs, indBStype2);
      end
      
      if isempty(tmpWantedBSs)
         close(gcf);
         break
      end
      
      compCPICHLevel = squeeze(max(CPICHStrength(tmpWantedBSs, :, :), [], 1));
      compCPICHLevel(find(compCPICHLevel < ud.minValue)) = ud.minValue-ud.stepSize; 
      compCPICHLevel(~isnan(waterArea)) = NaN;
      pcolor(xmin:resolution:xmax, ...
             ymin:resolution:ymax, ...
             compCPICHLevel);
      set(gca, 'userdata', ud); %don't delete - pcolor clears the userdata - heck why?
      eval(['colors1 = ' ud.curColMap '(' num2str(round((ud.maxValue-ud.minValue)/ud.stepSize)) ');']);
      caxis([ud.minValue-ud.stepSize ud.maxValue]);
      colormap([[1 1 1]; colors1]);
      hcb = colorbar;
      axis('equal');
      titleText = 'composite CPICH coverage';
      if numBStype1 & numBStype2
         if mode == 1
            titleText = [titleText ' - for carrier ' num2str(runLayer)];
         elseif mode == 2
            titleText = [titleText ' - for operator ' num2str(runLayer)];
         end
      else
         titleText = titleText; % ;-))
      end
      titleText = [titleText ' - selected cells'];
      title(['\it{}' titleText]);
      shading('flat')
      set(get(hcb, 'Title'), 'String', 'CPICH RX LEV');
      set(hcb, 'Ytick', [ud.minValue-ud.stepSize:ud.stepSize:ud.maxValue]);
      set(hcb, 'yticklabel', strcat(num2str(str2num(get(hcb, 'yticklabel'))), ' dBm'));
      tlabel = get(hcb, 'yticklabel');
      set(hcb, 'yticklabel', str2mat(['no coverage'], tlabel(2:end, :)));
      BSplot(basestation, gcf, vectMap, lossData);
      drawnow
   else
      %clear compCPICHCovFlag
   end
end

%Composite CPICH coverate for all BSs in each operators network
tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for runLayer = tmpLayer
   if exist('allCPICHCovFlag') & allCPICHCovFlag
      if (~exist(['allCPICHCovFig' num2str(runLayer)]))
         eval(['allCPICHCovFig' num2str(runLayer) ' = 1;']);
         hFig = figure;
         haAxis = gca;
         tagString  = ['allCPICHCovFig' num2str(runLayer)];
         deleteFunc = [...
               'clear haAxis allCPICHCovFig' num2str(runLayer) ' ' ...
               'allCPICHCovFlag' num2str(runLayer) ',' ...
               'if ~exist(''allCPICHCovFig1'')&~exist(''allCPICHCovFig1''),' ...
               '   clear allCPICHCovFlag;' ...
               'end'];
         set(hFig, ...
            'DeleteFcn', deleteFunc, ...
            'Tag', tagString);
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', -110, ...
            'maxValue', -60, ...
            'stepSize', 5, ...
            'curColMap', 'jet', ...
            'curFig', hFig, ...
            'curAxis', haAxis, ...
            'curFun', 'DispCPICHCoverage', ...
            'actBS', [], ...
            'wantedBSs', wantedBSs);
         set(gca, 'userdata', ud);
         ud1 = ud;
      else
         figure(findobj('Tag', ['allCPICHCovFig' num2str(runLayer)]));
         ud = get(gca, 'userdata');
         ud.minValue = ud1.minValue;
      end
      
      ud = get(gca, 'userdata');
      
      if (exist(['allCPICHCovFig' num2str(runLayer)]))
         ud.minValue = ud1.minValue;
         ud.maxValue = ud1.maxValue;
         ud.stepSize = ud1.stepSize;
         ud.curColMap = ud1.curColMap;
      end
      
      if runLayer == 1
         range = indBStype1;
      else
         range = indBStype2;
      end
      allCPICHLevel = squeeze(max(CPICHStrength(range, :, :), [], 1));
      allCPICHLevel(find(allCPICHLevel < ud.minValue)) = ud.minValue-ud.stepSize; 
      allCPICHLevel(~isnan(waterArea)) = NaN;
      pcolor(xmin:resolution:xmax, ...
             ymin:resolution:ymax, ...
             allCPICHLevel);
      set(gca, 'userdata', ud); %don't delete - pcolor clears the userdata - heck why?
      eval(['colors1 = ' ud.curColMap '(' num2str(round((ud.maxValue-ud.minValue)/ud.stepSize)) ');']);
      caxis([ud.minValue-ud.stepSize ud.maxValue]);
      colormap([[1 1 1]; colors1]);
      hcb = colorbar;
      axis('equal');
      titleText = 'composite CPICH coverage';
      if numBStype1 & numBStype2
         if mode == 1
            titleText = [titleText ' - for carrier ' num2str(runLayer)];
         elseif mode == 2
            titleText = [titleText ' - for operator ' num2str(runLayer)];
         end
      else
         titleText = titleText; %;-))
      end
      titleText = [titleText ' - all cells'];
      title(['\it{}' titleText]);
      shading('flat')
      set(get(hcb, 'Title'), 'String', 'CPICH RX LEV');
      set(hcb, 'Ytick', [ud.minValue-ud.stepSize:ud.stepSize:ud.maxValue]);
      set(hcb, 'yticklabel', strcat(num2str(str2num(get(hcb, 'yticklabel'))), ' dBm'));
      tlabel = get(hcb, 'yticklabel');
      set(hcb, 'yticklabel', str2mat(['no coverage'], tlabel(2:end, :)));
      BSplot(basestation, gcf, vectMap, lossData);
      drawnow
   else
      %clear allCPICHCovFlag
   end
end
clear wantedBS wantedBSstr k l ks 
