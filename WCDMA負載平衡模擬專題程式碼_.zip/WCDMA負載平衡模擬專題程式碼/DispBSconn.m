%DISPBSCONN   [MS NUMCONN] = DISPBSCONN(BSNR) displays all the connections the base
%             station BSNR is having
%
%Inputs:
%   bsNr          : the wanted BS
%   from evalin:
%   basestation   : the basestation structure
%   mobilestation : the mobilestation structure
%   bsTxPowerLin  : the link powers (to determine the connections)
%   area          : the borders of the network area
%   resolution    : the resolution of the map
%Outputs:
%   ms            : the ms's to which the bs has connections
%   numconn       : the number of connections
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

function [ms, numconn] = DispBSconn(bsNr, vectMap, lossData)

basestation   = evalin('base', 'basestation');
bsTxPowerLin  = evalin('base', 'bsTxPowerLin');
mobilestation = evalin('base', 'mobilestation');
area          = evalin('base', 'area');
resolution    = evalin('base', 'resolution');
indBStype1    = evalin('base', 'indBStype1');
indBStype2    = evalin('base', 'indBStype2');
numBStype1    = evalin('base', 'numBStype1');
numBStype2    = evalin('base', 'numBStype2');
numBSs        = length(basestation);
mode          = evalin('base', 'mode');

for kk1 = bsNr
   figure
   BSplot(basestation, gcf, vectMap, lossData);
   hold on
   ms      = find(bsTxPowerLin(kk1, :));
   numconn = length(ms);
   if ~numconn
      title([char(basestation(kk1).nameLong) ' has no connections']);
      return;
   end
   offset = 1.25*max(area(2)-area(1), area(4)-area(3))/25;
   if  ismember(kk1, indBStype2)
      bsColor = 'r';
   else
      bsColor = 'g';
   end
   hl1 = line([[mobilestation(ms).x]; repmat([basestation(kk1).x]+offset/2*cos((90-[basestation(kk1).antennaDir])*pi/180), 1, numconn)], ...
              [[mobilestation(ms).y]; repmat([basestation(kk1).y]+offset/2*sin((90-[basestation(kk1).antennaDir])*pi/180), 1, numconn)], ...
              'color', bsColor);
   
   titleText = '';
   if numconn < 10
      titleText = strvcat(titleText, int2str(ms));
   else
      for kk = 1:floor(numconn/10)
         titleText = strvcat(titleText, int2str(ms((kk-1)*10+1:kk*10)));
      end
      if 10*kk < numconn
         titleText = strvcat(titleText, int2str(ms(10*kk+1:numconn)));
      end
   end
   
   titleText1 = ['Connections of ' char(basestation(kk1).nameLong)];
   title(['\it{' titleText1 '}']);
   plot([mobilestation(ms).x], [mobilestation(ms).y], [bsColor '.'])
   offset = max(area(2)-area(1), area(4)-area(3))/25;
   hl2 = line([[basestation(kk1).x]; [basestation(kk1).x]+offset*cos((90-[basestation(kk1).antennaDir])*pi/180)], ...
              [[basestation(kk1).y]; [basestation(kk1).y]+offset*sin((90-[basestation(kk1).antennaDir])*pi/180)], 'Color', 'r');
   offset = offset*1.25;
   ht  = text([basestation(kk1).x]+offset*cos((90-[basestation(kk1).antennaDir])*pi/180), ...
              [basestation(kk1).y]+offset*sin((90-[basestation(kk1).antennaDir])*pi/180), ...
              basestation(kk1).name);
   set(ht, 'FontSize', 9);
   set(ht, 'FontWeight', 'bold');
   set(ht, 'Color', bsColor);
   hold off
   axis equal
   axis(area);
   msgbox(strvcat(['BS ' num2str(kk1) ' is connected to MS(s):'], titleText))
end
