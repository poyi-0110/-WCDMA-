%TWOTAPLINKPERFTABLES   TWOTAPLINKPERFTABLES consists of the Eb/No, SHO gain etc. tables,
%                       as a function of used MS speed. The tables have been written based
%                       on link level simulation results. When this script is run, a structure
%                       linkPerfTables will be formed which has all the information from the
%                       tables.
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%NOTE THIS IS ONLY A DRAFT VERSION OF THE TWO TAP

%Used bit rates (64k, 144k, 512k packet data)
linkPerfTables.bitRates = ...
   [8000 12200 64000 144000 512000];

%Voice activity factors for the differenr bit rates 
% 	in uplink
linkPerfTables.vUL = ...
   [0.67 0.67 1.0 1.0 1.0];
%	in downlink
linkPerfTables.vDL = ...
   [0.67 0.67 1.0 1.0 1.0];

%Specified speeds. Other speeds will be interpolated.
linkPerfTables.speeds = ...
   [3 20];

linkPerfTables.orthogonality = ...
   [0.75 0.7];

%Rows: specified bit rates
%Columns: specified speeds
%Dimensions must match to dimensions of linkPerfTables.bitRates 
%and linkPerfTables.speeds.

%Received Eb/No requirement in uplink as a function
%of speed. 12200 144000 from mika r document.
%Note: only a few speeds have been simulated for 12.2 kbps and 144 kbps.
%      The rest has been interpolated.
%      8000 kbps is more accurate.
linkPerfTables.EbNoUL = ...
   [5.0 5.5;
    4.0 4.5;   
    2.5 3.0;
    2.0 2.5;
    1.5 2.0];

%Received Eb/No requirement in downlink as a function of speed.
linkPerfTables.EbNoDL = ...
   [9.4 8.7;
    8.4 7.7;
    6.9 6.2;
    5.9 5.2;
    5.4 4.7];
   
%Average Tx power raise in uplink due to the TPC following the multipath
%fading.
linkPerfTables.AvPRUL = ...
   [1.3 1.0];

%Average Tx power raise in downlink due to the TPC following the multipath
%fading. AvPRDL are only rough approximations and not used in NPSW 2.0
linkPerfTables.AvPRDL = ...
   [5.0 4.5];

%Required multipath fading margin for MS transmitter compared to the average
%recieved levelin the single link case.
linkPerfTables.HRUL = ...
   [5.6 2.7]; 

%SHO gains as function of link difference between best server and the
%next best server.

%Specified link differences (the rest will be interpolated)
linkPerfTables.shoDifferences = ...
   [0 3 6 10]';

%SHO selection combining gains as a function of speed and link difference.
%Rows: link difference, columns: speed.

%SHO gain in average received power of the better cell.

linkPerfTables.RxPowSHOgainUL = ...
   [ 0.8  1.0;  % 0 dB diff
    -0.1  0.2;  % 3 dB diff
    -0.2 -0.2;  % 6 dB diff
    -0.2 -0.2]; %10 dB diff

% SHO gain in average transmitted power of the better cell
linkPerfTables.TxPowSHOgainUL = ...
   [ 1.6  1.6;  % 0 dB diff
     0.5  0.5;  % 3 dB diff
     0.1  0.1;  % 6 dB diff
    -0.1 -0.1]; %10 dB diff

% SHO gain in required fading margin above the 
% single link average received Eb/No. 
linkPerfTables.HRSHOgainUL = ...
   [3.1 1.7;  % 0 dB diff
    2.0 1.2;  % 3 dB diff
    1.3 0.5;  % 6 dB diff
    1.1 0.0]; %10 dB diff

% SHO gain in total received Eb/No + av. power raise
linkPerfTables.TxPowSHOgainDL = ...
   [1.1  0.8;  % 0 dB diff
    0.8  0.6;  % 3 dB diff
    0.2  0.0;  % 6 dB diff
    0.0 -0.2]; %10 dB diff
