%MSGENER3    MSGENER3 adds or removes mobiles in selected areas in the mobile
%            station parameter file specified in npswini. In the end MSs can be
%            saved to a new file.
%
%Inputs:  none
%Outputs: new MS parameter file
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Heiska (KHe)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: npswsys.m, npswini.m, mapini.m, BSread.m, MSread.m, BSplot.m,
%                mob_inside.m, Polygon.m, Poly1.m

close all;
npswsys
npswini
mapini

[basestation numBSs] = BSread(bsParamFile, pathlossModel, lossData);
MSread;
x = [mobilestation.x]';
y = [mobilestation.y]';

area = lossData(1).area;
corner = lossData(1).corner; %lower left corner of the map area
figure
plot(x, y, '.r');
hold on
[hl, ht] = BSplot(basestation, gcf, vectMap, lossData);

disp('reduce mobiles')
pois = 1;
while 1
   pois = input('mobiles to be removed (0-100%, -1 = goto adding mobiles)')
   if pois < 0;
      break;
   end
   disp('enter area where to reduce mobiles by mouse (+right click)')
   %[x0, y0]  = ginput;
   plgn = Polygon;
   x0 = plgn(:, 1);
   y0 = plgn(:, 2);
   inpoints  = mob_inside([x0 y0], [x y]);
   linpoints = length(find(inpoints));
   outpoints = find(1-inpoints);inpoints = find(inpoints);
   if pois < 100;
      x = [x(outpoints); x(inpoints(1:fix((100-pois)/100*linpoints)))];
      y = [y(outpoints); y(inpoints(1:fix((100-pois)/100*linpoints)))];
   else
      x = x(outpoints);
      y = y(outpoints);
   end
   [linpoints pois/100*linpoints]
   hold off;
   close all;
   plot(x, y, '.r');
   hold on
   [hl, ht] = BSplot(basestation, gcf, vectMap, lossData);
end

disp('adding mobiles')
lis = 1;

while lis >= 0
   lis = input('mobiles to be added (>0%), -1 = finish)')
   if lis < 0;
      break;
   end
   disp('enter area where to add mobiles by mouse (+right click)')
   plgn = polygon;
   x0 = plgn(:, 1);
   y0 = plgn(:, 2);
   test = mob_inside([x0 y0], [x y]);
   if isempty(find(test))
      lisabs = input('no previous mobiles, how many to add? ')
   else
      lisabs = length(find(test))*lis/100;
   end
   maxx = max(x0);
   maxy = max(y0);
   minx = min(x0);
   miny = min(y0);
   lev  = maxx-minx;
   kork = maxy-miny;
   xlis = minx+(rand(lisabs*10, 1)*lev);
   ylis = miny+(rand(lisabs*10, 1)*kork);
   inpoints = mob_inside([x0 y0], [xlis ylis]);
   xlis = xlis(find(inpoints));
   xlis = xlis(1:lisabs);
   ylis = ylis(find(inpoints));
   ylis = ylis(1:lisabs);
   lisabs
   x = [x; xlis];
   y = [y; ylis];
   hold off
   close all;
   plot(x, y, '.r');
   hold on
   [hl, ht] = BSplot(basestation, gcf, vectMap, lossData);
end

tmpOnes = ones(length(x), 1);
msdata = [x y zeros(length(x), 1) 1.5*tmpOnes 24*tmpOnes 1.5*tmpOnes ...
          1.5*tmpOnes 8000*tmpOnes tmpOnes 3*tmpOnes];
msFile = input('Name of the MS parameter file (without extension): ', 's');
eval(['save ', msFile, '.txt msdata -ascii'])
clear all
close all
