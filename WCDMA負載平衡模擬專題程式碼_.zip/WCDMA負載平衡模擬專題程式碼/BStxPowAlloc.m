%BSTXPOWALLOC   BSTXPOWALLOC initialises the memory for initial BS transmit powers and outages
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

bsTxPower = zeros(numBSs, numMSs);
bsTxPowerLin = zeros(numBSs, numMSs);
bsTxPowerLin(activeSetM) = 1e-28;
bsTxPower(activeSetM) = lin2log(1e-28);

outageDL = zeros(numBSs, numMSs);
