%CPICHPOWALLOC   BASESTATION = CPICHPOWERALLOC(BASESTATION, PERF, MAXCPICHPOWER,
%                                              CPICHPOWERSWITCH)
%                allocates the CPICH powers for all basestations
%
%Inputs:
%   BASESTATION     : array of basestation structures
%   PERF            : array of performance structures
%   MAXCPICHPOWER   : maximum allowed CPICH power
%   CPICHPOWERSWITCH: 1: all BSs have same CPICH power (MAXCPICHPOWER)
%                     2: BS with best sensitivity has higest CPICH power (MAXCPICHPOWER)
%                        other BSs CPICHs are adjusted with the differnce in sensitivity
%                     3: CPICH power is set freely (taken from the basestation structure)
%Outputs:
%   BASESTATION     : array of basestation structures
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function basestation = CPICHPowAlloc(basestation, perf, maxCPICHPower, CPICHPowerSwitch)

switch CPICHPowerSwitch
case 2
   for k = 1:length(basestation)
      basestation(k).CPICHPower = maxCPICHPower-perf(k).covth+min([perf.covth]);
   end
case 1
   [basestation.CPICHPower] = deal(maxCPICHPower);
otherwise
   %nothing
end
