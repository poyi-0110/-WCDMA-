%DISPMSTXPOWER   DISPMSTXPOWER displays a histogram of the TCH TX power of the mobile stations

%Inputs:
%Outputs:   
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   eval(['hFig = findobj(''Tag'', ''MSTXPOWER' num2str(layer) ''');']);
   if isempty(hFig)
      hFig = figure;
      eval(['set(hFig, ''Tag'', ''MSTXPOWER' num2str(layer) ''');']);
   else
      figure(hFig)
   end
   
   eval(['range = indMStype' num2str(layer) ';']);
   
   tmpPower = [mobilestation(range).txPower]; 
   tmpPower = tmpPower(find(tmpPower>-999));
   binSize = 5;
   binMini = 5*floor(min(tmpPower)/5);
   binMaxi = 5*ceil(max(tmpPower)/5);
   
   [a1 b1] = hist(tmpPower, binMini:binSize:binMaxi);
   
   a1 = 100*a1/sum(a1);
   bar(b1, a1);
   titleText = 'Mobile station TX power';
   if numBStype2 & numBStype1
      if mode == 2
         titleText = [titleText ' for operator ' num2str(layer)];
      elseif mode == 1
         titleText = [titleText ' for carrier ' num2str(layer)]; 
      end
   end
   title(['\it{}' titleText]);
   xlabel(['power [dBm]   -   mean: ' num2str(round(100*lin2log(mean(log2lin(tmpPower))))/100) ' dBm, std: ', ...
           num2str(round(100*lin2log(std(log2lin(tmpPower))))/100) ' dBm']);
   ylabel('percentage');
   set(gca, 'Xlim', [binMini-2*binSize binMaxi+2*binSize]);
   maxY = get(gca, 'Ylim');
   text(b1(1), maxY(2)/10, ['min: ' num2str(round(100*min(tmpPower))/100) ' dBm']);
   text(b1(end), maxY(2)/10, ['max: ' num2str(round(100*max(tmpPower))/100) ' dBm'], ...
                              'HorizontalAlignment', 'left');
   text(b1(1), maxY(2)*0.90, ['max. allowed: ' num2str(round(100*max([mobilestation(range).txMaxPower]))/100) ' dBm']);
   text(b1(1), maxY(2)*0.85, ['min. allowed: ' num2str(round(100*min([mobilestation(range).txMinPower]))/100) ' dBm']);
end
clear tmpPower hFig a1 b1 maxY binMini binMaxi binSize layer titleText
