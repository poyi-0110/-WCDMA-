%CREATECHANNELMATRICES   CREATECHANNELMATRICES creates vectors and matrices holding a channel index
%                        which can be used to refer to a linkPerfTables in the array linkPerf of all
%                        linkPerfTables. Also the mobilestation and basestation specific link performance
%                        parameters are calculated here. Channel is originally a BS parameter and
%                        based on minimum linkloss from different base stations a channel is chosen for
%                        mobilestations and pixels.
%
%Inputs:
%   basestation : array of base station structures. The field .channel is used as input.
%   linklossDL  : DL linklosses from all BS:s to all pixels
%   yPixels     : number of pixels in the map, in y direction
%   xPixels     : number of pixels in the map, in x direction
%   indBStype1/2: indices of BSs of type 1/2
%
%Outputs:
%   channels    : vector of channel indeces found in the scenario
%   numChannels : number of channels found in the scenario
%   channelMap  : yPixels x xPixels matrix of channel indeces to each pixel. This 
%                 is determined by the BS with minimum linkloss to the pixel.
%   
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

channels    = unique([basestation.channel]);
numChannels = length(channels);
channelMap  = zeros([2 yPixels xPixels]);
tmpBsChan   = [basestation.channel];

%Operator/Carrier runType
for runType = 1:2
   eval(['indBStypeX = indBStype' num2str(runType) ';']);
   if ~isempty(indBStypeX)
      [tmpMindist, tmpIMindist] = min(linklossDL(indBStypeX, :, :), [], 1);
      channelMap(runType, :) = tmpBsChan(indBStypeX(tmpIMindist(:)));
   end
end

clear tmp* runType
