%DISPGENERICCOV   DISPGENERICCOV is a generic function to plot area coverage probabilities
%
%Inputs:
%Outputs:   
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

function [hcf, hcb] = DispGenericCov(covMatrix, covThreshold, baseString, mode, layer, lossData, basestation, vectMap, ...
                                     waterArea, resolution, xmin, ymin, xmax, ymax, numBStype2, lowerLimit, upperLimit)

tmpCovMatrix = covMatrix;
tmpCovMatrix(covMatrix>upperLimit)   = upperLimit;
tmpCovMatrix(covMatrix<lowerLimit)   = lowerLimit;
tmpCovMatrix(covMatrix<covThreshold) = lowerLimit-1;

tmpCovMatrix(~isnan(waterArea)) = NaN;

hcf = figure;
pcolor(xmin:resolution:xmax, ...
       ymin:resolution:ymax, ...
       tmpCovMatrix);
CIcolors = hsv(32);
colormap(flipud([CIcolors(8:32, :); [0 0 0]]));
caxis([lowerLimit-1 upperLimit]);
hold on
hcb = colorbar('vert');
BSplot(basestation, gcf, vectMap, lossData);
if numBStype2
   if mode == 1
      if layer == 0, 
         layerString = [', combined for all carriers'];
      else
         layerString = [' for carrier ' num2str(layer)];
      end
   elseif mode == 2
      layerString = [' for operator ' num2str(layer)];     
   end
   titleText = [baseString layerString ];
else
   titleText = [baseString];
end 
title(['\it{', titleText, '}']);
axis('image');
shading('flat');
set(get(hcb, 'Title'), 'String', baseString);
set(hcb, 'yticklabel', strcat(get(hcb,'yticklabel'), ' dB'));
hold off
