%DISPUSERDELTAGENERIC   DISPUSERDELTAGENERIC displays all the users which are not served due to the given outage reason, 
%                       indicating bit rates by different icons and colors.
%
%Inputs:  (global) mobilestation, basestation, numBSs, numMSs, xPos, yPos,
%         xmin, xmax, ymin, ymax, resolution, outageReason (given from the UI callback in DispPPmenu)
%Outputs:
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

if (~exist('outageReason'))
   outageReason = 0;
end

switch outageReason
case 0
   outageText = 'not served';
case -1
   outageText = 'not served because of hard blocking';
case -2
   outageText = 'not served because of MS max power limit';
case -3
   outageText = 'not served because of BS Tx power per link limitation';
case -4
   outageText = 'not served because of total BS Tx power limitation';
case -5
   outageText = 'not served because of Ueta';
case -6
   outageText = 'not served because of too bad P-CPICH Ec/Io';
otherwise
   errorDlg([num2str(outageReason) ' is not an allowed outage reason !!!'] ,'outage reason error');
end

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   eval(['tmpInd = numBStype' num2str(layer) ';']);
   tmpInd = find([mobilestationOri.usedCarr] == layer);
   eval(['tmpInd = setdiff(tmpInd, indMStype' num2str(layer) ');']);
   tmpMSs = mobilestation(tmpInd);
   
   colors = 'gbrgbrgbr';
   marker = '...***ooo';
   ii = 1;
   figure;
   set(gcf, 'Tag', 'tagUserFig');
   hold on
   bitRates = unique([[mobilestation.RUL] [mobilestation.RDL]]);
   if length(bitRates) > 9
      bitRates = bitRates(1:9);
   end
   numOut = [];
   userDelta = 0;
   lBitRates = [];
   for tmpRate = bitRates
      if outageReason == 0
         ind1 = find([tmpMSs.RUL] == tmpRate & [tmpMSs.usedCarr] < 0);
      else
         ind1 = find([tmpMSs.RUL] == tmpRate & [tmpMSs.usedCarr] == outageReason);
      end
      plot([tmpMSs(ind1).x], [tmpMSs(ind1).y], [marker(ii) colors(ii)]);
      ii = ii+1;
      if ~isempty(ind1)
         lBitRates = [lBitRates; tmpRate];
         numOut = [numOut; length(ind1)];
         userDelta = userDelta+length(ind1);
      end
   end
   
   if (numBStype1 == 0 | numBStype2 == 0)
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end

   titleText = ['USER DISTRIBUTION' layerString ' (' outageText ') (total = ' num2str(userDelta), ' users)'];
   title(['\it{', titleText, '}']);
   axis('equal');
   BSplot(basestation, gcf, vectMap, lossData);
   hLegend = legend(strcat(num2str(lBitRates(:)/1000), ' kBit/s (', num2str(numOut(:)), ')'));
   set(hLegend, 'color', [1 1 1]);
end

%clean up
clear tmpMSs tmpInd bitRates ind1 ii colors marker tmpRate lBitRates layerString layer
clear userDelta outageReason outageText titleText numOut hLegend
