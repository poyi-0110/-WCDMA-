%CALCLINKSPERSERVICE   CALCLINKSPERSERVICE calculates for each cell how many links are using
%                      which bit rate
%
%Inputs:
%Outputs:
%   serviceTypes          : vector holding all used bit rates in the network
%   linksPerCellPerService: (numBSs x numServices) matrix. Each row k holds the number of 
%                           links for each service bit rate at BS k
%
%Authors: Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005

ind = find([mobilestation.usedCarr] >= 1);
serviceTypes = unique([mobilestation(ind).R])

linksPerCellPerService = zeros(numBSs, length(serviceTypes));

for m = 1:numMSs
   if (mobilestation(m).usedCarr >= 1)
      service = find(serviceTypes == mobilestation(m).R);
      bss = find(rxLevels1(:, m));
      linksPerCellPerService(bss, service) = linksPerCellPerService(bss, service)+1;
   end
end

clear ind service bss
