%CREATETRAF  CREATETRAF creates the traffic maps 'user' and 'datarate' from the
%            MS parameter structures
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

user = zeros(2, yPixels, xPixels);
datarate = user;

for k = indMStype1
   if (mobilestation(k).usedCarr >= 1)
      user(1, yPos(k), xPos(k)) = user(1, yPos(k), xPos(k))+1;
      datarate(1, yPos(k), xPos(k)) = datarate(1, yPos(k), xPos(k))+mobilestation(k).RUL;
   end
end

for k = indMStype2
   if (mobilestation(k).usedCarr >= 1)
      user(2, yPos(k), xPos(k)) = user(2, yPos(k), xPos(k))+1;
      datarate(2, yPos(k), xPos(k)) = datarate(2, yPos(k), xPos(k))+mobilestation(k).RUL;
   end
end

%calculate average data rate
ind = find(user);         %avoid division by 0
datarate(ind) = datarate(ind)./user(ind);
clear ind k
