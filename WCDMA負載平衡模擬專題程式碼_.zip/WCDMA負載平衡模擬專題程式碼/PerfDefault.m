%PERFDEFAULT   DEFAULTPERF = PERFDEFAULT() returns a perf struct having default parameters
%
%Inputs:
%   none
%Outputs:
%   DEFAULTPERF: default perf struct
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function defaultPerf = PerfDefault()

defaultPerf.i = .55;
defaultPerf.mUL = 30;
defaultPerf.SHO = .30;
defaultPerf.RUL = 32000;
defaultPerf.covth = -110;
