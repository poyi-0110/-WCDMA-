%REDUCELOAD   REDUCELOAD if Ueta or UetaOwnin radio link budget is too high
%                                      
%Inputs:
%Outputs:
%
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa), Kari Sipil� (KSi)
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed functions: DoIFHO.m, DoSaattohoito.m

indexHL = find(Ueta>[basestation.excessLoadTotal] | UetaOwn>[basestation.excessLoadOwn]);
if isempty(indexHL)
   return
end

disp(['reducing load at BSs: ' num2str(indexHL)]);

msIndGeneric = [];
msIndSaattohoito = [];

%A counter to help seeing whether load could be reduced or not.
tmp_count1 = 0;

if (loadControlSwitch == 1) %random selection of MSs at whole network from same carrier
                            %mobiles not yet put to other carrier chosen as candidates
   for loopType = 1:2
      eval(['indMStypeX = indMStype' num2str(loopType) ';']);
      eval(['numBStypeX = numBStype' num2str(loopType) ';']);
      if numBStypeX == 0 | isempty(indMStypeX)
         continue
      end
      
      if any(ismember(indexHL, numBStypeX)) %carrierX or operatorX; X = 1..2
         msIndHL = find(usedCarrV(indMStypeX)==loopType);
         msIndHL = indMStypeX(msIndHL);
         if (length(msIndHL) > 0)
            %order these randomly to avoid changing the spatial distribution
            msIndHLtemp = randperm(length(msIndHL));	
            msIndHL = msIndHL(msIndHLtemp);
            
            %Try to get the loading just a little below excessLoad
            ind1 = min([ceil(0.97*length(msIndHL)) ...
                        ceil(max([basestation.excessLoadTotal])/max(Ueta)*length(msIndHL)) ...
                        ceil(max([basestation.excessLoadOwn])/max(UetaOwn)*length(msIndHL))]);
            msIndHL = msIndHL(ind1:end);
            
            %set the mobiles to other carrier (2 carrier case) or outage (2 operator case)
            if mode == 1
               tmpInd1 = find(ifhoCounter(msIndHL) < limitIFHO);
               tmpInd2 = find(ifhoCounter(msIndHL) >= limitIFHO);
               tmpInd1 = msIndHL(tmpInd1);
               tmpInd2 = msIndHL(tmpInd2);
               
               if ~isempty(tmpInd1)
                  tmpUsedCarrV = num2cell(1+mod([mobilestation(tmpInd1).usedCarr], 2));
                  [mobilestation(tmpInd1).usedCarr] = deal(tmpUsedCarrV{:});
                  msIndGeneric = [msIndGeneric tmpInd1];
               end
               if ~isempty(tmpInd2)
                  [mobilestation(tmpInd2).usedCarr] = deal(-5);
                  msIndSaattohoito = [msIndSaattohoito, tmpInd2];
                  addCarrNeeded(n) = 1;
               end
            elseif mode == 2
               [mobilestation(msIndHL).usedCarr] = deal(-5);
               msIndSaattohoito = [msIndSaattohoito, msIndHL];
               %set number of used carriers at BS n to 2
               addCarrNeeded(n) = 1;
            else
               error('Wrong mode');
            end
         else
            %loading could not be reduced because no mobiles was left on this carrier.
            tmp_count1 = length(indexHL);
            emptyCells(indBStypeX) = 1;
         end
      end
   end
elseif (loadControlSwitch == 2 | loadControlSwitch == 3)  %high power MSs or random MSs out from high loaded cells
   for n = indexHL
      %find all mobiles at cell n using basestation(n).usedCarr
      msIndHL = find(bestServerV==n & usedCarrV==basestation(n).usedCarr);
      
      %avoid trying to take out from empty cells.
      if (length(msIndHL) > 0)
         if loadControlSwitch == 2  %high power MSs out from high loaded cells
            %get their tx powers and sort them
            [msTempPower msIndHLtemp] = sort([mobilestation(msIndHL).txPower]);
         elseif loadControlSwitch == 3 %random MSs out from high loaded cells
            %order these randomly to avoid changing the spatial distribution within cell
            msIndHLtemp = randperm(length(msIndHL));
         end
         
         %sort msIndHL according to the same sort order
         msIndHL = msIndHL(msIndHLtemp);
         
         %Try to get the loading just a little below excessLoad
         ind1 = min([ceil(0.97*length(msIndHL)) ...
                     ceil(basestation(n).excessLoadTotal/Ueta(n)*length(msIndHL)) ...
                     ceil(basestation(n).excessLoadOwn/UetaOwn(n)*length(msIndHL))]);
         msIndHL = msIndHL(ind1:end);
         
         %change carrier (2 carr case) or set the mobiles to carrier 2 (2 op case)
         if mode == 1
            tmpInd1 = msIndHL(find(ifhoCounter(msIndHL) < limitIFHO));
            tmpInd2 = msIndHL(find(ifhoCounter(msIndHL) >= limitIFHO));
            
            if ~isempty(tmpInd1) %IFHO allowed
               tmpUsedCarrV = num2cell(1+mod([mobilestation(tmpInd1).usedCarr], 2));
               [mobilestation(tmpInd1).usedCarr] = deal(tmpUsedCarrV{:});
               msIndGeneric = [msIndGeneric tmpInd1];
            end
            if ~isempty(tmpInd2) %IFHO not allowed anymore -> outage
               [mobilestation(tmpInd2).usedCarr] = deal(-5);
               msIndSaattohoito = [msIndSaattohoito, tmpInd2];
               addCarrNeeded(n) = 1;
            end
         elseif mode == 2
            [mobilestation(msIndHL).usedCarr] = deal(-5);
            msIndSaattohoito = [msIndSaattohoito, msIndHL];
            %set addCarrNeeded at BS n to 1
            addCarrNeeded(n) = 1;
         else
            error('Wrong mode');
         end
      else
         %if it was an empty cell but loading was too high
         tmp_count1 = tmp_count1+1;
      end
   end
else
   error('Wrong loadControlSwitch');
end

%set loading temporarily back to zero if loading could be reduced 
if (tmp_count1 < length(indexHL))   
   Ueta    = zeros(size(Ueta));
   UetaOwn = zeros(size(UetaOwn));
else
   loadJustReduced = 0;
   disp('WARNING: Loading should have been reduced but could not.');
end

if (mode == 1 & length(msIndGeneric) >= 1)
   DoIFHO;
end

if length(msIndSaattohoito) >= 1
   DoSaattohoito;
end

indMStype1 = find([mobilestation.usedCarr] == 1);
indMStype2 = find([mobilestation.usedCarr] == 2);
numMStype1 = length(indMStype1);
numMStype2 = length(indMStype2);

clear tmp_count1 tmpInd1 tmpInd2 msIndHl msIndHLtemp ind1 k tmpUsedCarrV
clear msIndSaattohoito msIndGeneric loopType
