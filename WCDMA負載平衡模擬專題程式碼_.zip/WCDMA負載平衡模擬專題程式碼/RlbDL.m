%RLBDL   RLBDL calculates the radio link budget for CDMA, based rather much on the excel
%        calculates coverage threshold [dBm] (covth) for downlink
%
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa), Kari Sipil� (KSi),
%         Kai Heikkinen (KHeik)
%Inputs:
%Outputs:
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: log2lin.m

MS_noise_power_lin = log2lin(Thermal_noise_density+MS_noise_figure)*W;

if (numBStype1 & numMStype1 & numBStype2 & numMStype2)
   EbNoCorrectionFactor = -deltaSensitivity-[mobilestation.EbNoDL]+[mobilestation.EbNoUL];
elseif (numBStype1 & numMStype1)
   EbNoCorrectionFactor = -deltaSensitivity(indMStype1)- ...
                          [mobilestation(indMStype1).EbNoDL]+[mobilestation(indMStype1).EbNoUL];
elseif (numBStype2 & numMStype2)
   EbNoCorrectionFactor = -deltaSensitivity(indMStype2)- ...
                          [mobilestation(indMStype2).EbNoDL]+[mobilestation(indMStype2).EbNoUL];
end

indBS = find(bestServDLV);
MSsensitivity(indBS) = [perf(bestServDLV(indBS)).covth]-EbNoCorrectionFactor(indBS);

clear EbNoCorrectionFactor indBS
