%BSPOS   [BASESTATION NUMBSS] = BSPOS(N, BASESTATION, NUMFIG) manual positioning of the BSs
%        on the map
%
%        [BASESTATION NUMBSS] = BSPOS(N)
%                                  create N new BSs in new figure
%        [BASESTATION NUMBSS] = BSPOS(N, BASESTATION)
%                                  add N new BSs to BASESTATION in new figure
%        [BASESTATION NUMBSS] = BSPOS(N, BASESTATION, NUMFIG)
%                                  create/add N new BSs in figure NUMFIG
%
%Inputs:
%   BASESTATION: Structure holding BS parameters (optional)
%   N          : Number of BSs to add
%                if N = -1: add until right mouse click (mandatory)
%   FIGNUM     : figure number of current figure (optional)
%Outputs:
%   BASESTATION: Structure holding BS parameters after adding BSs
%   NUMBSS     : New number of base stations
%
%Authors : Achim Wacker (AWa), Jaana Laiho-Steffens (jls)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot

function [basestation, numBSs] = BSpos(N, basestation, numFig)

vectMap  = evalin('base', 'vectMap');
lossData = evalin('base', 'lossData');

if (nargin == 1)
   activeBS = 0;
   fignum = figure;
   curaxis = [1 10 1 10];
elseif (nargin == 2)
   activeBS = length(basestation);
   fignum == figure;
   curaxis = [1 10 1 10];
elseif (nargin == 3)
   activeBS = length(basestation);
   curaxis = axis;
   fignum = numFig;
else
   error(' wrong number of input arguments');
end

disp(' click with the mouse the positions of the base station(s) ')
figure(fignum);
axis(curaxis);

%disp any old BSs
if (activeBS ~= 0)
   BSplot(basestation, fignum, vectMap, lossData);
end   

if (N == -1)
   while (1)
      activeBS = activeBS+1;
      [x, y, button] = ginput(1);
      basestation(activeBS) = BSdefault;
      basestation(activeBS).x = x;
      basestation(activeBS).y = y;
      BSplot(basestation, fignum, vectMap, lossData);
      axis(curaxis);
      if (button == 3)
         break;
      end
   end
else
   while (N > 0)
      activeBS = activeBS+1;
      [x, y, button] = ginput(1);
      basestation(activeBS) = BSdefault;
      basestation(activeBS).x = x;
      basestation(activeBS).y = y;
      BSplot(basestation, fignum, vectMap, lossData);
      axis(curaxis);
      N = N-1;
   end
end

numBSs = length(basestation);
