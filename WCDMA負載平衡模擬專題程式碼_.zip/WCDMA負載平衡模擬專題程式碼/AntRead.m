%ANTREAD   [GAIN PATTERN] = ANTREAD(ANT_FILENAME) reads the antenna data file
%          [GAIN PATTERN] = ANTREAD() reads the omni antenna data file as default
%          HUOM !!!  Special format required, see latest npsw-doc
%          Pattern is interpolated in 1 degree steps 0...360 deg.
%
%Inputs:
%   ANT_FILENAME: file which contains antenna data (omni if omitted)
%Outputs:
%   GAIN        : gain of the antenna in dBi
%   PATTERN     : (n * 4) matrix holding the pattern
%                  antenna(:,1) = hor. angles - antenna(:,2) hor. attenuations
%                  antenna(:,1) = ver. angles - antenna(:,2) ver. attenuations
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none
%
%Comment: Pattern should be given so that the values are (pos.) attenuation below the
%         main lobe. Main lobe should have the minimum attenuation, preferably 0, but not
%         necessarily. Pattern is corrected in that way that main lobe has attenuation 0 dB.
%         Gain must be in dBi.

function [gain, pattern] = AntRead(antFileName);

if (nargin == 0)
   antFileName = ('omni.ant');
end

antFilePointer = fopen(antFileName, 'rt');
if antFilePointer == -1
   error(['antenna file ''' antFileName '''does not exist!']);
end
k = 0;

%find horizontal pattern
while (1)
   line = fgetl(antFilePointer);
   if (length(line) >= 4)
      if (lower(line(1:4)) == 'gain')
         gain = str2num(fgetl(antFilePointer));
         break
      end
   end
end

line = fgetl(antFilePointer);
if (lower(line(1:10)) ~= 'horizontal')
      errordlg('Error', ['Error in antenna file ' antFileName ', horizontal Pattern section!']);
end
horPattern = fscanf(antFilePointer, '%f %f', [2 inf]);

%read vertical pattern
line = fgetl(antFilePointer);

if (length(line) >= 8)
   if (lower(line(1:8)) ~= 'vertical')
      errordlg('Error', ['Error in antenna file ' antFileName ', vertical Pattern section!']);
   end
   verPattern = fscanf(antFilePointer, '%f %f', [2 inf]);
end

fclose(antFilePointer);

%minimum angles must be 0 and maximum angles must be 360, otherwise inter-
%polation returns NaN for outliers and CreateLinklosses.m produces wrong linklosses
if ((min(horPattern(1,:)) ~= 0) | (max(horPattern(1, :)) ~= 360) | ...
    (min(verPattern(1,:)) ~= 0) | (max(verPattern(1, :)) ~= 360))
   errordlg('Error', ['check minimum and maximum angles in ' antFileName '.']);
end

%interpolate
horPattern = interp1(horPattern(1,:), horPattern(2,:), [0:360], '*linear');
horPattern = horPattern-min(horPattern);
verPattern = interp1(verPattern(1,:), verPattern(2,:), [0:360], '*linear');
verPattern = verPattern-min(verPattern);

pattern = [[0:360]', horPattern', [0:360]', verPattern'];

return
