%DISPDLEBNO      DISPDLEBNO displays the DL Eb/No:s of iterated MS after DL iteration as a histogram
%
%Inputs:
%
%Outputs:
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: log2lin.m lin2log.m

bsTxPowerLin = log2lin(bsTxPower);   %bsTxPower is also 0 (dBm) when there is no connection
bsTxPowerLin(find(bsTxPower==0)) = 0;%!!! ^^^that's the reason for this "adjustment"

%set all the links in bsTxPowerLin to the non zero minimum value 
tmpMat = (bsTxPowerLin > 0);                       %find all nonzero entries
tmpVect = min(bsTxPowerLin + 9e99*(~tmpMat));      %find minimum of ^^^
bsTxPowerLin = tmpMat.*repmat(tmpVect, numBSs, 1); %set all nonzero entries to minimum

IownDL = zeros(numBSs, numMSs);
IothDL = zeros(numBSs, numMSs);
C_over_I_all = zeros(numBSs, numMSs);
C_over_I = zeros(1, numMSs);

msRxPowerLin = zeros(numBSs, numMSs);

bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2) + ...
                  log2lin([basestation.CPICHPower]') + ...
                  log2lin([basestation.commonChannelOther]');
               
for k = 1:numMSs
   for m = 1:numBSs
      if (bsTxPowerLin(m, k)~=0)
         IownDL(m, k) = (1-mobilestation(k).orthFactor) * ...
                        (bsTxPowerTotLin(m)-(mobilestation(k).vDL)*bsTxPowerLin(m, k)) / ...
                        log2lin(linklossDLM(m, k));
         
         msRxPowerLin(m, k) = bsTxPowerLin(m, k)/log2lin(linklossDLM(m, k));
         
         IothDL(m, k) = sum(bsTxPowerTotLin./log2lin(linklossDLM(:, k))) - ...
                        bsTxPowerTotLin(m)/log2lin(linklossDLM(m, k));
      end
   end
end

Itot = IownDL+IothDL+MS_noise_power_lin;

tmpRxPowerLin = msRxPowerLin;
tmpRxPowerLin(msRxPowerLin==0) = 1e-28;
dlEbNo = lin2log(W./[mobilestation.RDL].*sum(tmpRxPowerLin./Itot));

tmpN = hist(dlEbNo, -5:1:20);
figure;
bar(-5:1:20, tmpN);
xlabel('DL Eb/No');
ylabel('Number of MSs');
grid

clear tmpN tmpRxPowerLin 
