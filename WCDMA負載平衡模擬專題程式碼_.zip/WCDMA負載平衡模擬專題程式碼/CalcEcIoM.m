%CALCECIOM   CALCECIOM calculates the Ec/Io for all common pilot channels at all mobile stations
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files:   None

bsTxPowerLin = log2lin(bsTxPower);   %bsTxPower is also 0 (dBm) when there is no connection
bsTxPowerLin(find(bsTxPower==0)) = 0;%!!! ^^^that's the reason for this "adjustment"

%numBSs X numMSs matrix IoM will contain total wideband power for each MS
%so that for BS i on carrier k, the element IoM(i, j) for MS j contains
%the total WB power as MS j would on carrier k. 
%Same rule is applied for CPICHStrengthM giving the received CPICH power 
%and CPICHEcIoM giving the received CPICH Ec/Io.

IoM = zeros(numBSs, numMSs);
CPICHStrengthM = zeros(numBSs, numMSs);
CPICHEcIoM = zeros(numBSs, numMSs);

bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2) + ...
                      log2lin([basestation.CPICHPower]') + ...
                      log2lin([basestation.commonChannelOther]');

IoM = zeros([numBSs, numMSs]);
if numBStype1
   IoM(indBStype1, :) = ones([length(indBStype1), 1])*bsTxPowerTotLin(indBStype1)'*log2lin(-linklossDLM(indBStype1, :));
   if numBStype2
      IoM(indBStype1, :) = IoM(indBStype1, :)+...
                           ones([length(indBStype1), 1])*...
                           (max(log2lin(-acFilterDL(channelOffset))*bsTxPowerTotLin(indBStype2), ...
                            log2lin(acMinPowDL)))'*log2lin(-linklossDLM(indBStype2, :));
   end
end
if numBStype2
   IoM(indBStype2, :) = ones([length(indBStype2), 1])*bsTxPowerTotLin(indBStype2)'*log2lin(-linklossDLM(indBStype2, :));
   if numBStype1
      IoM(indBStype2, :) = IoM(indBStype2, :)+...
                           ones([length(indBStype2), 1])*...
                           (max(log2lin(-acFilterDL(channelOffset))*bsTxPowerTotLin(indBStype1), ...
                            log2lin(acMinPowDL)))'*log2lin(-linklossDLM(indBStype1, :));
   end
end

IoM = lin2log(IoM+log2lin(Thermal_noise_density+MS_noise_figure)*W);
CPICHStrengthM = [basestation.CPICHPower]'*ones([1, numMSs])-linklossDLM;
CPICHEcIoM = CPICHStrengthM-IoM;
