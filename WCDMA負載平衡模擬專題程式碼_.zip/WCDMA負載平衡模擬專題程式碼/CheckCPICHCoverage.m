%CHECKCPICHCOVERAGE   CHECKCPICHCOVERAGE collects to msIndGeneric the MSs to change carrier
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

msIndGeneric1 = [];
msIndGeneric2 = [];

%Collect to msIndSaattohoito the MSs to put permanently to outage
msIndSaattohoito1 = [];
msIndSaattohoito2 = [];

tmpMsInd1 = find([mobilestation.usedCarr]==1);
if length(indBStype1) >= 1 & length(tmpMsInd1) >= 1
   %Find the highest CPICHEcIo 
   [tmpMaxEcIo, tmpMaxEcIoInd] = max(CPICHEcIoM(indBStype1, tmpMsInd1), [], 1);
   %Find the MSs below the CPICHEcIoThreshold 
   tmpIndCPICHOutage = find(tmpMaxEcIo < CPICHEcIoThreshold);
   if length(tmpIndCPICHOutage) >= 1
      %Construct the original MS indeces
      tmpIndCPICHOutage = tmpMsInd1(tmpIndCPICHOutage);
      %Add outage counter for these MSs
      outageCPICH(tmpIndCPICHOutage) = outageCPICH(tmpIndCPICHOutage)+1;
      %Find the MSs for which outage limit is exceeded
      tmpIndCPICHOutageLimitExceeded = find(outageCPICH(tmpIndCPICHOutage) >= limitOutageCPICH);
      if length(tmpIndCPICHOutageLimitExceeded) >= 1
         %Construct the original MS indeces
         tmpIndCPICHOutageLimitExceeded = tmpIndCPICHOutage(tmpIndCPICHOutageLimitExceeded);
         if mode == 1 & length(indBStype2) >= 1
            %find the MSs for which the IF HO is still possible
            msIFHOcountNotExceededInd = (ifhoCounter(tmpIndCPICHOutageLimitExceeded) < limitIFHO);
            if length(msIFHOcountNotExceededInd) >= 1
               %Construct the original MS indeces
               msIndGeneric1 = tmpIndCPICHOutageLimitExceeded(msIFHOcountNotExceededInd);
            end
         end
         msIndSaattohoito1 = setdiff(tmpIndCPICHOutageLimitExceeded, msIndGeneric1);
      end
   end
end

tmpMsInd2 = find([mobilestation.usedCarr]==2);
if length(indBStype2) >= 1 & length(tmpMsInd2) >= 1
   %Find the highest CPICHEcIo 
   [tmpMaxEcIo, tmpMaxEcIoInd] = max(CPICHEcIoM(indBStype2, tmpMsInd2), [], 1);
   %Find the MSs below the CPICHEcIoThreshold 
   tmpIndCPICHOutage = find(tmpMaxEcIo < CPICHEcIoThreshold);
   if length(tmpIndCPICHOutage) >= 1
      %Construct the original MS indeces
      tmpIndCPICHOutage = tmpMsInd2(tmpIndCPICHOutage);
      %Add outage counter for these MSs
      outageCPICH(tmpIndCPICHOutage) = outageCPICH(tmpIndCPICHOutage)+1;
      %Find the MSs for which outage limit is exceeded
      tmpIndCPICHOutageLimitExceeded = find(outageCPICH(tmpIndCPICHOutage) >= limitOutageCPICH);
      if length(tmpIndCPICHOutageLimitExceeded) >= 1
         %Construct the original MS indeces
         tmpIndCPICHOutageLimitExceeded = tmpIndCPICHOutage(tmpIndCPICHOutageLimitExceeded);
         if mode == 1 & length(indBStype1) >= 1
            %find the MSs for which the IF HO is still possible
            msIFHOcountNotExceededInd = (ifhoCounter(tmpIndCPICHOutageLimitExceeded) < limitIFHO);
            if length(msIFHOcountNotExceededInd) >= 1
               %Construct the original MS indeces
               msIndGeneric2 = tmpIndCPICHOutageLimitExceeded(msIFHOcountNotExceededInd);
            end
         end
         msIndSaattohoito2 = setdiff(tmpIndCPICHOutageLimitExceeded, msIndGeneric2);
      end
   end
end

msIndGeneric = [msIndGeneric1, msIndGeneric2];
msIndSaattohoito = [msIndSaattohoito1, msIndSaattohoito2];

%IFHO MSs
if length(msIndGeneric) >= 1
   tmpVect = [mobilestation(msIndGeneric).usedCarr];
   tmpVect = 1+mod(tmpVect, 2);
   tmpVect = num2cell(tmpVect);
   [mobilestation(msIndGeneric).usedCarr] = deal(tmpVect{:}); 
   DoIFHO;
end

%Outage MSs
if length(msIndSaattohoito) >= 1
   [mobilestation(msIndSaattohoito).usedCarr] = deal(-6);
   DoSaattohoito;
end
