%DISPBESTSERVDL   DISPBESTSERVDL plots best servers for downlink
%
%Inputs:
%Outputs:   
%Comment:
%   Best server in this context is that BS whose CPICH is received with highest level
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   bestServerColors1 = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.9 0.9 0.9];
   bestServerColors  = [bestServerColors1' 0.8*bestServerColors1' ...
                        0.6*bestServerColors1(1:5, :)' 0.4*bestServerColors1(1:5, :)']';
   if layer == 1
      while (size(bestServerColors, 1) < numBStype1)
         bestServerColors = [bestServerColors' bestServerColors']';
      end
      tmpNumBSs = length(indBStype1);
      tmpIndBS = indBStype1;
   elseif layer == 2
      while (size(bestServerColors, 1) < numBStype2)
         bestServerColors = [bestServerColors' bestServerColors']';
      end
      tmpNumBSs = length(indBStype2);
      tmpIndBS = indBStype2;
   end
   
   bestServerColors = [[0 0 0]' bestServerColors']';
   
   tmpBestServDL = squeeze(bestServDL(layer, :, :));
   for kk = 1:tmpNumBSs
      tmpBestServDL(find(tmpBestServDL==tmpIndBS(kk))) = kk;
   end
   
   figure
   tmpBestServDL(~isnan(waterArea)) = NaN;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          tmpBestServDL);
   
   if layer == 1
      colormap(bestServerColors(1:tmpNumBSs+1, :));
      caxis([0 tmpNumBSs+1]);
   elseif layer == 2
      colormap(bestServerColors(1:tmpNumBSs+1, :));
      caxis([0 tmpNumBSs+1]);     
   end
   
   hcb = colorbar('vert');
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end  
   title(['\it{}' ['BEST SERVER' layerString ' - based on highest received CPICH power']]);
   shading('flat');
   axis('image');
   set(get(hcb, 'Title'), 'String', 'transmitting BS');
   set(hcb, 'Ytick', [0:tmpNumBSs+1]);
   
   tLabelStr = num2str(tmpIndBS(1));
   for kk = 2:tmpNumBSs
      tLabelStr = str2mat(tLabelStr, num2str(tmpIndBS(kk)));
   end
   set(hcb, 'yticklabel', str2mat(['no coverage'], tLabelStr(1:end, :)));
   set(hcb, 'Ytick', get(hcb, 'Ytick')+0.5);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
end

clear bestServerColors bestServerColors1 hcb tLabelStr layer layerString tmp*
