%DOSAATTOHOITO   DOSAATTOHOITO clears several quantities after mobiles in msIndSaattohoito
%                have beent put to outage
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

if (length(msIndSaattohoito) >= 1)
   bsTxPowerLin(:, msIndSaattohoito) = 0;
   bsTxPower(:, msIndSaattohoito) = 0;
   targetCI(msIndSaattohoito) = 0;
   outageDL(:, msIndSaattohoito) = 0;
   outageCPICH(:, msIndSaattohoito) = 0;
end
