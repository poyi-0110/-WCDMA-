%ANTPATTERN   LOSS = ANTPATTERN(BASESETATION, XX, YY, ANTENNA)
%
%Inputs:
%   BASESTATION: the base station structure
%   XX,YY      : locations of the network pixels
%   ANTENNA    : matrix with horizontal and vertical pattern
%                antenna(:,1) = hor. angles - antenna(:,2) hor. attenuations
%                antenna(:,1) = ver. angles - antenna(:,2) ver. attenuations
%Outputs:
%   LOSS       : the loss from BASESTATION to each location compared to main lobe
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function loss = AntPattern(basestation, xx, yy, antenna)

mobilestation.groundHeight = 0;
mobilestation.antennaHeight = 1.5;

%calculate absolute azimuth as ETN value
deltaLoc = (xx-basestation.x)+j*(yy-basestation.y);
azimuth  = 90-angle(deltaLoc)/pi*180;
azimuth  = azimuth+360*(azimuth<0);
azimuth  = azimuth-basestation.antennaDir;
azimuth  = azimuth+360*(azimuth<0);

%calculate elevation
distance  = abs(deltaLoc);
deltaH    =   basestation.groundHeight +   basestation.antennaHeight - ...
           (mobilestation.groundHeight + mobilestation.antennaHeight);

tiltType = 1;
switch tiltType
case 1 %mechanical tilt, a non-linear model
   %deltaTilt = acos(1-(cos(pi/180*azimuth).^2)*(1-cos(pi/180*basestation.antennaTilt)))*180/pi;
   %ind1 = find(azimuth>90 & azimuth < 270);
   %deltaTilt(ind1) = -deltaTilt(ind1);
   deltaTilt = atan(tan(basestation.antennaTilt/180*pi)*cos(azimuth/180*pi))/pi*180;
case 2 %mechanical tilt, a simple linear model
   deltaTilt = (abs(azimuth-180)/90-1)*basestation.antennaTilt;
otherwise %electrical tilt - used up to now
   deltaTilt = basestation.antennaTilt;
end
elevation = angle(distance+j*deltaH)*180/pi-deltaTilt;
elevation = elevation+360*(elevation<0);

%interpolate antenna pattern,
%NOTE!!!  interp1(...,'*linear') is faster than interp1q(...) but requires 
%         eqaully spaced x-Values (antenna directions)
horLoss = interp1(antenna(:,1), antenna(:,2), azimuth(:), '*linear');
horLoss = reshape(horLoss, size(azimuth, 1), size(azimuth, 2));
verLoss = interp1(antenna(:,3), antenna(:,4), elevation(:), '*linear');
verLoss = reshape(verLoss, size(elevation, 1), size(elevation, 2));

%calculate loss
loss = horLoss+verLoss;
return
