%CALCTHROUGHPUT   calculates cell throughput, deals it to perf.ThroughputUL and DL                   
%                                      
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
hhhhhhhh%
%needed m-files: Calcm_RDL.m

Calcm_RDL
for k = 1:numBSs
   thputUL(k) = perf(k).mUL*perf(k).RUL;
   thputDL(k) = perf(k).mDL*perf(k).RDL;   
end

thputUL = num2cell(thputUL);
thputDL = num2cell(thputDL);

[perf.throughputDL] = deal(thputDL{:});
[perf.throughputUL] = deal(thputUL{:});

clear thputUL thputDL;
