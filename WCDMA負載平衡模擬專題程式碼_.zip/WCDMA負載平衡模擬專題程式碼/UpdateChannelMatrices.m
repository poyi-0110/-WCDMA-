%UPDATECHANNELMATRICES   UPDATECHANNELMATRICES creates vectors and matrices holding a channel index
%                        which can be used to refer to a linkPerfTables in the array linkPerf of all
%                        linkPerfTables. Also the mobilestation and basestation specific link performance
%                        parameters are calculated here. Channel is originally a BS parameter and
%                        based on minimum linkloss from different base stations a channel is chosen for
%                        mobilestations and pixels.
%
%Inputs:
%   basestation  : array of base station structures. The field .channel is used as input.
%   mobilestation: array of MS structures. The fields .speed and .R (bitrate) are used as input.           
%   linklossDLM  : linklosses from all BS:s to all MS:s
%   yPixels      : number of pixels in the map, in y direction
%   xPixels      : number of pixels in the map, in x direction
%
%Outputs:
%   channels     : vector of channel indeces found in the scenario
%   numChannels  : number of channels found in the scenario
%   channelMap   : yPixels x xPixels matrix of channel indeces to each pixel. This 
%                  is determined by the BS with minimum linkloss to the pixel.
%   
%   basestation.wideAreaCovEbNoDL : DL Eb/No for the reference service, 
%                                   calculated based on basestation.channel
%   mobilestation.channel         : Channel specific MS parameters
%   mobilestation.EbNoUL
%   mobilestation.EbNoDL
%   mobilestation.txPowRaise
%   mobilestation.headRoom
%   mobilestation.vUL
%   mobilestation.vDL
%   mobilestation.orthFactor
%   deltaSensitivity
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcMsEbNoDL.m,    CalcMsEbNoUL.m,        CalcMsTxPowRaise.m, 
%                CalcMsHeadRoom.m,  CalcVoiceActivityUL.m, CalcVoiceActivityDL.m, CalcOrthogonality.m

channels    = unique([basestation.channel]);
numChannels = length(channels);
tmpBsChan   = [basestation.channel];

%Operator/Carrier runType
for runType = 1:2
   eval(['indBStypeX = indBStype' num2str(runType) ';']);
   tmpIndCarr = msIndGeneric(find([mobilestation(msIndGeneric).usedCarr]==runType));
   
   if ~isempty(indBStypeX) & ~isempty(tmpIndCarr)
      [tmpMindist, tmpIMindist] = min(linklossDLM(indBStypeX, tmpIndCarr), [], 1);
      tmpMsChannels = num2cell(tmpBsChan(indBStypeX(tmpIMindist(:))));
      [mobilestation(tmpIndCarr).channel] = deal(tmpMsChannels{:});
   end
end

for i1 = 1:numChannels
   ind2 = find([mobilestation(msIndGeneric).channel]==channels(i1));
   if (length(ind2) >= 1)
      ind1 = msIndGeneric(ind2);
      tmpEbNoDL = num2cell(CalcMsEbNoDL(linkPerf(channels(i1)), [mobilestation(ind1).speed], [mobilestation(ind1).RDL]));
      [mobilestation(ind1).EbNoDL] = deal(tmpEbNoDL{:});
      tmpEbNoUL = num2cell(CalcMsEbNoUL(linkPerf(channels(i1)), [mobilestation(ind1).speed], [mobilestation(ind1).RUL]));
      [mobilestation(ind1).EbNoUL] = deal(tmpEbNoUL{:});
      tmpTxPowRaise = num2cell(CalcMsTxPowRaise(linkPerf(channels(i1)), [mobilestation(ind1).speed]));
      [mobilestation(ind1).txPowRaise] = deal(tmpTxPowRaise{:});
      tmpHeadRoom = num2cell(CalcMsHeadRoom(linkPerf(channels(i1)), [mobilestation(ind1).speed]));
      [mobilestation(ind1).headRoom] = deal(tmpHeadRoom{:});
      tmpVUL = num2cell(CalcVoiceActivityUL(linkPerf(channels(i1)), [mobilestation(ind1).RUL]));
      [mobilestation(ind1).vUL] = deal(tmpVUL{:});
      tmpVDL = num2cell(CalcVoiceActivityDL(linkPerf(channels(i1)), [mobilestation(ind1).RDL]));
      [mobilestation(ind1).vDL] = deal(tmpVDL{:});
      tmpAlpha = num2cell(CalcOrthogonality(linkPerf(channels(i1)), [mobilestation(ind1).speed]));
      [mobilestation(ind1).orthFactor] = deal(tmpAlpha{:});
   end
end

tmpvul = [mobilestation(msIndGeneric).vUL];
deltaSensitivity(msIndGeneric) = lin2log(...
   vUL*(1+W/(vUL*log2lin(wideAreaCovEbNo)*wideAreaCovR))./ ...
   (tmpvul.*(1+W./(tmpvul.*log2lin([mobilestation(msIndGeneric).EbNoUL]).*[mobilestation(msIndGeneric).RUL]))));

for i1 = 1:numBSs
   basestation(i1).wideAreaCovEbNoDL = CalcMsEbNoDL(linkPerf(basestation(i1).channel), wideAreaCovSpeed, wideAreaCovR);
end

clear tmp* ind1 ind2 i1 runType indBStypeX;
