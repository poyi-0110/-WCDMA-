%CALCULPOWERMAP  CALCULPOWERMAP Calculates received power from each pixel to every
%                basestation. This is done for the iterated mobiles not in outage and
%                not in other carriers but 1.
%
%
%Inputs:
%   mobilestation: array of structures
%   linklossUL   : (numBSs, yPixels, xPixels) matrix
%Outputs:
%   bsRxPower    : (numBSs, yPixels, xPixels) matrix
%
%Author : Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: lin2log.m, log2lin.m

tmpMsTxPower = -999*ones(yPixels, xPixels);
tmpMsTxPowerLin = zeros(size(tmpMsTxPower));

% A map of transmitted powers in linear scale is generated
for i1 = 1:numMSs
   if (mobilestation(i1).txPower ~= -999)
      tmpMsTxPowerLin(yPos(i1), xPos(i1)) = tmpMsTxPowerLin(yPos(i1), xPos(i1))+ ...
                                            log2lin(mobilestation(i1).txPower);
   end
end

bits1 = (tmpMsTxPowerLin(:) ~= 0)';
tmpMsTxPower(bits1) = lin2log(tmpMsTxPowerLin(bits1));
tmpMsTxPower(~bits1) = -999;

% Received power map is calculated for each base station
% Reshape is just to get a matrix of dimension 1xlength(tmpMsTxPower(bits1))
for i1 = 1:numBSs
   bsRxPower(i1, bits1) = reshape(tmpMsTxPower(bits1), 1, length(tmpMsTxPower(bits1)))-linklossUL(i1, bits1);
   bsRxPower(i1, ~bits1) = -999;
end

clear bits1 tmpMsTxPower tmpMsTxPowerLin i1
