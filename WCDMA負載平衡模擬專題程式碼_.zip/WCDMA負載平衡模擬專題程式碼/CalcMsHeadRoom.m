%CalcMsHeadRoom   txHeadRoom = CalcMsHeadRoom(lpTables, speeds) returns the single link
%                 headroom above average single link received Eb/No required for a MS
%                 with PC to live in fading.
%
%Inputs:
%   lPTables  : linkPerfTables for a channel, see e.g. pedALinkPerfTables.m	
%   speeds:     The speeds at which the headrooms are calculated.	
%Outputs:
%   txHeadRoom: The headroom required in the single link link budget for PC in dB  
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function txHeadRoom = CalcMsHeadRoom(lPTables, speeds);

tabspeed    = lPTables.speeds;
tabheadroom = lPTables.HRUL;

txHeadRoom = zeros(size(speeds));
m1 = length(lPTables.speeds);

% If the input speeds are outside the tabled speeds special action is taken.
bits1 = speeds < tabspeed(1);
bits2 = speeds > tabspeed(m1);
bits3 = ~(bits1 | bits2);

if (sum(bits1) > 0)
	txHeadRoom(bits1) = tabheadroom(1);
end

if (sum(bits2) > 0)
	txHeadRoom(bits2) = tabheadroom(m1);
end

if (sum(bits3) > 0)
   txHeadRoom(bits3) = interp1(tabspeed, tabheadroom, speeds(bits3));
end
