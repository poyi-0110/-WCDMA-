%MOB_INSIDE   IN = MOB_INSIDE(POLYGON, ROUTE) checks which part of ROUTE is within POLYGON
%
%Inputs:
%   POLYGON: a polygon
%   ROUTE  : a route
%Outputs:
%   IN     : indices of ROUTE(:) which are inside POLYGON
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function in = mob_inside(polygon, route)

[nm0, mm0] = size(route);
in = zeros(1, nm0);
pminx = min(polygon(:, 1));
pminy = min(polygon(:, 2));
pmaxx = max(polygon(:, 1));
pmaxy = max(polygon(:, 2));
routeind = find((route(:, 1)>pminx & route(:, 1)<pmaxx & ...
                 route(:, 2)<pmaxy & route(:, 2)>pminy)');
if ~isempty(routeind);
   route = route(routeind, :);
   %Gives "1" to route indices inside the polygon (and "0" to indices outside)
   [nm, mm] = size(route);
   [n, m] = size(polygon);
   walls = [polygon(1:n, 1:2) [polygon(2:n, 1:2);polygon(1, 1:2)]];
   chang = walls(:, 4)~=walls(:, 2);
   walls = walls(chang, :);
   n = length(find(chang));
   wx1 = walls(:, 1)*ones(1, nm);
   wy1 = walls(:, 2)*ones(1, nm);
   wy2 = walls(:, 4)*ones(1, nm);
   routey = ones(n, 1)*route(:, 2)';
   ero1 = routey-wy1;
   ero2 = routey-wy2;
   ind = ero1.*ero2<0;
   l = (wx1-ones(n, 1)*route(:, 1)')+ero1./(wy2-wy1).*(walls(:, 3)*ones(1, nm)-wx1);
   s = sum(l>0 & ind)/2;
   in = zeros(1, nm0);
   in(routeind) = (s-floor(s))~=0;
else
   in = zeros(1, nm0);
end
