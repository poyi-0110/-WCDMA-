%CREATELINKPERF   CREATELINKPERF creates a vector of link performance tables and 
%                 a link performance table for wideAreaCov calculations. It uses as input
%                 the link performance table files indicated in the struct array 
%                 "channelFiles", which is given in npswini.m.
%Inputs:
%   channelFiles       : array of structures holding the names of link performance table files in
%                        its fields .name
%Outputs:
%   wideAreaCovLinkPerf: linkPerfTables for the wide area coverage
%   linkPerf           : array of all linkPerfTables whose file names were given in channelFiles.name 
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

clear linkPerf;

%reference link performance table. Number one is chosen.
eval(channelFiles(1).name);
wideAreaCovLinkPerf = linkPerfTables;

%all link performance tables
for i1 = 1:length(channelFiles)
   eval(channelFiles(i1).name);
   linkPerf(i1) = linkPerfTables;
end

clear linkPerfTables;
