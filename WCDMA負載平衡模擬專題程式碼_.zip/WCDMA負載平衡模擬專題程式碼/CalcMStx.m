%CALCMSTX   CALCMSTX checks for outage and copies the MS transmit power to the MS structure
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcShoGain.m, DoIFHO.m, DoSaattohoito.m

%Average transmitted power seen by the own cell without SHO gain
txPowerBaseV = msTxPowerV+deltaSensitivity;

for i1 = 1:numChannels
   ind1 = find([mobilestation.channel]==channels(i1));
   if (length(ind1) >= 1)
      %Average transmitted power seen by the own cell with SHO gain
	   txPowerRxV(ind1) = txPowerBaseV(ind1) - ...
		                   CalcShoGain([mobilestation(ind1).speed], deltaSHOV(ind1), linkPerf(channels(i1)), 1);            
            
		%Average transmitted power seen by the other cells including SHO gain
		txPowerTxV(ind1) = txPowerBaseV(ind1)+[mobilestation(ind1).txPowRaise] - ...
	                      CalcShoGain([mobilestation(ind1).speed], deltaSHOV(ind1), linkPerf(channels(i1)), 2);

		%Required peak power including SHO gain, used in outage checking.
		txPowerPeakV(ind1) = txPowerBaseV(ind1)+[mobilestation(ind1).headRoom] - ...
                           CalcShoGain([mobilestation(ind1).speed], deltaSHOV(ind1), linkPerf(channels(i1)), 3);
   end
end

%msTxPowerV will be recalculated
%This will be used in calculating IownUL           
msTxPowerV = -999*ones(size(msTxPowerV));
%msTxPowerRaisedV will contain the tx powers with av. power raise added.
%This will be used in calculating IothUL
msTxPowerRaisedV = -999*ones(size(msTxPowerV));
           
usedCarrV   = [mobilestation.usedCarr];           
txMaxPowerV = [mobilestation.txMaxPower];
txMinPowerV = [mobilestation.txMinPower];

%MSs not in outage nor removed because of high loading
ind2 = find(usedCarrV>=1 & txPowerPeakV<=txMaxPowerV); 
msTxPowerV(ind2)       = txPowerRxV(ind2);
msTxPowerRaisedV(ind2) = txPowerTxV(ind2);

%MSs not in outage nor removed because of high loading, 
%but tx power below the minimum
ind2a = find(usedCarrV>=1 & txPowerPeakV<=txMaxPowerV & ...
             msTxPowerV < txMinPowerV);
msTxPowerV(ind2a) = txMinPowerV(ind2a);

%same as the previous one but for msTxPowerRaisedV
ind2b = find(usedCarrV>=1 & txPowerPeakV<=txMaxPowerV & ...
             msTxPowerRaisedV < txMinPowerV);
msTxPowerRaisedV(ind2b) = txMinPowerV(ind2b);

%outage counter added if the required peek transmit power exceeds the maximum transmit power
ind3 = find(usedCarrV>=1 & txPowerPeakV>txMaxPowerV);
outageUL(ind3) = outageUL(ind3)+1;

%if the previous has happened >= limitOutageUL times ms will be put to outage (2op case) or put to other carrier (2carr case)
msIndSaattohoito = [];
if mode == 1 %2 carrier case
   %if IF-HO counter expired -> MS to outage
   ind7 = find(usedCarrV>=1 & txPowerPeakV>txMaxPowerV & ifhoCounter>=limitIFHO);
   usedCarrV(ind7) = -2;
   
   msIndSaattohoito = [msIndSaattohoito ind7];
  
   %change from carrier 1 to carrier 2
   ind5 = find(usedCarrV==1 & txPowerPeakV>txMaxPowerV & outageUL>=limitOutageUL & ifhoCounter<limitIFHO);
   
   %change from carrier 2 to carrier 1
   ind6 = find(usedCarrV==2 & txPowerPeakV>txMaxPowerV & outageUL>=limitOutageUL & ifhoCounter<limitIFHO);
   
   usedCarrV(ind5) = 2;
   usedCarrV(ind6) = 1;
      
   msIndGeneric = [ind5 ind6];
elseif mode == 2 %2 operator case
   ind4 = find(usedCarrV>=1 & txPowerPeakV>txMaxPowerV & outageUL>=limitOutageUL);
   usedCarrV(ind4) = -2; %-2 means outage reason: MS running out of power
   msIndSaattohoito = [msIndSaattohoito ind4];
end

%mobilestation-structure up-dated
tmpUsedCarr = num2cell(usedCarrV);
[mobilestation.usedCarr] = deal(tmpUsedCarr{:});
tmpMsTxPower = num2cell(msTxPowerV);
[mobilestation.txPower] = deal(tmpMsTxPower{:});

if ~isempty(msIndSaattohoito)
   DoSaattohoito;
end

if mode == 1
   if length(msIndGeneric) >= 1
      DoIFHO;
   end
end

indMStype1 = find([mobilestation.usedCarr] == 1);
indMStype2 = find([mobilestation.usedCarr] == 2);
numMStype1 = length(indMStype1);
numMStype2 = length(indMStype2);

clear tmpMsTxPower tmpUsedCarr txPowerBaseV txPowerRxV txPowerTxV txPowerPeakV;
clear ind2 ind2a ind2b ind3 ind4 ind5 ind6 ind7 txMaxPowerV txMinPowerV msIndSaattohoito msIndGeneric
