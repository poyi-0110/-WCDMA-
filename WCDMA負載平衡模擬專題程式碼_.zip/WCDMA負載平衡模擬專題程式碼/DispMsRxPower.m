%DispMsRxPower   DispMsRxPower displays a histogram of the RX power of the MSs
%
%Inputs:
%   bsTxPowerTotLin   : the total transmit power of the basestations calc. in CalcIntDL.m
%   MS_noise_power_lin: the noise power in the MS
%   linklossDLM       : linklosses between base stations and mobile stations
%   acFilterDL        : the combined BS leakage and MS selectivity
%Outputs:   
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

dlFilterM = zeros(numBSs, numMSs);
dlFilterM(indBStype2, indMStype1) = acFilterDL(channelOffset);
dlFilterM(indBStype1, indMStype2) = acFilterDL(channelOffset);
msRxAll = bsTxPowerTotLin'*log2lin(-linklossDLM-dlFilterM)+MS_noise_power_lin;

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   eval(['hFig = findobj(''Tag'', ''MSRXPOWER' num2str(layer) ''');']);
   if isempty(hFig)
      hFig = figure;
      eval(['set(hFig, ''Tag'', ''MSRXPOWER' num2str(layer) ''');']);
   else
      figure(hFig)
   end
   if layer == 1
      tmpMsRxAll = msRxAll(indMStype1);
   else
      tmpMsRxAll = msRxAll(indMStype2);
   end
   
   [a b] = hist(lin2log(tmpMsRxAll));
   a = 100*a/sum(a);
   bar(b, a)
   xlabel(['mean: ' num2str(lin2log(mean(tmpMsRxAll))) ' dBm   -   max: ' num2str(lin2log(max(tmpMsRxAll))) ' dBm']);
   ylabel('percentage');
   titleText = 'total received wide band power of MSs in dBm ';
   if numBStype2 & numBStype1
      if mode == 2
         titleText = [titleText 'for operator ' num2str(layer)];
      elseif mode == 1
         titleText = [titleText 'for carrier ' num2str(layer)]; 
      end
   end
   title(['\it{', titleText, '}']);
end
clear a b tmpMsRxAll hFig layer msRxAll titleText dlFilterM
