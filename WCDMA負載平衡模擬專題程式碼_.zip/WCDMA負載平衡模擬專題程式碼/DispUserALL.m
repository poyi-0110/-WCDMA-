%DISPUSERALL   DISPUSERALL creates and displays the 'userALL' map, i.e. all users, 
%              whether they are in outage, carrier1 or any other carrier.
%
%Inputs:  (global) mobilestation, basestation, numBSs, umMSs, xPos, yPos,
%         xmin, xmax, ymin, ymax, resolution
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Jaana Laiho-Steffen (jls), 
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   userALL = zeros(yPixels, xPixels);
   eval(['indMStypeX = find([mobilestationOri.usedCarr] == ' num2str(layer) ');']);
   for m = indMStypeX
      userALL(yPos(m), xPos(m)) = userALL(yPos(m), xPos(m))+1;
   end

   totalUsers = sum(sum(userALL));
   userALL(~isnan(waterArea)) = NaN;
   
   figure
   set(gcf, 'Tag', 'tagUserFig');
   userColors = [1 1 1; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.5 0.5 0.5];
   pcolor(xmin:resolution:xmax, ...
      ymin:resolution:ymax, ...
      userALL);
   caxis([0 8]);
   colormap(userColors);
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   titleText = ['USER DISTRIBUTION' layerString ' (all) (total = ' num2str(totalUsers), ' users)'];
   title(['\it{', titleText, '}']);
   axis('equal');
   shading('flat');
   hcb = colorbar('vert');
   set(get(hcb, 'Title'), 'String', '# of users');
   tlabel = get(hcb, 'yticklabel');
   set(hcb, 'yticklabel', tlabel);
   set(hcb, 'Ytick', get(hcb, 'Ytick')+0.5);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
   clear userAll userColors tlabel hcb m totalUsers 
end
