%DISPLINKLOSS   DISPLINKLOSS displays the UL or DL link losses
%
%Inputs:
%   llType       : set in DispPPmenu when seleting UL (llType = 1) or DL losses (llType = 2)
%   linklossUL/DL: the linkloss matrices
%Outputs:
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m, BSselect.m

h0 = BSselect(3);
uiwait(h0);

if llType == 1
   llString = 'UL';
else
   llString = 'DL';
end

scale = [90 90+1*64];

for wantedBS = wantedBSs
   figure
   eval(['linkloss1 = squeeze(linkloss' llString '(wantedBS, :, :));']);
   linkloss1(~isnan(waterArea)) = NaN;
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          linkloss1);
   caxis(scale);
   colormap(flipud(jet(64)))
   hcb = colorbar;
   axis('equal');
   str1 = num2str(wantedBS);
   ks = num2str(wantedBS);
   
   if (numBStype2 > 0) & (numBStype1 > 0)
      if mode == 1
         layerString = ['CA'];
      elseif mode == 2
         layerString = ['OP'];
      end
      if ismember(wantedBS, indBStype1)
         layer = 1;
      else
         layer = 2;
      end
   else
      layer = 1;
   end   
   
   header = [llString ' link losses of ' char(basestation(wantedBS).nameLong)];
   if (wantedBS >= 10)
      header = [header '_' ks(2)];
   end
   title(['\it{}' header]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', [llString ' link loss']);
   set(hcb, 'yticklabel', strcat(num2str(str2num(get(hcb, 'yticklabel'))), ' dB'));
   BSplot(basestation, gcf, vectMap, lossData);
   drawnow
end


if exist('compLossFlag') & compLossFlag
   tmpLayer = [];
   if numBStype1
      tmpLayer = [tmpLayer 1];
   end
   if numBStype2
      tmpLayer = [tmpLayer 2];
   end
   
   for layer = tmpLayer
      eval(['hFig = findobj(''Tag'', ''tagCompLoss' num2str(layer) ''');']);
      if isempty(hFig)
         hFig = figure;
         eval(['set(hFig, ''Tag'', ''tagCompLoss' num2str(layer) ''');']);
      else
         figure(hFig)
      end
      eval(['linkloss1 = squeeze(min(linkloss' llString '(indBStype' num2str(layer) ', :, :), [], 1));']);
      linkloss1(~isnan(waterArea)) = NaN;
      pcolor(xmin:resolution:xmax, ...
             ymin:resolution:ymax, ...
             linkloss1);
      
      colormap(flipud(jet(64)))
      caxis(scale);
      hcb = colorbar;
      axis('equal');
      titleText = ['composite ' llString ' link losses '];
      if (numBStype1 > 0 & numBStype2 > 0)
         if mode == 2
            titleText = [titleText 'for operator ' num2str(layer)];
         elseif mode == 1
            titleText = [titleText 'for carrier ' num2str(layer)]; 
         end
      end
      title(['\it{', titleText, '}']);
      
      shading('flat')
      set(get(hcb, 'Title'), 'String', [llString ' link loss']);
      set(hcb, 'yticklabel', strcat(num2str(str2num(get(hcb, 'yticklabel'))), ' dB'));
      BSplot(basestation, gcf, vectMap, lossData);
      drawnow
   end
end
clear wantedBS wantedBSs wantedBSstr k l ks titleText layer hcb layerString llType llString tmp*
