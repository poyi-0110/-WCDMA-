%NPSWINI   this file contais all the frequently changed system and control paramters needed 
%
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa), Kari Sipil?(KSi)
%         Kari Heiska (KHe), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%%%%%%%%%%%%%%%%%%%%%%% general %%%%%%%%%%%%%%%%%%%%%%

%following parameters are fixed but could be as well BS or MS
%specific if different classes of BSs or MSs exist

mobilestationAntennaGain = 1.5;% dBi
mobilestationBodyLoss = 1.5;   % dB

limitCT = 0.2;                 % dB - limit for cov. threshold (uplink break criterion)
limitDeltaCT = 0.1;            % dB - limit for delta cov. th. (uplink break criterion)
limitOutageUL = 1;             % plain - number of iterations after MS is put to outage in UL
limitCI = 0.2;                 % dB - limit for C/I (downlink break criterion)
limitDeltaCI = 0.001;          % dB - limit for delta C/I (downlink break criterion)
limitOutageDL = 2;             % plain - number of iterations after MS is put to outage in DL
limitOutageCPICH = 1;          % plain - number of iterations MS can stay in the carrier with bad CPICH EcIo
limitIFHO = 2;                 % plain - number of allowed IFHO after MS is put to outage

area_correction = [-3];  %�̻ݨD�t�X�ק�% dB - 0 for urban,
%                                    -3 for dense urban,
%                                     8 for suburban....
numMStype1 = 330;%�ݭn�t�XMSparam_2tier.txt���ק�
numMStype2 = 0;
numBStype1 = 21; %�ݭn�t�XBSparam_2tier.txt���ק�
numBStype2 = 0;

%following values are from 3GPP 25.101 and 25.104 as of 10.6.2000
aciFilterUL = [65];    %channel offset 1,                  (BS selectivity), channel 2 not spec.
aciFilterDL = [33];    %channel offset 1,                  (MS selectivity), channel 2 not spec.
acpFilterDL = [45 50]; %channel offset 1, channel offset 2 (BS leakage)
acpFilterUL = [33 43]; %channel offset 1, channel offset 2 (MS leakage)

%following values are from "hat"
acMinPowUL  = -55;  %dBm <- JNu
acMinPowDL  = -55;  %dBm
acMinPowUL  = -999; %dBm
acMinPowDL  = -999; %dBm

%2 tier scenario
msParamFile   = 'MSparam_2tier.txt';%�̻ݨD�t�X�ק�
bsParamFile   = 'BSparam_2tier.txt';%�̻ݨD�t�X�ק�
linklossFile  = '';              % linkloss data file   (.mat-file)
vectFile      = '';              % vector building data (.mat-file)
mapFile       = '';              % name of the clutter map when exported from nps/x
waterAreaFile = '';              % the variable in this .mat-file should be called waterArea,
                                 % the filename can be anything

%%%%%%%%%%%%%%%%%%%%%%%%%%%% propagation related %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pathlossModel  = 1;            % 1: Okumura Hata
                               % 2: UMTS pedestrian (micro)
deltaHb = 15; %(needed with 2) % 3: UMTS vehicular  (macro)
                               % 4: UMTS vehicular with hb = 15m, f = 2000 MHz
                               % 5: OH with hb = 35 m
                               % 6: single slope model; slope = 40 dB/dec.
                               % 7: Linkloss data from nps/x
                               % 8: Linkloss data from nps/x (vector data displayed)
useImportedAntennaInfo = 0;    % 0: don't use antenna type/dir./tilt from NPSX, keep old
                               %    (antenna in NPSX should have been isotropic)
                               % 1: use antenna type/dir./tilt from NPSX
                               
sigmaLogNorm = 7;              % standard deviation for the log normal fading [dB]

sectCorr = 0.8;                % fading correlation between sectors at same cell
siteCorr = 0.5;                % fading correlation between sectors at different cell
                               
%Names of the linkPerfTables definition files are given here without the .m extension
%In BS file the number in column 'channel' refers to these linkPerfTables.
channelFiles(1).name = 'vehALinkPerfTablesNew';
channelFiles(2).name = 'pedALinkPerfTablesNew';
channelFiles(3).name = 'twoTapLinkPerfTables';

%%%%%%%%%%%%%%%%%% coverage probability calculation, test probe definition %%%%%%%
wideAreaCovR       = 8000;     % bits/s
wideAreaCovSpeed   = 50;       % km/h
wideAreaCovMsTxMax = 21;       % dBm

%%%%%%%%%%%%%%%%5%%%%%%%%%%%%%%%%%% common channel related %%%%%%%%%%%%%%%%%%%%%%%
maxCPICHPower = 30;            % dBm
CPICHPowerSwitch = 3;          % 1 for fixed power CPICH
                               % 2 for changing power according to UL load
                               % 3 CPICH powers read from BS-file (for mixed cells)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LC related %%%%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
loadControlSwitch = 3;         % 1 for random choose of the MS:s to be thrown out
                               % 2 for MS with highest TX power at highly loaded cells
                               %   to be thrown out
                               % 3 for random chose of MSs at highly loaded cells
reducePowerSwitch = 2;         % 1 not used anymore
                               % 2 take randomly   MSs out until BS TX power is small enough
                               % 3 take high power MSs out until BS TX power is small enough
                               % 4 take low  power MSs out until BS TX power is small enough

%%%%%%%%%%%%%%%%%%%%%%%%%% Common channel analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CPICHEcIoThreshold = -18;      % default dB threshold for Ec/Io(wideband Io) for being able
                               % to measure CPICH channel
bchEbNo = 5;                   % Average Eb/No for the BCH channel
bchCpichOffset = 5;            % difference in power between BCH and CPICH in dB
bchBitRate = 12200;            % bits/s

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Downlink power allocation %%%%%%%%%%%%%%%%%%%%%%%%%
limitDLPowerSwitch = 0;        % 0: no limit for link powers in DL
pTxDLAbsMin = -999;            % Maximum power per link in DL (dBm) 'soft' limit - not in SFS -> -999

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% hard blocking %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hardBlocking = 0;              % 0: no hard blocking used, 1: hard blocking used
basestationChannels = 172;     % number of CHE in the base station pool

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulation mode %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mode = 1;                      % 1: 2 Carriers
                               % 2: 2 Operators
doInitialCarrierSelection = 0; % If mode == 1 and doInitialCarrierSelection == 1 it is checked before the
                               % iteration whether the MS can hear the CPICH channel on the carrier indicated
                               % in the MS file. If not, a carrier re-selection is made if the second carrier
                               % can be heard.
                               % If mode == 1 and doInitialCarrierSelection == 2 MSs reselect the carrier 
                               % with highest CPICH Ec/Io
                               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MS order method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%for random MS selection from the MS file
randomizeMSfile = 0;
usePrevRandStateInMsRead = 0;
msReadDefRandState = 111;