%CALCM_RUL   CALCM_RUL calculates perf.mUL and perf.RUL
%                                      
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none                      

tmpPerm = eye(numBSs);
tmpPerm = tmpPerm(:, bestServerV);

tmpOnes = ones(size(usedCarrV));
tmpOnes(usedCarrV < 1 | msTxPowerV == -999) = 0;

tmpPerfM = (tmpPerm*tmpOnes')';

tmpMsR = [mobilestation.RUL];
tmpTotalBits = (tmpPerm*(tmpMsR.*tmpOnes)')';
tmpPerfR = zeros(size(tmpPerfM));
ind1 = find(tmpPerfM>0);
tmpPerfR(ind1) = tmpTotalBits(ind1)./tmpPerfM(ind1);

tmpPerfM = num2cell(tmpPerfM);
tmpPerfR = num2cell(tmpPerfR);

[perf.mUL] = deal(tmpPerfM{:});
[perf.RUL] = deal(tmpPerfR{:});

%clean up
clear tmpPerm tmpOnes tmpPerfM tmpPerfR ind1 tmpTotalBits tmpMsR
