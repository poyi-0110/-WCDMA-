%VEHALINKPERFTABLESNEW   VEHALINKPERFTABLESNEW consists of the Eb/No, SHO gain etc. tables,
%                        as a function of used MS speed. The tables have been written based
%                        on link level simulation results. When this script is run, a structure
%                        linkPerfTables will be formed which has all the information from the
%                        tables.
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

%Channel: Vehicular A

linkPerfTables.bitRates = ...
   [8000 12200 64000 144000 512000];

%Specified speeds. Other speeds will be interpolated.
linkPerfTables.speeds = ...
   [3 50 120];

linkPerfTables.vUL = ...
   [0.67 0.67 1.0 1.0 1.0];

linkPerfTables.vDL = ...
   [0.67 0.67 1.0 1.0 1.0];

linkPerfTables.orthogonality = ...
   [0.5 0.5 0.5];

%Rows: specified bit rates
%Columns: specified speeds
%Dimensions must match to dimensions of linkPerfTables.bitRates 
%and linkPerfTables.speeds.

linkPerfTables.EbNoUL = ...
   [6.5 6.8 7.0;
    5.5 5.8 6.0;
    4.0 4.3 4.5;
    3.5 3.8 4.0;
    3.0 3.3 3.5];
  
linkPerfTables.EbNoDL = ...
   [9.0 9.4 9.4;
    8.5 8.0 7.8; 
    7.1 6.6 6.4;  
    6.1 5.6 5.4;
    5.6 5.1 4.9]; 
 
linkPerfTables.AvPRUL = ...
   [0.7 0.3 0.0];

linkPerfTables.AvPRDL = ...
   [0.7 0.7 0.6];

linkPerfTables.HRUL = ...
   [1.8 0.5 0.0]; 

linkPerfTables.shoDifferences = ...
   [0 3 6 10]';

linkPerfTables.RxPowSHOgainUL = ...
   [1.1 0.8 1.1;
    0.3 0.1 0.1;
    0.1 0.1 0.1;
    0.0 0.0 0.0];

linkPerfTables.TxPowSHOgainUL = ...
   [1.3 1.2 1.1;
    0.4 0.3 0.1;
    0.1 0.0 0.1;
    0.0 0.0 0.0];
      
linkPerfTables.HRSHOgainUL = ...
   [2.0 1.4 1.1;
    0.8 0.3 0.1;
    0.1 0.1 0.1;
    0.0 0.0 0.0];

linkPerfTables.TxPowSHOgainDL = ...
   [1.4 0.9 1.0;
    1.0 0.8 0.9;
    0.9 0.7 0.6;
    0.4 0.3 0.1];
