%DISPCARR   DISPCARR creates the used carrier map and plots it
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

carrierColors = [1 1 1; 0.7 0.7 0.7; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1];
maxCarrs = 3;

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   carriers = zeros(yPixels, xPixels);
   for k = 1:yPixels
      for l = 1:xPixels
         if squeeze(bestServer(layer, k, l))
            carriers(k, l) = 1+addCarrNeeded(squeeze(bestServer(layer, k, l)));
         end
      end
   end
   carriers(find(carriers>maxCarrs)) = maxCarrs;
   carriers(~isnan(waterArea)) = NaN;
   
   figure
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          carriers)
   caxis([0 maxCarrs+1]);
   colormap(carrierColors(1:maxCarrs+1, :));
   hcb = colorbar('vert');
   axis('equal');
   if numBStype2 == 0 | numBStype1 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   title(['\it{}' ['Used carriers' layerString]]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'Used carriers');
   set(hcb, 'Ytick', [0:maxCarrs]+0.5);
   set(hcb, 'yticklabel', str2mat(['no coverage'], num2str([1:maxCarrs]')));
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
end

clear carrierColors carriers k l layer maxCarrs hcb
