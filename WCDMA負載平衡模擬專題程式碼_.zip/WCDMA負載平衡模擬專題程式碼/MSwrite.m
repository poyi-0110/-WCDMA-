%MSWRITE   MSWRITE(MOBILESTATION, FILENAME) writes mobile stations to parameter file
%
%Inputs:
%   MOBILESTATION: array of base station structures to be saved
%   FILENAME     : name of the output file (optional, default=MSparam.txt)
%Outputs:
%   none
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function MSwrite(mobilestation, msFilename)

if (nargin == 1)
   msFilename = 'MSparam.txt';
end

msFID = fopen(msFilename, 'w');

numMSs = length(mobilestation);
for k = 1:numMSs
   fprintf(msFID, '%f ', mobilestation(k).x);
   fprintf(msFID, '%f ', mobilestation(k).y);
   fprintf(msFID, '%d ', mobilestation(k).groundHeight);
   fprintf(msFID, '%d ', mobilestation(k).antennaHeight);
   fprintf(msFID, '%f ', mobilestation(k).txMaxPower);
   fprintf(msFID, '%f ', mobilestation(k).txMinPower);
   fprintf(msFID, '%f ', mobilestation(k).antennaGain);
   fprintf(msFID, '%f ', mobilestation(k).bodyLoss);
   fprintf(msFID, '%f ', mobilestation(k).RUL);
   fprintf(msFID, '%f ', mobilestation(k).RDL);
   fprintf(msFID, '%d ', mobilestation(k).usedCarr);
   fprintf(msFID, '%f' , mobilestation(k).speed);
   fprintf(msFID, '\n');
end
fclose(msFID);
