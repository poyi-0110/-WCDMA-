%DISP_I   DISP_I creates the 'little_i' map and plots it
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m, Scaling.m

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   little_i = zeros(yPixels, xPixels);
   for k = 1:yPixels
      for l = 1:xPixels
         if (bestServer(layer, k, l))
            little_i(k, l) = perf(bestServer(layer, k, l)).i;
         end
      end
   end
   
   if layer == 1
      if (~exist('little_iFig1'))
         little_iFig1 = 1;
         hFig = figure;
         set(hFig, ...
            'DeleteFcn', 'clear little_iFig1', ...
            'Tag', 'little_iFig1');
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', 0.2, 'maxValue', 1, 'stepSize', 0.02, ...
            'curColMap', 'jet', 'curFig', hFig, 'curFun', 'Disp_i');
      else
         figure(findobj('Tag', 'little_iFig1'));
         ud = get(gca, 'userdata');
      end
   else
      if (~exist('little_iFig2'))
         little_iFig2 = 1;
         hFig = figure;
         set(hFig, ...
            'DeleteFcn', 'clear little_iFig2', ...
            'Tag', 'little_iFig2');
         hMenu = uimenu(...
            'Parent', hFig, ...
            'Label', '&Scaling', ...
            'Tag', 'tagScaling', ...
            'Callback', 'Scaling');
         ud = struct(...
            'minValue', 0.2, 'maxValue', 1, 'stepSize', 0.02, ...
            'curColMap', 'jet', 'curFig', hFig, 'curFun', 'Disp_i');
      else
         figure(findobj('Tag', 'little_iFig2'));
         ud = get(gca, 'userdata');
      end
   end
   
   little_i((little_i<ud.minValue) & (little_i>0)) = ud.minValue+eps;
   little_i(little_i == 0) = -1;
   little_i(~isnan(waterArea)) = NaN;
   
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          little_i)
   set(gca, 'userdata', ud); %don't delete - pcolor clears the userdata
   caxis([ud.minValue-ud.stepSize ud.maxValue]);
   eval(['colors1 = ' ud.curColMap ,'(round((ud.maxValue-ud.minValue)/ud.stepSize));']);
   colormap([[1 1 1]; colors1]);
   hcb = colorbar;
   axis('equal');
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   title(['\it{}' ['Other to own cell interference ratio' layerString]]);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'i');
   set(hcb, 'yticklabel', strcat(num2str(100*str2num(get(hcb, 'yticklabel'))), ' %'));
   BSplot(basestation, gcf, vectMap, lossData);
   clear little_i colors1 hcb k l
end
clear layer; %this is important, don't delete
