%DISPBSTXPOWER   DISPBSTXPOWER displays histograms of the power of all TCH's for selected BSs, 
%                a histogram of all TCHs at all BSs and a histogram of the total TCH power
%                of each BS
%Inputs:
%Outputs:   
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

for k = wantedBSs
   powersInd = find(bsTxPowerLin(k, :));
   
   if (~isempty(powersInd))
      figure
      hist(bsTxPower(k, powersInd), ...
         [floor(min(bsTxPower(k, powersInd))) : 0.5 : ceil(max(bsTxPower(k, :)))]);
      aveTxPower = mean(bsTxPower(k, powersInd));
      stdTxPower = std(bsTxPower(k, powersInd));
      titleText = ['TCH TX powers for connections at ' char(basestation(k).nameLong) ' [dBm]'];
      
      title(['\it{', titleText, '}']);
      xlabel(['ave = ' num2str(aveTxPower) ' dBm - std = ' num2str(stdTxPower) ...
              ' dBm   Ueta = ' num2str(Ueta(k))]);
   else
      warndlg(['Base station ' basestation(k).nameLong ' has no connections !'], 'BS TX Power Display')
   end     
end

if totTxPowerFlag
   tmpLayer = [];
   if numBStype1
      tmpLayer = [tmpLayer 1];
   end
   if numBStype2
      tmpLayer = [tmpLayer 2];
   end
   
   for layer = tmpLayer
      figure
      eval(['temp = sum(bsTxPowerLin(indBStype' num2str(layer) ', :), 2);'])
      temp = lin2log(temp(find(temp)));
         
      hist(temp, [floor(min(temp)) : 0.5 : ceil(max(temp))]);
      aveTxPower = mean(temp);
      stdTxPower = std(temp);
      
      if numBStype1 == 0 | numBStype2 == 0
         layerString = [];
      else
         if mode == 1
            layerString = [' for carrier ' num2str(layer)];
         elseif mode == 2
            layerString = [' for operator ' num2str(layer)];
         end
      end
      
      title(['\it{}' ['total TCH TX powers for all BS [dBm]' layerString]]);
      xlabel(['ave  ' num2str(aveTxPower) ' dBm - std = ' num2str(stdTxPower) ' dBm  ave Ueta = '...
             num2str(mean(Ueta))]);
   end
end
 
if allLinksFlag
   tmpLayer = [];
   if numBStype1
      tmpLayer = [tmpLayer 1];
   end
   if numBStype2
      tmpLayer = [tmpLayer 2];
   end
   
   for layer = tmpLayer
      figure
      eval(['tmp = bsTxPower((indBStype' num2str(layer) '), :);']);
      temp = tmp(find(tmp));
      hist(temp, [floor(min(temp)) : 0.5 : ceil(max(temp))]);
      aveTxPower = mean(temp);
      stdTxPower = std(temp);
      
      if numBStype1 == 0 | numBStype2 == 0
         layerString = [];
      else
         if mode == 1
            layerString = [' for carrier ' num2str(layer)];
         elseif mode == 2
            layerString = [' for operator ' num2str(layer)];
         end
      end
      
      title(['\it{}' ['TCH TX powers for all connections [dBm]' layerString]]);
      xlabel(['ave = ' num2str(aveTxPower) ' dBm - std = ' num2str(stdTxPower) ' dBm   ave Ueta = ' ...
             num2str(mean(Ueta))]);
   end
end
   
clear temp aveTxPower stdTxPower powersInd k wantedBSs allLinksFlag totTxPowerFlag ind1
clear tmp layer layerString
