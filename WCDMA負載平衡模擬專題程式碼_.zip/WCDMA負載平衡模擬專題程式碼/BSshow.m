%BSSHOW   BSSHOW(activeBS, hFig) display the active bast station's parameter
%
%Inputs:
%   activeBS: BS to show
%   hFig    : handle to current figure
%Outputs:
%   none
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function BSshow(activeBS, hFig)

currentBS  = evalin('base', 'currentBS');
insBStype2 = evalin('base', 'indBStype2');

set(findobj(hFig, 'Tag', 'EditTextCurrentBS'), 'String', num2str(currentBS)); 
set(findobj(hFig, 'Tag', 'EditTextOperator'), 'String', num2str(activeBS.usedCarr)); 
set(findobj(hFig, 'Tag', 'EditTextXcoord'), 'String', num2str(activeBS.x));
set(findobj(hFig, 'Tag', 'EditTextYcoord'), 'String', num2str(activeBS.y));
set(findobj(hFig, 'Tag', 'EditTextGroundHeight'), ...
    'String', num2str(activeBS.groundHeight));
set(findobj(hFig, 'Tag', 'EditTextUetaOwn'), 'String', num2str(100*activeBS.excessLoadOwn));
set(findobj(hFig, 'Tag', 'EditTextUetaTotal'), 'String', num2str(100*activeBS.excessLoadTotal));
set(findobj(hFig, 'Tag', 'EditTextAntennaHeight'), ...
    'String', num2str(activeBS.antennaHeight));
set(findobj(hFig, 'Tag', 'EditTextAntennaDir'), 'String', num2str(activeBS.antennaDir));
set(findobj(hFig, 'Tag', 'EditTextAntennaTilt'), 'String', num2str(activeBS.antennaTilt));
set(findobj(hFig, 'Tag', 'EditTextMhaGain'), 'String', num2str(activeBS.mhaGain));
set(findobj(hFig, 'Tag', 'EditTextRfHeadGain'), 'String', num2str(activeBS.rfHeadGain));
set(findobj(hFig, 'Tag', 'EditTextCableLosses'), 'String', num2str(activeBS.cableLosses));
set(findobj(hFig, 'Tag', 'EditTextTxPower'), 'String', num2str(activeBS.txMaxPower));
set(findobj(hFig, 'Tag', 'EditTextTxMaxPowerPerLink'), 'String', num2str(activeBS.txMaxPowerPerLink));
set(findobj(hFig, 'Tag', 'EditTextTxMinPowerPerLink'), 'String', num2str(activeBS.txMinPowerPerLink));
set(findobj(hFig, 'Tag', 'EditTextPTxDLAbsMax'), 'String', num2str(activeBS.pTxDLAbsMax));
set(findobj(hFig, 'Tag', 'EditTextCPICHPower'), 'String', num2str(activeBS.CPICHPower));
set(findobj(hFig, 'Tag', 'EditTextCommonChannelOther'), 'String', num2str(activeBS.commonChannelOther));
set(findobj(hFig, 'Tag', 'EditTextCPICHToRefRabOffset'), 'String', num2str(activeBS.CPICHToRefRabOffset));
set(findobj(hFig, 'Tag', 'EditTextChannel'), 'String', num2str(activeBS.channel));
set(findobj(hFig, 'Tag', 'EditTextNumCarr'), 'String', num2str(activeBS.numCarr));
set(findobj(hFig, 'Tag', 'EditTextWINDOW_ADD'), 'String', num2str(activeBS.WINDOW_ADD));
set(findobj(hFig, 'Tag', 'SliderWINDOW_ADD'), 'Value', activeBS.WINDOW_ADD);

allAnt = get(findobj(hFig, 'Tag', 'PopupAntennaType'), 'String');
for (kk = 1:size(allAnt, 1))
   if (strcmp(activeBS.antennaType, strtok(allAnt(kk, :))))
      set(findobj(hFig, 'Tag', 'PopupAntennaType'), 'Value', kk);
      break
   end
end
