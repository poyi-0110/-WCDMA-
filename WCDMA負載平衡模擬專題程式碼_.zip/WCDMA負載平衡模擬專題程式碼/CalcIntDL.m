%CALCINTDL   CALCINTDL calculates the interference in downlink
%
%Authors: Jaana Laiho-Steffens (jls), Achim Wacker (AWa), Kari Sipil� (KSi), 
%         Kai Heikkinen (KHeik)
%         
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: ReduceBStxPower.m

bsTxPowerLin = log2lin(bsTxPower);   %bsTxPower is also 0 (dBm) when there is no connection
bsTxPowerLin(find(bsTxPower==0)) = 0;%!!! ^^^that's the reason for this "adjustment"

ReduceBStxPower;

bsTxPower(find(bsTxPowerLin ~= 0)) = lin2log(bsTxPowerLin(find(bsTxPowerLin ~= 0)));
bsTxPower(find(bsTxPowerLin == 0)) = 0;

%calculate Ec/Io for each MS
CalcEcIoM;

%check whether EcIo is good eneough
CheckCPICHCoverage;

IownDL       = zeros(numBSs, numMSs);
IothDL       = zeros(numBSs, numMSs);
IoDL         = zeros(numBSs, numMSs);
C_over_I_all = zeros(numBSs, numMSs);
C_over_I     = zeros(1, numMSs);
msRxPowerLin = zeros(numBSs, numMSs);

bsTxPowerTotLin = sum(bsTxPowerLin.*repmat([mobilestation.vDL], numBSs, 1), 2)+...
                  log2lin([basestation.CPICHPower]')+...
                  log2lin([basestation.commonChannelOther]');
               
IoDL = (bsTxPowerLin ~= 0).*(bsTxPowerTotLin*ones([1, numMSs]))./log2lin(linklossDLM);               
IownDL = IoDL .*(ones([numBSs, 1])*(1-[mobilestation.orthFactor]));
msRxPowerLin = bsTxPowerLin./log2lin(linklossDLM);               
               
if numMStype1 & numBStype1
   IothDL(indBStype1, indMStype1) = ...
      (bsTxPowerLin(indBStype1, indMStype1) ~= 0).*...
      (ones([length(indBStype1), 1])*bsTxPowerTotLin(indBStype1)'*log2lin(-linklossDLM(indBStype1, indMStype1)))-...
      IoDL(indBStype1, indMStype1);   
   if numBStype2
      IothDL(indBStype1, indMStype1) = ...
         IothDL(indBStype1, indMStype1)+...
         (bsTxPowerLin(indBStype1, indMStype1) ~= 0).*...
         (ones([length(indBStype1), 1])*...
         max(log2lin(-acFilterDL(channelOffset))*bsTxPowerTotLin(indBStype2), log2lin(acMinPowDL))'*...
         log2lin(-linklossDLM(indBStype2, indMStype1)));
   end
end

if numMStype2 & numBStype2
   IothDL(indBStype2, indMStype2) = ...
      (bsTxPowerLin(indBStype2, indMStype2) ~= 0).*...
      (ones([length(indBStype2), 1])*bsTxPowerTotLin(indBStype2)'*log2lin(-linklossDLM(indBStype2, indMStype2)))-...
      IoDL(indBStype2, indMStype2);   
   if numBStype1
      IothDL(indBStype2, indMStype2) = ...
         IothDL(indBStype2, indMStype2)+...
         (bsTxPowerLin(indBStype2, indMStype2) ~= 0).*...
         (ones([length(indBStype2), 1])*...
         max(log2lin(-acFilterDL(channelOffset))*bsTxPowerTotLin(indBStype1), log2lin(acMinPowDL))'*...
         log2lin(-linklossDLM(indBStype1, indMStype2)));
   end
end

Itot = IownDL+IothDL+MS_noise_power_lin;
ind = find(Itot);

C_over_I_all(ind) = msRxPowerLin(ind)./Itot(ind);

temp = sum(C_over_I_all, 1);
ind = find(temp);

C_over_I(ind) = lin2log(temp(ind));
