%CalcOrthogonality  alpha = CalcOrthogonality(lpTables, speeds) returns the orthogonality
%                   factor needed in DL interference calculation. The MS speed is used as 
%                   input and also the link performance tables from where the orthogonality 
%                   is interpolated.
%
%Inputs:
%   lPTables  : linkPerfTables for a channel, see e.g. pedALinkPerfTables.m   
%   speeds    : the speeds at which the orthogonality is calculated.
%Outputs:
%   alpha     : The orthogonality for the input speeds and input channel
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function alpha = CalcOrthogonality(lPTables, speeds);

tabspeed = lPTables.speeds;
tabalpha = lPTables.orthogonality;

alpha = zeros(size(speeds));
m1 = length(lPTables.speeds);

%If the input speeds are outside the tabled speeds special action is taken.
bits1 = speeds < tabspeed(1);
bits2 = speeds > tabspeed(m1);
bits3 = ~(bits1 | bits2);

if (sum(bits1) > 0)
   alpha(bits1) = tabalpha(1);
end

if (sum(bits2) > 0)
   alpha(bits2) = tabalpha(m1);
end

if (sum(bits3) > 0)
   alpha(bits3) = interp1(tabspeed, tabalpha, speeds(bits3));
end
