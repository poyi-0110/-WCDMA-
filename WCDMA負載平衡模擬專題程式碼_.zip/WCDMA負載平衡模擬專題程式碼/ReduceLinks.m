%REDUCELINKS   REDUCELINKS reduce links if the site is hard blocked
%                                      
%Inputs:
%Outputs:
%
%Author : Kari Heiska (KHe), Achim Wacker (AWa), Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%											   
%needed m-files: DoIFHO.m, DoSaattohoito.m

indexCh = find(hardBlockCells); %index of those cells where the users > no channels

msTempOutageInd = zeros([1, numMSs]);
tmpUsedCarr = [mobilestation(:).usedCarr];
tmpUsedCarr(tmpUsedCarr >= 1) = 1;

if (loadControlSwitch == 1) 
   for n = 1:numBSs
      if ~isempty(indexCh)
         if sum(indexCh == n) > 0 %if the number of users in the basestation n is too high  
            %order these randomly to avoid changing the spatial distribution within cell
            Carr_temp = tmpUsedCarr;
            msIndSHO = find(linksUplink(n,:) & Carr_temp == 1);
            msIndSHOtemp = randperm(length(msIndSHO));	
            msIndSHO = msIndSHO(msIndSHOtemp);   
            pool = find([basestation(:).site] == basestation(n).site);
            target = sum([basestation(pool).channels])*sum(linksUplink(n, msIndSHO)) / ...
                     sum(sum((linksUplink(pool, :)).*(repmat(Carr_temp,length(pool), 1)==1)));
            diff_temp = (sum(linksUplink(n, msIndSHO))-target).*(sum(linksUplink(n, msIndSHO))-target>0);
            %index of the mobiles from where the mobiles will be put to another carrier
            ind2 = fix(sum(linksUplink(n, msIndSHO))/(((diff_temp)./target)*0.05+1));
            clear diff_temp Carr_temp pool links_pool target;
            msIndSHO = msIndSHO(fix(ind2):end);
            
            if length(msIndSHO) > 1
               tmpUsedCarr(msIndSHO) = -1;
					msTempOutageInd(msIndSHO) = 1;					               
            end
         end
      end
   end
else 
   for n = 1:numBSs
      if ~isempty(indexCh)
         if sum(indexCh == n) > 0 %if the number of users in the basestation n is too high  
            %order these randomly to avoid changing the spatial distribution within cell
            Carr_temp = tmpUsedCarr;
            msIndSHO = find(linksUplink(n,:) & Carr_temp == 1);
            msIndSHOtemp = randperm(length(msIndSHO));	
            msIndSHO = msIndSHO(msIndSHOtemp);   
            pool = find([basestation(:).site] == basestation(n).site);
            target = sum([basestation(pool).channels])*sum(linksUplink(n, msIndSHO)) / ...
                     sum(sum((linksUplink(pool,:)).*(repmat(Carr_temp, length(pool), 1)==1)));
            diff_temp = (sum(linksUplink(n, msIndSHO))-target).*(sum(linksUplink(n, msIndSHO))-target>0);
            %index of the mobiles from where the mobiles will be put to another carrier
            ind2 = fix(sum(linksUplink(n, msIndSHO))/(((diff_temp)./target)*0.05+1));
            clear diff_temp Carr_temp pool target;
            msIndSHO = msIndSHO(fix(ind2):end);
            
            if length(msIndSHO) > 1
               tmpUsedCarr(msIndSHO) = -1;
					msTempOutageInd(msIndSHO) = 1;					               
            end
         end
      end
   end 
end

if mode == 1 & length(indBStype1) >= 1 & length(indBStype2) >= 1
   msIFHOcountNotExceededInd = (ifhoCounter < limitIFHO);
   msChangeCarrierInd = find(msTempOutageInd & msIFHOcountNotExceededInd);
   if length(msChangeCarrierInd) >= 1
      tmpVect = [mobilestation(msChangeCarrierInd).usedCarr];
      tmpVect = 1+mod(tmpVect, 2);
      tmpVect = num2cell(tmpVect);
      [mobilestation(msChangeCarrierInd).usedCarr] = deal(tmpVect{:});
      msIndGeneric = msChangeCarrierInd;
      DoIFHO;
   end
   msOutageInd = find(msTempOutageInd & ~msIFHOcountNotExceededInd);
else
   msOutageInd = find(msTempOutageInd);
end
if length(msOutageInd) >= 1
   [mobilestation(msOutageInd).usedCarr] = deal(-1);
   msIndSaattohoito = msOutageInd;
   DoSaattohoito;
   %set flag at BS n that additional carrier would be needed
   addCarrNeeded(unique(bestServerV(msIndSaattohoito))) = 1;
end

indMStype1 = find([mobilestation.usedCarr] == 1);
indMStype2 = find([mobilestation.usedCarr] == 2);
numMStype1 = length(indMStype1);
numMStype2 = length(indMStype2);
