%BESTSERVERUL   [neededMsTxPowerV, bestServerV, deltaSHOV] = BestServerUL(perf, linklossULM,
%               activeSetM);
%               calculates needed ms tx power, best server and distance from the 
%               next best server for each MS assuming wideAreaCovEbNo and wideAreaCovR. 
%               Calculation is done by using the coverage threshold found in RlbUL.m.
%               This is later corrected to the right bit-rates and Eb/No:s in CalcMStx.m.
%               bestServer will be searched only from the active set described in the
%               activeSetM matrix.
%				  
%Inputs:
%   PERF            : structure holding the performances of the BSs
%   LINKLOSSM       : (NumBSs * NUMMSS) matrix holding the link loss of BS,
%                     1...NumBSs, to the mobile stations 1,...,numMSs.
%   ACTIVESETM      : (m,n), m=1,..,numBSs, n=1,...,numMSs matrix holding 1 if BS(m) is in 
%			             the active set of MS(n) and 0 if not.  
%Outputs:   
%   NEEDEDMSTXPOWERV: NUMMSS-vector of the minimum needed average (over multi-path fading) 
%                     transmit powers needed for each mobile assuming wideAreaCovEbNo and -R.
%   BESTSERVERV     : NUMMSS-vector of the bestserver index for each MS. 
%   DELTASHOV       : NUMMSS-vector of the distances between the best and the next best server,
%                     seen from each mobile
%Comment:
%   Best server in this context is that BS to which mobile has to transmit with the
%   smallest power
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa), Jaana Laiho-Steffens (jls)
%         Kai Heikkinen (KHeik) NET
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function [neededMsTxPowerV, bestServerV, deltaSHOV] = BestServerUL(perf, linklossM, activeSetM);

numBStype1 = evalin('base', 'numBStype1');
numBStype2 = evalin('base', 'numBStype2');
numMStype1 = evalin('base', 'numMStype1');
numMStype2 = evalin('base', 'numMStype2');
indBStype1 = evalin('base', 'indBStype1');
indBStype2 = evalin('base', 'indBStype2');
indMStype1 = evalin('base', 'indMStype1');
indMStype2 = evalin('base', 'indMStype2');

[numBSs, numMSs] = size(linklossM);

%a matrix holding required ms tx power for every MS to every BS
neededMsTxPowerM = [perf.covth]'*ones([1, numMSs])+linklossM;

%the BS not in active set put to a high value.
neededMsTxPowerM = neededMsTxPowerM.*activeSetM+(~activeSetM).*9999;   
   
if numMStype2 & numBStype1
	neededMsTxPowerM(indBStype1, indMStype2) = 9999;
end
if numMStype1 & numBStype2
   neededMsTxPowerM(indBStype2, indMStype1) = 9999;
end
   
[neededMsTxPowerV bestServerV] = min(neededMsTxPowerM, [], 1);

tmpPerm = eye(numBSs);

%The best server is put to high needed power to see the next best server
neededMsTxPowerM = neededMsTxPowerM+tmpPerm(:, bestServerV).*(9999-neededMsTxPowerM);

[tmpMsTxPowerV tmpbestServerV] = min(neededMsTxPowerM, [], 1);

%The link difference of best server and next best server.
deltaSHOV = abs(tmpMsTxPowerV-neededMsTxPowerV);
