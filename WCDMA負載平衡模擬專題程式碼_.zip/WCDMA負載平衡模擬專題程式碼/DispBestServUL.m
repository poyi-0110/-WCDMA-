%DISPBESTSERVUL   DISPBESTSERVUL plots best servers for uplink
%
%Inputs:
%Outputs:   
%Comment:
%   Best server in this context is that BS to which mobile has to transmit with the
%   smallest power
%
%Authors: Achim Wacker (AWa), Kari Heiska (KHe), jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BSplot.m

%'layer' when script is called from within CalcCovPUL.m
%loop here impossible (or difficult) because called twice from CalcCovPUL.m
if numBStype1 & (~exist('layer') | layer == 1)
   bestServerColors1 = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.9 0.9 0.9];
   bestServerColors  = [bestServerColors1' 0.8*bestServerColors1' ...
                        0.6*bestServerColors1(1:5, :)' 0.4*bestServerColors1(1:5, :)']';
   while (size(bestServerColors, 1) < numBStype1)
      bestServerColors = [bestServerColors' bestServerColors']';
   end
   
   bestServerColors = [[0 0 0]' bestServerColors']';
   
   tmpBestServerA = squeeze(bestServer(1,:,:));
   tmpBestServer  = zeros(size(tmpBestServerA));
   for kk = 1:numBStype1
      tmpBestServer(find(tmpBestServerA == indBStype1(kk))) = kk;
   end
   tmpBestServer(~isnan(waterArea)) = NaN;
   
   figure
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          tmpBestServer);
   colormap(bestServerColors(1:numBStype1+1, :));
   caxis([0 numBStype1+1]);
   hcb = colorbar('vert');
   
   if numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = ['for carrier 1'];
      elseif mode == 2
         layerString = ['for operator 1'];
      end
   end  
   titleText = ['BEST SERVER ' layerString ' - based on minimum MS TX power'];
   title(['\it{}' titleText]);
   
   shading('flat');
   axis('image');
   set(get(hcb, 'Title'), 'String', 'Receiving BS');
   set(hcb, 'Ytick', [0:numBStype1+1]);
   tLabelStr = num2str(indBStype1(1));
   for kk = 2:numBStype1
      tLabelStr = str2mat(tLabelStr, num2str(indBStype1(kk)));
   end
   set(hcb, 'yticklabel', str2mat(['no coverage'], tLabelStr(1:end, :)));
   set(hcb, 'Ytick', get(hcb, 'Ytick')+0.5);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
end

if numBStype2 & (~exist('layer') | layer == 2)
   bestServerColors1 = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 0.9 0.9 0.9];
   bestServerColors  = [bestServerColors1' 0.8*bestServerColors1' ...
                        0.6*bestServerColors1(1:5, :)' 0.4*bestServerColors1(1:5, :)']';
   while (size(bestServerColors, 1) < numBStype2)
      bestServerColors = [bestServerColors' bestServerColors']';
   end
   
   bestServerColors = [[0 0 0]' bestServerColors']';
   
   tmpBestServerA = squeeze(bestServer(2, :, :));
   tmpBestServer  = zeros(size(tmpBestServerA));
   for kk = 1:numBStype2
      tmpBestServer(find(tmpBestServerA == indBStype2(kk))) = kk;
   end

   figure;
   tmpBestServer(~isnan(waterArea)) = NaN;
   
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          tmpBestServer);
   colormap(bestServerColors(1:numBStype2+1, :));
   caxis([0 numBStype2+1]);
   hcb = colorbar('vert');
   if numBStype1 == 0
      layerString = [];
   else
      if mode == 1
         layerString = ['for carrier 2'];
      elseif mode == 2 
         layerString = ['for operator 2'];
      end
   end  
   title(['\it{BEST SERVER ' layerString ' - based on minimum MS TX power}']);
   shading('flat');
   axis('image');
   set(get(hcb, 'Title'), 'String', 'Receiving BS');
   set(hcb, 'Ytick', [0:numBStype2+1]);
   tLabelStr = num2str(indBStype2(1));
   for kk = 2:numBStype2
      tLabelStr = str2mat(tLabelStr, num2str(indBStype2(kk)));
   end
   tlabel = get(hcb, 'yticklabel');
   set(hcb, 'yticklabel', str2mat(['no coverage'], tLabelStr(1:end, :)));
   set(hcb, 'Ytick', get(hcb, 'Ytick')+0.5);
   set(hcb, 'ticklength', [0 0]);
   BSplot(basestation, gcf, vectMap, lossData);
end

clear layerString bestServerColors bestServerColors1 hcb tlabel
