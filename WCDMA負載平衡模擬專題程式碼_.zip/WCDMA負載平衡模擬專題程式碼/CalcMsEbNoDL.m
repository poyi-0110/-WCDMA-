%CALCMSEBNODL   MSEBNOS = CALCMSEBNODL(lpTables, speeds, bitrates) returns the single link
%               Eb/Nos in downlink for the mobiles with speed and bitrate. 
%               EbNos are interpolated from link performance tables.
%               Calculates the msEbNos from EbNos tables by interpolating for different
%               speeds. The closest bit rate in EbNos tables is chosen for each mobile.
%   NOTE:       speeds and bitrates must be the same size                       
%
%Inputs:
%   lPTables: linkPerformanceTables, see LoadLinkPerfTables.m
%   speeds  : the speeds at which the Eb/Nos are calculated.	
%   bitrates: the bit-rates at which the Eb/Nos are calculated
%Outputs:
%   msEbNos : The target downlink EbNos for the mobiles.
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function msEbNos = CalcMsEbNoDL(lPTables, speeds, bitrates);

% Find the closest bit-rate from lPTables.bitRates to each mobile.
bitRateDiff = [];
m1 = length(lPTables.bitRates);
for i1 = 1:m1
   bitRateDiff = [bitRateDiff; bitrates-lPTables.bitRates(i1)];
end
[Y, I1] = min(abs(bitRateDiff), [], 1);
% Index table I1 points to closest bit-rate row for each mobile.

tabspeed = lPTables.speeds;
tabebno  = lPTables.EbNoDL;

msEbNos = zeros(size(speeds));

% If there are smaller or larger speeds in mobilestations
% than in EbNo tables those speeds are inserted to tables 
% by repeating first and last EbNos in the original tables. 

minsp = min(speeds);
if (minsp < min(lPTables.speeds)) 
   tabspeed = [minsp, tabspeed];
   tabebno = [tabebno(:, 1), tabebno];
end

m2 = length(tabspeed);
maxsp = max(speeds);
if (maxsp > max(lPTables.speeds)) 
   tabspeed = [tabspeed, maxsp];
   tabebno  = [tabebno, tabebno(:, m2)];
end

% Finally EbNos are interpolated
for i1 = 1:m1, 
   bits = find(I1==i1);
   msEbNos(bits) = interp1(tabspeed, tabebno(i1, :), speeds(bits));
end
