%CalcVoiceActivityUL  vul = CalcVoiceActivityUL(lpTables, bitrates) returns the voice
%                     activity factors in uplink as a function of MS bitrate. Closest bitrate
%                     from linkPerfTables is chosen
%
%Inputs:
%   lPTables: linkPerformanceTables, see LoadLinkPerfTables.m	
%   bitrates: the bit-rates at which the voice activity factors are calculated.		  
%Outputs:   
%   vul     : voice activity factors in uplink for the bitrates.
%
%Author : Kari Sipil� (KSi)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function vul = CalcVoiceActivityUL(lPTables, bitrates);

%Find the closest bit-rate from lPTables.bitRates to each mobile.
bitRateDiff = [];
m1 = length(lPTables.bitRates);
for i1 = 1:m1
	bitRateDiff = [bitRateDiff; bitrates-lPTables.bitRates(i1)];
end
[Y, I1] = min(abs(bitRateDiff), [], 1);
%Index table I1 points to closest bit-rate row for each mobile.

vul = ones(size(bitrates));
for i1 = 1:m1
   bits = find(I1==i1);
   vul(bits) = lPTables.vUL(i1);
end
