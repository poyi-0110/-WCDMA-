%CALCACTIVESET   Calculates the active set matrices for MS-BS connections and for 
%                BS-map pixel connections. The k:th basestation will be in active set
%                for an MS or a map pixel if the received CPICH power will be higher 
%                than the strongest CPICH  strength minus WINDOW_ADD parameter of the 
%                BS with strongest CPICH. 
%
%Inputs:
%   BASESTATION     : structure holding the BS data, including perch powers.
%   LINKLOSS        : (NumBSs * yPixels * xPixels) matrix holding the link loss of BS, 
%                     1...NumBSs, to the map pixels.
%Outputs:
%   ACTIVESETM      : (m, n), m=1, .., numBSs, n=1, ..., numMSs matrix holding 1 if BS(m) is in 
%                     the active set of MS(n) and 0 if not.  
%   ACTIVESETT      : (k, j, i), k=1, ..., numBSs, j=1, ..., yPixels, i=1, ..., xPixels, matrix
%                     holding 1 if BS(k) is in the active set in pixel (j, i) and 0 if not.
%
%Authors: Achim Wacker (AWa), Kari Sipil� (KSi), Kari Heiska (KHe), 
%         Jaana Laiho-Steffens (jls), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: BestServerDL.m, CalcSHO.m

[CPICHLevel, bestServDL, CPICHStrength, bestServDLV] = BestServerDL(basestation, linklossDL);
CalcSHO;
activeSetM = (rxLevels1~=0);
activeSetT = zeros(numBSs, yPixels, xPixels);
for j = 1:yPixels
   for i = 1:xPixels
      if numBStype1
         activeSetT(indBStype1, j, i) = (CPICHStrength(indBStype1, j, i) >= (CPICHLevel(1, j, i)+...
                                                                             basestation(bestServDL(1, j, i)).WINDOW_ADD));
      end
      if numBStype2
         activeSetT(indBStype2, j, i) = (CPICHStrength(indBStype2, j, i) >= (CPICHLevel(2, j, i)+...
                                                                            basestation(bestServDL(2, j, i)).WINDOW_ADD));
      end
   end
end
linksUplink = activeSetM;
