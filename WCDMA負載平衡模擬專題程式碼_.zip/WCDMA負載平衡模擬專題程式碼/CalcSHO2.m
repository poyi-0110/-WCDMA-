%CALCSHO2   CALCSHO2 recalculates the matrix holding all the SHO connections for the MSs which are in 
%           the vector msIndGeneric.
%
%Authors: Achim Wacker (AWa) NET, Kai Heikkinen (KHeik), NET, Kari Sipil� (KSi) NET
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

rxLevels1(1:numBSs, msIndGeneric) = 0;

for runType = 1:2
   eval(['indMStypeX = indMStype' num2str(runType) ';']);
   eval(['indBStypeX = indBStype' num2str(runType) ';']);
   if ~isempty(indBStypeX) & ~isempty(indMStypeX)
      tmpind = msIndGeneric(find([mobilestation(msIndGeneric).usedCarr]==runType));
      if ~isempty(tmpind)
         rxLevels = CPICHStrengthM(indBStypeX, tmpind);
         [maxLevel, maxLevelIndex] = max(rxLevels, [], 1);
         bestServDLV(tmpind) = indBStypeX(maxLevelIndex);
         %set rxLevels1 to zero where there is no connection
         rxLevels(rxLevels<(ones([length(indBStypeX), 1])*(maxLevel+[basestation(bestServDLV(tmpind)).WINDOW_ADD]))) = 0;
         rxLevels1(indBStypeX, tmpind) = rxLevels;
      end
   end
end

activeSetM = (rxLevels1~=0);
linksUplink = activeSetM;

clear tmpind maxLevel maxLevelIndex rxLevels indBStypeX indMStypeX
