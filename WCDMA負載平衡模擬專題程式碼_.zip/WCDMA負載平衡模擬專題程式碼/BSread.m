%BSREAD   (BASESTATION NUMBSS) = BSREAD(BS_FILENAME, PATHLOSSMODEL, LOSSDATA, useImportedAntennaInfo)
%         reads the BS parameter file
%
%Inputs:
%   BS_FILENAME  : file which contains BS parameters
%   PATHLOSSMODEL: which model has been used for prediction or when importing
%   LOSSDATA     : The link loss and BS info when import feature was used
%Outputs:
%   BASESTATION: array of structures holding BS parameters
%   NUMBSS     : number of base stations
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Heiska (KHe), 
%         Kari Sipil?(KSi), Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function [basestation, numBSs, indBStype1, indBStype2, numBStype1, numBStype2] = BSread(...
   bsFilename, pathlossModel, lossData, useImportedAntennaInfo, channelFiles, numBStype1, numBStype2, mode);

if (nargin == 0)
   bsFilename = ('BSparam.txt');
end

bsFilePointer = fopen(bsFilename, 'rt');

if (bsFilePointer == -1)
   error(['BS file ''' bsFilename ''' does not exist !']);
end
k = 0;
line_out = [];
while (1)
   line = fgetl(bsFilePointer);
   if (~isstr(line))
      break
   end
   
   if (k == 0)
      line = fgetl(bsFilePointer); %skip header line
   end
   
   k = k+1;
   
   value = sscanf(line, '%f%f%f%f%f%f%f%f%f%f%f%s%f%f%f%f%f%f%f%d%d%f%f');
   

   basestation(k).x = value(1);
   basestation(k).y = value(2);
   basestation(k).groundHeight = value(3);
   basestation(k).antennaHeight = value(4);
   basestation(k).txMaxPower = value(5);
   basestation(k).txMaxPowerPerLink = value(6);
   basestation(k).txMinPowerPerLink = value(7);
   basestation(k).pTxDLAbsMax = value(8);
   basestation(k).CPICHPower = value(9);
   basestation(k).commonChannelOther = value(10);
   basestation(k).CPICHToRefRabOffset = value(11);
   basestation(k).antennaType = char(value(12:end-11)');
   basestation(k).antennaDir = value(end-10);
   
   basestation(k).antennaTilt = value(end-9);
   %basestation(k).antennaTilt = (value(end-9)+z(k));
   %basestation(k).antennaTilt = (value(end-9)+z(1,k));
   
   basestation(k).cableLosses = value(end-8);
   basestation(k).mhaGain = value(end-7);
   basestation(k).rfHeadGain = value(end-6);
   basestation(k).channel = value(end-5);
   basestation(k).WINDOW_ADD = value(end-4);
   basestation(k).numCarr = value(end-3);
   basestation(k).usedCarr = value(end-2);
   basestation(k).excessLoadOwn = value(end-1);
   basestation(k).excessLoadTotal = value(end);
   
   if ((pathlossModel == 7) | (pathlossModel == 8))
      if (k > lossData(1).numBSs)
         error(['Error: Mismatch in BS and nps/x import file']);
      end
      txloc = lossData(k).txloc;
      basestation(k).x = txloc(1);
      basestation(k).y = txloc(2);
      basestation(k).txMaxPower = value(5);
      basestation(k).txMaxPowerPerLink = value(6);
      basestation(k).txMinPowerPerLink = value(7);
      basestation(k).pTxDLAbsMax = value(8);
      basestation(k).CPICHPower = value(9);
      basestation(k).commonChannelOther = value(10);
      basestation(k).CPICHToRefRabOffset = value(11);
      basestation(k).groundHeight = lossData(k).Hg;
      basestation(k).antennaHeight = lossData(k).Ha;
      if (lossData(k).model == 3) | (useImportedAntennaInfo)
         basestation(k).antennaType = 'npsx';        %npsx is the same as isotropic
         basestation(k).antennaDir = lossData(k).Ba; %Bearing
         basestation(k).antennaTilt = lossData(k).Ta;%Tilt
      end
      basestation(k).cableLosses = value(end-8);
      basestation(k).mhaGain = value(end-7);
      basestation(k).rfHeadGain = value(end-6);
      basestation(k).channel = value(end-5);
      basestation(k).WINDOW_ADD = value(end-4);
      basestation(k).numCarr = value(end-3);
      basestation(k).usedCarr = value(end-2);
      basestation(k).excessLoadTotal = value(end-1);
      basestation(k).excessLoadTotal = value(end);
      line_out = [line_out; [basestation(k).x basestation(k).y basestation(k).groundHeight ...
                             basestation(k).antennaHeight      basestation(k).txMaxPower ...
                             basestation(k).txMaxPowerPerLink  basestation(k).txMinPowerPerLink ...
                             basestation(k).pTxDLAbsMax        basestation(k).CPICHPower ...
                             basestation(k).commonChannelOther basestation(k).CPICHToRefRabOffset ...
                             basestation(k).antennaDir ...
                             basestation(k).antennaTilt        basestation(k).cableLosses ...
                             basestation(k).mhaGain            basestation(k).rfHeadGain ...
                             basestation(k).channel            basestation(k).WINDOW_ADD ...
                             basestation(k).numCarr            basestation(k).usedCarr ...
                             basestation(k).excessLoadOwn      basestation(k).excessLoadTotal]];
   end
end

fclose(bsFilePointer);
numBSs = k;  

%If the nps/x maps are used the new file replaces the old one
if ((pathlossModel == 7) | (pathlossModel == 8))
   bsFilePointer = fopen(bsFilename, 'wt');
   
   fprintf(bsFilePointer, '%s\n', 'xPos	yPos	groundHeight	antHeight	txMaxPower	txMaxPowerPerLink	txMinPowerPerLink	pTxDLAbsMax	CPICHPower	commonChannelOther	CPICHToRefRabOffset	antType	antDir	antTilt	cableLosses	mhaGain	rfHeadGain	channel	windowADD	numCarr	usedCarr	excessLoadOwn	excessLoadTotal');
   for k = 1:numBSs
      fprintf(bsFilePointer, '%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t', line_out(k, 1:11));
      fprintf(bsFilePointer, [basestation(k).antennaType]);
      if k < numBSs
         fprintf(bsFilePointer, '\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.0f\t%.2f\t%.0f\t%.0f\t%.2f\t%.2f\n', line_out(k, 12:22));
      else
         fprintf(bsFilePointer, '\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.0f\t%.2f\t%.0f\t%.0f\t%.2f\t%.2f', line_out(k, 12:22));
      end
   end
   fclose(bsFilePointer);
end
basestation = basestation(1:numBSs);
indBStype1  = find([basestation.usedCarr] == 1);
indBStype2  = find([basestation.usedCarr] == 2);
numBStype1a = length(indBStype1);
numBStype2a = length(indBStype2);
if (numBStype1a~=numBStype1) | (numBStype2a~=numBStype2)
   button = questdlg(...
      ['Mismatch in number of BSs in npswini.m and ' bsFilename '. ' ...
       'Adjust according info from ' bsFilename ' and continue or Exit ?'], ...
       'BS error', 'Continue', 'Exit', 'Continue');
   if strcmp(button, 'Continue')
      numBStype1 = numBStype1a;
      numBStype2 = numBStype2a;
      numBSs = numBStype1+numBStype2;
   else
      error('npsw terminated due to error in ''BSread.m''');
   end
end

%create some names
if (numBStype1 == 0)
   for kk = 1:numBStype2
      basestation(kk).name = {[' Cell_{', num2str(kk), '}']};
   end
elseif (numBStype2 == 0)
   for kk = 1:numBStype1
      basestation(kk).name = {[' Cell_{', num2str(kk), '}']};
   end
else
   if mode == 2
      for kk = 1:numBStype1
         basestation(indBStype1(kk)).name = {[' OP1_{', num2str(kk), '}']};
      end
      for kk = 1:numBStype2
         basestation(indBStype2(kk)).name = {[' OP2_{', num2str(kk), '}']};
      end
   elseif mode == 1
      for kk = 1:numBStype1
         basestation(indBStype1(kk)).name = {[' CA1_{', num2str(kk), '}']};
      end
      for kk = 1:numBStype2
         basestation(indBStype2(kk)).name = {[' CA2_{', num2str(kk), '}']};
      end
   end
end

if (numBStype2 > 0) & (numBStype1 > 0)
   if mode == 1
      layerString = ['CA'];
   elseif mode == 2
      layerString = ['OP'];
   end
   for kk = indBStype1
      basestation(kk).nameLong = {[layerString '1\_BS_{', num2str(find(indBStype1 == kk)), '}']};
   end
   for kk = indBStype2
      basestation(kk).nameLong = {[layerString '2\_BS_{', num2str(find(indBStype2 == kk)), '}']};
   end
elseif numBStype2 == 0
   for kk = indBStype1
      basestation(kk).nameLong = {['BS_{', num2str(find(indBStype1 == kk)), '}']};
   end
elseif numBStype1 == 0
   for kk = indBStype2
      basestation(kk).nameLong = {['BS_{', num2str(find(indBStype2 == kk)), '}']};
   end
end
