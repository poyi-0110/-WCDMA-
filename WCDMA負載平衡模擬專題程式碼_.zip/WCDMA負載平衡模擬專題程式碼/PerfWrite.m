%PERFWRITE   PERFWRITE(PERFORMANCE, FILENAME) writes performance to parameter file
%
%Inputs:
%   PERFORMANCE: array of performance structures to be saved
%   FILENAME   : name of the output file (optional, default=Performance.txt)
%Outputs:
%   none
%
%Author : Achim Wacker (AWa) NTC
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function PerfWrite(performance, perfFilename)

if (nargin == 1)
   perfFilename = 'Performance.txt';
elseif (nargin ~= 2)
   error('wrong number of input arguments');
end

perfFID = fopen(perfFilename, 'w');

numPerfs = length(performance);
for k = 1:numPerfs
   fprintf(perfFID, '%f\t', performance(k).i);
   fprintf(perfFID, '%d\t', performance(k).m);
   fprintf(perfFID, '%f\t', performance(k).SHO);
   fprintf(perfFID, '%f\t', performance(k).covth);
   fprintf(perfFID, '%d\t', performance(k).mDL);
   fprintf(perfFID, '\n');
end
fclose(perfFID);

return
