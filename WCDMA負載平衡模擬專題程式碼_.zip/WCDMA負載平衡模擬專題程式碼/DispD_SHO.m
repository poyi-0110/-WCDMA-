%DISPD_SHO  DISD_SHO displays the dominance and SHO area
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), KAri Heiska (KHe), Jaana Laiho-Steffens (jls),
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcSHOarea.m, BSplot.m

if (exist('SHOarea') ~= 1)
   CalcSHOarea;
end

helpme = size(SHOarea);

%following is for the script to work also in 1-operator case
if numBStype2 == 0 | numBStype1 == 0
   helpme = 2*helpme;
end

tmpLayer = [];
if numBStype1
   tmpLayer = [tmpLayer 1];
end
if numBStype2
   tmpLayer = [tmpLayer 2];
end

for layer = tmpLayer
   domin_SHO = squeeze(CPICHLevel(layer, :, :));
   domin_SHO(find(domin_SHO>rxLevMin+64)) = rxLevMin+64;
   i1 = find(domin_SHO<=rxLevMin);
   if numBStype2 == 0 | numBStype1 == 0
      domin_SHO(find(SHOarea(1:helpme(1)/2, :))) = rxLevMin-1;
   else
      domin_SHO(find(SHOarea(helpme(1)/2+1:end, :))) = rxLevMin-1;
   end
   domin_SHO(i1) = rxLevMin-eps;
   domin_SHO(~isnan(waterArea)) = NaN;
   figure
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          domin_SHO)
   caxis([rxLevMin-1 rxLevMin+64]);
   colormap([[1 1 1]; [0 0 0]; jet(63)]);
   hcb = colorbar('vert');
   axis('equal');
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 1
         layerString = [' for carrier ' num2str(layer)];
      elseif mode == 2
         layerString = [' for operator ' num2str(layer)];
      end
   end
   title(['\it{Dominance and SHO area' layerString ', WINDOW\_ADD = ' ...
          num2str(basestation(1).WINDOW_ADD) ' dB}']);
   shading('flat')
   set(get(hcb, 'Title'), 'String', 'CPICH RX level');
   set(hcb, 'yticklabel', strcat(get(hcb, 'yticklabel'), ' dBm'));
   BSplot(basestation, gcf, vectMap, lossData);
   
   if numBStype1 == 0 | numBStype2 == 0
      SHOarea1 = SHOarea(1:helpme(1)/2, :);
      SHOarea1(find(SHOarea(1:helpme(1)/2, :)==0)) = NaN; 
   else
      SHOarea1 = SHOarea(1+helpme(1)/2:end, :);
      SHOarea1(find(SHOarea(1+helpme(1)/2:end, :)==0)) = NaN; 
   end
   
   figure
   BSplot(basestation, gcf, vectMap, lossData);
   hold on
   if (pathlossModel == 7 | pathlossModel == 8)
      colors = colormap;
      colors = [colors; [0 .6 0]]; % green
      SHOarea1 = (length(colormap)+1)*SHOarea1;
      SHOarea1(~isnan(waterArea)) = NaN;
   else
      colors = [ 1 .8 .4];
   end
   if numBStype1 == 0 | numBStype2 == 0
      layerString = [];
   else
      if mode == 2
         layerString = ['Operator ' num2str(layer) ': '];
      else
         layerString = ['Carrier ' num2str(layer) ': '];
      end
   end
   title(['\it{' layerString 'SHO area for WINDOW\_ADD_1 = ' num2str(basestation(1).WINDOW_ADD) ' dB}']);
   
   pcolor(xmin:resolution:xmax, ...
          ymin:resolution:ymax, ...
          SHOarea1)
   colormap(colors);
   shading('flat')
end
clear domin_SHO colors SHOarea1
