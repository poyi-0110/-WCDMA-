%CALCM_RDL   CALCM_RDL   calculates perf.mDL and perf.RDL
%                                      
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil� (KSi)
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none                      

saveBestServDLV = bestServDLV;
bestServDLV(find(bestServDLV<1)) = 1;
tmpPerm = eye(numBSs);
tmpPerm = tmpPerm(:, bestServDLV);
tmpOnes = ones(1, numMSs);
tmpMsR  = [mobilestation.RDL];
tmpOnes(usedCarrV < 1 | msTxPowerV == -999) = 0;

tmpPerfM = (tmpPerm*tmpOnes')';

tmpTotalBits = (tmpPerm*(tmpMsR.*tmpOnes)')';
tmpPerfR = zeros(size(tmpPerfM));
ind1 = find(tmpPerfM>0);
tmpPerfR(ind1) = tmpTotalBits(ind1)./tmpPerfM(ind1);

tmpPerfM = num2cell(tmpPerfM);
tmpPerfR = num2cell(tmpPerfR);

[perf.mDL] = deal(tmpPerfM{:});
[perf.RDL] = deal(tmpPerfR{:});

%clean up
BestServDLV = saveBestServDLV;
clear tmpPerm tmpOnes tmpPerfM tmpPerfR ind1 tmpTotalBits tmpMsR saveBestServDLV
