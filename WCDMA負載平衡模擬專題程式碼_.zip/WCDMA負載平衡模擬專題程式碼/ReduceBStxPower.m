%REDUCEBSTXPOWER   REDUCEBSTXPOWER limits the power per link and the total tx power of
%                  a base station according the method specified in npswini by 
%                  reducePowerSwitch
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls), Kari Sipil� (KSi)
%         Kai Heikkinen (KHeik)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: DoIFHO.m, DoSaattohoito.m, lin2log.m, log2lin.m

%first the powers per link are limited and then the maximum bsTxPower is checked according
%reducePowerSwitch

if limitDLPowerSwitch
   %for all base stations
   if iteration == 1
      for k = 1:numBSs
         basestation(k).txMaxPowerPerLink = min(basestation(k).txMaxPowerPerLink, basestation(k).pTxDLAbsMax);
         
         %there is no pTxDLAbsMin in SFS so use -999 (still in npwini but to make sure also here)
         pTxDLAbsMin = -999;
         
         basestation(k).txMinPowerPerLink = max(basestation(k).txMinPowerPerLink, pTxDLAbsMin);
         
         %set the maximum for the reference RAB at that bs
         txMaxPowerRefRab(k) = basestation(k).CPICHPower-basestation(k).CPICHToRefRabOffset;
         
         %check it against the limits
         if ((txMaxPowerRefRab(k) > basestation(k).txMaxPowerPerLink) | ...
             (txMaxPowerRefRab(k) < basestation(k).txMinPowerPerLink))
            disp(['Warning - txMaxPowerRefRab is out of the min/max link power limits at '...
                  'base station ' num2str(k)]);
         end
         ebNoDLtemp = CalcMsEbNoDL(linkPerf(basestation(k).channel),... 
                                   wideAreaCovSpeed*ones([1, numMSs]), [mobilestation.RDL]);
         tempPowerLinMax = log2lin(txMaxPowerRefRab(k))/wideAreaCovR/log2lin(basestation(k).wideAreaCovEbNoDL)...
                           *[mobilestation.RDL].*log2lin(ebNoDLtemp);
         tempPowerLinMax = min(tempPowerLinMax, log2lin(basestation(k).txMaxPowerPerLink));
         
         minPowerMatrix(k, :) = log2lin([basestation(k).txMinPowerPerLink]'*ones([1, numMSs]));
			maxPowerMatrix(k, :) = tempPowerLinMax;			                  
      end
   end
   
   tooHighPowerInd = bsTxPowerLin > maxPowerMatrix;
   bsTxPowerLin(tooHighPowerInd) = 1e-28;
   outageDL(tooHighPowerInd) = outageDL(tooHighPowerInd)+1;
   outCountExceedInd = (outageDL >= limitOutageDL);
   bsTxPowerLin(outCountExceedInd) = 0;
   outageDL(outCountExceedInd) = 0;
   tmpPerm = eye(numBSs);
   bestServIndMat = tmpPerm(:, bestServDLV);
   bestServOutInd = outCountExceedInd & bestServIndMat;
   msTempOutageInd = sum(bestServOutInd,1) > 0;
   
   if mode == 1
      msIFHOcountNotExceededInd = (ifhoCounter < limitIFHO);
      msChangeCarrierInd = find(msTempOutageInd & msIFHOcountNotExceededInd);
      if length(msChangeCarrierInd) >= 1
         tmpVect = [mobilestation(msChangeCarrierInd).usedCarr];
         tmpVect = 1+mod(tmpVect,2);
         tmpVect = num2cell(tmpVect);
         [mobilestation(msChangeCarrierInd).usedCarr] = deal(tmpVect{:});
         msIndGeneric = msChangeCarrierInd;
         DoIFHO;
      end
      msOutageInd = find(msTempOutageInd & ~msIFHOcountNotExceededInd);
   else
      msOutageInd = find(msTempOutageInd);
   end
	if length(msOutageInd) >= 1
      [mobilestation(msOutageInd).usedCarr] = deal(-3);
      msIndSaattohoito = msOutageInd;
      DoSaattohoito;
   end
end

switch reducePowerSwitch    
case 1, 
   %this used to be the link power limitation but this is now separate
   disp('you are using wrongly reducePowerSwitch = 1')
case {2, 3, 4}
   %2 = reduce method2     - if power is too big set randomly power of mobiles to a small 
   %                         value until total power is small enough andafter limitOutageDL
   %                         times take the MSs complete out
   %3 = reduce method3high - if total power is too big set powers of mobiles with highest
   %                         powers to a small value until total power is small enough and
   %                         after limitOutageDL times take the MSs complete out
   %4 = reduce method3low  - if total power is too big set powers of mobiles with lowest
   %                         powers to a small value until total power is small enough and
   %                         after limitOutageDL times take the MSs complete out
   
   msTempOutageInd = zeros([1,numMSs]);
   for k = 1:numBSs
      maxPower = log2lin(basestation(k).txMaxPower)-log2lin(basestation(k).CPICHPower)-log2lin(basestation(k).commonChannelOther);
      if (sum(bsTxPowerLin(k, :)) > maxPower)
         
         ind1 = find(bsTxPowerLin(k, :) ~= 0);        % find all connections
         
         if reducePowerSwitch == 2
            ind2 = ind1(randperm(length(ind1))); % order connections arbitrary
         elseif reducePowerSwitch == 3
            [dummy ind2] = sort(bsTxPowerLin(k, ind1)); % sort connections in increasing powers
            ind2 = (ind1(ind2));       % take high-power users out - extrem overestimate of capa
         else %reducePowerSwitch == 4
            [dummy ind2] = sort(bsTxPowerLin(k, ind1)); % sort connections in increasing powers
            ind2 = fliplr(ind1(ind2)); % take low-power users out - extrem underestimate  of capa
         end
         
         %%set number of connections to be taken out, example 5% or 
         %%(1-(basestation(k).txMaxPower-CCHpowers)/bsTxPowerTotal)*100%, which ever is bigger
        
         numOut = min(ceil(0.95*length(ind2)), ceil(maxPower/sum(bsTxPowerLin(k, :))*length(ind2)));
         %%take desired number of connections out immediately
         indOut = ind2(numOut:end);
         bsTxPowerLin(k,indOut) = 0;
         outageDL(k,indOut) = 0;
         tmpBestServInd = find(bestServDLV(indOut)==k);
         msTempOutageInd(indOut(tmpBestServInd)) = 1;  
      end
   end
   
   if mode == 1
      msIFHOcountNotExceededInd = (ifhoCounter < limitIFHO);
      msChangeCarrierInd = find(msTempOutageInd & msIFHOcountNotExceededInd);
      if length(msChangeCarrierInd) >= 1
         tmpVect = [mobilestation(msChangeCarrierInd).usedCarr];
         tmpVect = 1+mod(tmpVect, 2);
         tmpVect = num2cell(tmpVect);
         [mobilestation(msChangeCarrierInd).usedCarr] = deal(tmpVect{:});
         msIndGeneric = msChangeCarrierInd;
         DoIFHO;
      end
      msOutageInd = find(msTempOutageInd & ~msIFHOcountNotExceededInd);
   else
      msOutageInd = find(msTempOutageInd);
   end
	if length(msOutageInd) >= 1
      [mobilestation(msOutageInd).usedCarr] = deal(-4);
      msIndSaattohoito = msOutageInd;
      DoSaattohoito;
   end
      
otherwise
   error('Error in reduceLoadSwich - check npswini.m')
end

bsTxPowerLin(bsTxPowerLin>0 & (ones([numBSs, 1])*sum(bsTxPowerLin==1e-28, 1)>0)) = 1e-28;

if (limitDLPowerSwitch)
   tmpind7 = find(bsTxPowerLin(:)>1e-28 & bsTxPowerLin(:)<minPowerMatrix(:));  
   if (length(tmpind7) >= 1)
      bsTxPowerLin(tmpind7) = minPowerMatrix(tmpind7);
   end
end

indMStype1 = find([mobilestation.usedCarr] == 1);
indMStype2 = find([mobilestation.usedCarr] == 2);
numMStype1 = length(indMStype1);
numMStype2 = length(indMStype2);
