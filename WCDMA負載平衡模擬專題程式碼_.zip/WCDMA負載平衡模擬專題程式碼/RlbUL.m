%RLBUL   RLBUL calculates the radio link budget for CDMA uplink, based rather much on the excel                       
%        calculates coverage threshold [dBm] (covth)
%
%Inputs:
%Outputs:
%
%Authors: Achim Wacker (AWa), Jaana Laiho-Steffens (jls),Kari Sipil� (KSi),
%         Kari Heiska (KHe)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files:   CalcSiteLinks.m, lin2log.m, log2lin.m, ReduceLinks.m, ReduceLoad.m

BS_noise_power_lin = log2lin(Thermal_noise_density+BS_noise_figure)*W;
BS_noise_power = lin2log(BS_noise_power_lin);

%IothUL and IownUL includes already the voice activity.
Ueta    = (IothUL+IownUL+IothOpUL)./(IothUL+IownUL+IothOpUL+BS_noise_power_lin);
UetaOwn = (IothUL+IownUL)./(IothUL+IownUL+BS_noise_power_lin);

if (any(Ueta > [basestation.excessLoadTotal]) | any(UetaOwn > [basestation.excessLoadOwn]))
   %The order here is important, because in the end of ReduceLoad
   %loadJustReduced is put back to zero if load could not be reduced.
   loadJustReduced = 1;   
   ReduceLoad;
else
   loadJustReduced = 0;
end
   
if hardBlocking == 1
   CalcSiteLinks;
   if sum(hardBlockCells) > 0
      ReduceLinks;
   end
end

%uplink sensitivity basestation by basestation
temp = W/(vUL*log2lin(wideAreaCovEbNo)*wideAreaCovR);
Required_BS_SNR = lin2log(1./(vUL*(1+temp)*(1-Ueta)));
Required_signal_power = BS_noise_power+Required_BS_SNR;

temp = num2cell(Required_signal_power);
[perf.covth] = deal(temp{:});

%clean up
clear temp
