%CALCMSSHOGAINSDL   CalcMsSHOGainsDL calculates the SHO gains in Eb/No:s which has the average  
%                   transmit power raise added. The calculation is done as a function of the
%                   CPICH Ec received level difference at MS, of the best and the second best 
%                   link in the active set.
%
%Inputs:
%   rxLevels1             : received CPICH levels from the BS in the active set
%   mobilestation         : the mobile station data structure
%   bsTxPowerLin          : bs transmit power of the active links 
%	linkPerf    		  : link performance tables for different channels
%	channelMap            : yPixels x xPixels matrix telling the index of channel of each pixel
%   channels              : vector of channel indeces used in the scenario
%   numChannels           : number of channels used in the scenario
%
%Outputs:
%   msShoGainsDL          : DL soft handover gains for the MS:s
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcSHOGain.m

[m1,n1] = size(rxLevels1);
tmpRxLevels = rxLevels1;

% Other ones are in outage;
tmpIndM = bsTxPowerLin > 0;

% Set a small RX level for non existing links.
tmpRxLevels(~tmpIndM)=-999;

%Calculate the best link's rxlevel.
[tmpMaxRxLevels,tmpMaxRxIndeces] = max(tmpRxLevels,[],1);

%Set the best link to small value.
tmpPerm = eye(m1);
tmpRxLevels = tmpRxLevels+tmpPerm(:, tmpMaxRxIndeces).*(-999-tmpRxLevels);

% Calculate the second best link's rxlevel
tmp2MaxRxLevels = max(tmpRxLevels,[],1);

% Set the best link of those who doesn't have the second best link to high value.
tmpMaxRxLevels(tmp2MaxRxLevels==-999) = 1000;

% Delta should be almost y2k for those who don't have at least two link in active set.
tmpDeltaRxLevels = abs(tmpMaxRxLevels-tmp2MaxRxLevels);

% Calculate the SHO gains for the MS depending on the channel.
msSHOGainsDL = zeros(size([mobilestation.speed]));
for i1 = 1:numChannels
   ind1 = find([mobilestation.channel]==channels(i1));
   if (length(ind1) >= 1)
      msSHOGainsDL(ind1) = ...
      	CalcShoGain([mobilestation(ind1).speed], tmpDeltaRxLevels(ind1), linkPerf(channels(i1)), 4);
   end
end

clear tmpRxLevels tmpIndM tmpMaxRxLevels tmpMaxRxIndeces tmpPerm tmp2MaxRxLevels tmpDeltaRxLevels
