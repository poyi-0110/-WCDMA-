%LOG2LIN   conversion from logarithmic to linear scale
%
%Revision: 5.0.0web   Date: 17-Jul-2005

function linout = log2lin(login)

linout = 10.^(login/10);
