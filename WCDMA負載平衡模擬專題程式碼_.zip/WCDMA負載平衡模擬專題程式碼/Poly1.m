%POLY1   POLY1 Draw a polygon in a figure interactively.
%        POLY1(FIG) draws a line segment by clicking the mouse at the
%        polygon points of the line segment in the figure FIG.
%        A rubberband line tracks the mouse movement. 
%        Right mouse button click closes the polygon.
%        H = POLY1(FIG) Returns the handle to the line.
%        POLYGON with no input arguments draws in the current figure.
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%called from within polygon.m

function poly = Poly1(fig);

if nargin < 1, 
  draw_fig = gcf;
  fig = draw_fig;
  s = 'start'; 
end

if isstr(fig), 
   s = fig;
   draw_fig = findobj(0, 'Tag', 'drawfig');
   ud = get(draw_fig, 'UserData');
   gcacolor = get(gca, 'Color');
else
   s = 'start';
   draw_fig = fig;
   ud.currentPoint = 1;
end

switch s
case 'start'
   oldtag = get(draw_fig, 'Tag');
   cData = NaN*ones(16, 16);
   cData(8, 1:15) = 2;
   cData(1:15, 8) = 2;
   set(draw_fig, ...
      'Tag', 'drawfig', ...
      'Pointer', 'custom', ...
      'PointerShapeCData', cData, ...
      'PointerShapeHotSpot', [7 7]),
   figure(draw_fig);
   ax = gca;
   if any(get(ax, 'view') ~= [0 90]), 
     error('POLYGON works only for 2-D plots.');
   end
   
   % Create an invisible line to preallocate the xor line color.
   xlimits = get(ax, 'Xlim');
   x = (xlimits + flipud(xlimits))./2;
   ylimits = get(ax, 'Ylim');
   y = (ylimits + flipud(ylimits))./2;
   hline = line(x, y, 'Visible', 'off', 'eraseMode', 'xor');

   bdown = get(draw_fig, 'WindowButtonDownFcn');
   bup = get(draw_fig, 'WindowButtonUpFcn');
   bmotion = get(draw_fig, 'WindowButtonMotionFcn');
   oldud = get(draw_fig, 'UserData');
   set(draw_fig, ...
      'WindowButtonDownFcn', 'Poly1(''down'');')
   set(draw_fig, ...
      'WindowButtonMotionFcn', 'Poly1(''motion'');')
   set(draw_fig, ...
      'WindowButtonupFcn', '')
 
   ud.hline(1) = hline;
   ud.pts = [];
   ud.buttonfcn = {bdown; bup; bmotion};
   ud.oldud = oldud;
   ud.oldtag = oldtag;
   set(draw_fig, ...
      'UserData', ud);
   
   uiwait(draw_fig);
   
case 'motion'
   if isempty(ud.pts);
      return;
   end
   
   set(ud.hline(ud.currentPoint), ...
      'Xdata', ud.pts(:, 1), ...
      'Ydata', ud.pts(:, 2), ...
      'eraseMode', 'xor', ...
      'linestyle', '-', ...
      'linewidth', 1, ...
      'Color', 1-gcacolor, ...
      'Visible', 'on');
   
   Pt2 = get(gca, 'CurrentPoint');
   Pt2 = Pt2(1, 1:2);
   ud.pts(2, :) = Pt2;
   
   set(draw_fig, ...
      'UserData', ud);
   return

case 'down'   %start polygon
   Pt1 = get(gca, 'CurrentPoint');
   ud.polygon(1, :) = Pt1(1, 1:2);
   ud.pts = [Pt1(1, 1:2); Pt1(1, 1:2)];
   set(ud.hline(1), ...
      'Xdata', ud.pts(:, 1), ...
      'Ydata', ud.pts(:, 2), ...
      'eraseMode', 'xor', ...
      'linestyle', '-', ...
      'linewidth', 1.5, ...
      'Color', 1-gcacolor, ...
      'Visible', 'on');
   
   set(draw_fig, ...
      'WindowButtonDownFcn', 'Poly1(''down2'');', ...
      'UserData', ud)
   
case 'down2'
   buttontype = get(draw_fig, 'SelectionType');
   if strcmp(buttontype, 'normal')   %finish one segment and start a new one
      Pt2 = get(gca, 'CurrentPoint');
      Pt2 = Pt2(1, 1:2);
      ud.pts(2, :) = Pt2;
      
      set(ud.hline(ud.currentPoint), ...
         'Xdata', ud.pts(:, 1), ...
         'Ydata', ud.pts(:, 2), ...
         'eraseMode', 'normal', ...
         'linestyle', '-', ...
         'linewidth', 2.5, ...
         'Color', 'w');%1-gcacolor);
      
      ud.currentPoint = ud.currentPoint+1;
      
      Pt1 = Pt2;
      ud.pts(1, :) = Pt1;
      x = (ud.pts(:, 1)+ flipud(ud.pts(:, 2)))/2;
      y = (ud.pts(:, 2)+ flipud(ud.pts(:, 2)))/2;
      ud.hline(ud.currentPoint) = line(x, y, 'Visible', 'on', 'eraseMode', 'xor');
      set(ud.hline(ud.currentPoint), ...
         'Xdata', ud.pts(:, 1), ...
         'Ydata', ud.pts(:, 2), ...
         'eraseMode', 'xor', ...
         'linestyle', '-', ...
         'linewidth', 1.5, ...
         'Color', 1-gcacolor);
      
      ud.polygon(ud.currentPoint, :) = Pt2;
      
      set(draw_fig, ...
         'UserData', ud);
     
   else   %close polygon and return data
      Pt2 = ud.polygon(1, :);
      ud.pts(2, 1:2) = Pt2;
      
      set(ud.hline(ud.currentPoint), ...
         'Xdata', ud.pts(:, 1), ...
         'Ydata', ud.pts(:, 2), ...
         'eraseMode', 'normal', ...
         'linestyle', '-', ...
         'linewidth', 2.0, ...
         'Color', 'w');%1-gcacolor);
      
      ud.currentPoint = ud.currentPoint + 1;
      bfcns = ud.buttonfcn;
      set(draw_fig, ...
         'windowbuttondownfcn', bfcns{1}, ...
         'windowbuttonupfcn', bfcns{2}, ...
         'windowbuttonmotionfcn', bfcns{3}, ...
         'Pointer', 'arrow', ...
         'Tag', ud.oldtag, ...
         'UserData', ud.oldud);
      
      ud.polygon(ud.currentPoint, :) = Pt2;
      set(draw_fig, ...
         'UserData', ud);
      
      uiresume
   end
otherwise
   error('Invalid call-back.');
end
