%POLYGONGAME   POLYGONGAME loads the previous used polygon from disk or gives the user possibility 
%              to draw an own one. This is needed in several display functions of npsw.
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: inpolygon.m, Polygon.m

function [plgn, totA, inplgn] = PolygonGame(xx, yy, xPixels, yPixels, questionText)

if nargin == 4
   questionText = 1;
end

switch questionText
case 1
   answer = questdlg(['Use previous polygon ? In case of "No": Select the polygon with left mouse button '...
                      'clicks. Right mouse button click closes the polygon. '], 'Polygon selection', 'Yes', 'No', 'Yes');
case 2
   answer = questdlg('Use same polygon for Operator 2 ?', 'Polygon selection', 'Yes', 'No', 'Yes');
case 3
   answer = questdlg('Use same polygon for Carrier 2 ?', 'Polygon selection', 'Yes', 'No', 'Yes');
otherwise
   error('Wrong questionText flag in PolygonGame.m');
end

previousPolygonFlag = strcmp(answer, 'Yes');

if (previousPolygonFlag)
   if exist('previousPolygon.mat')
      load previousPolygon.mat;
      hold on;
      plot(plgn(:, 1), plgn(:, 2), 'w', 'LineWidth', 2);
      
      if exist('inplgn') & exist('totA')
         if size(inplgn) ~= [yPixels xPixels]
            inplgn = inpolygon(xx, yy, plgn(:, 1), plgn(:, 2));
            totA = sum(sum(inplgn));
            save previousPolygon.mat plgn inplgn totA;
         end
      else
         inplgn = inpolygon(xx, yy, plgn(:, 1), plgn(:, 2));
         totA = sum(sum(inplgn));
         save previousPolygon.mat plgn inplgn totA;
      end
      hold off;
   else
      disp('previousPolygon.mat does not exist');
      disp('Select the polygon with left mouse button clicks. Right mouse button click closes the polygon.');
      plgn = Polygon;
      plgnX = plgn(:, 1);
      plgnY = plgn(:, 2);
      inplgn = inpolygon(xx, yy, plgnX, plgnY);
      totA = sum(sum(inplgn));
      save previousPolygon.mat plgn inplgn totA;
   end
   
else
   disp('Select the polygon with left mouse button clicks. Right mouse button click closes the polygon.');
   plgn = Polygon;
   plgnX = plgn(:, 1);
   plgnY = plgn(:, 2);
   inplgn = inpolygon(xx, yy, plgnX, plgnY);
   totA = sum(sum(inplgn));
   save previousPolygon.mat plgn inplgn totA;
end
