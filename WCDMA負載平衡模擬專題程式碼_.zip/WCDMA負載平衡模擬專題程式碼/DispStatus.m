%DISPSTATUS   DISPSTATUS(STRING) displays the status 'STRING' in the status window
%
%Inputs:
%Outputs:
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: none

function teststatus(string)
if (nargin == 1)
   hText1 = findobj(allchild(0), 'Tag', 'tagStatusText1');
   [len dummy] = size(string);
   string1 = string(1,:);
   for kk = 2:len
      string1 = str2mat(string1, ' ', string(kk, :));
   end
   string = textwrap(hText1, cellstr(string1));
   set(hText1, 'String', string);
end
drawnow
