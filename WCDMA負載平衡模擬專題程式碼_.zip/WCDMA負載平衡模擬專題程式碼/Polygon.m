%POLYGON   Draw a polygon in a figure interactively.
%          POLYGON(FIG) draws a line segment by clicking the mouse at the
%          polygon points of the line segment in the figure FIG.
%          A rubberband line tracks the mouse movement. 
%          Right mouse button click closes the polygon.
%          H = POLYGON(FIG) Returns the handle to the line.
%          POLYGON with no input arguments draws in the current figure.
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: Poly1.m

function poly = Polygon(fig)

if nargin < 1
   fig = gcf;
end

Poly1(fig);

poly_tmp = get(gcf, 'UserData');
poly = poly_tmp.polygon;
