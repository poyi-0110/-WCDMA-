%DOIFHO   DOIFHO recalulates several quantities after mobiles in msIndGeneric have
%         changed the carrier
%
%Authors: Kari Sipil� (KSi), Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: CalcSHO2.m, UpdateChannelMatrices.m

CalcSHO2;

bsTxPowerLin(:, msIndGeneric) = 1e-28*activeSetM(:, msIndGeneric);
bsTxPower(:, msIndGeneric)    = 10*log10(1e-28)*activeSetM(:, msIndGeneric);
outageDL(:, msIndGeneric)     = 0;
outageCPICH(:, msIndGeneric)  = 0;

UpdateChannelMatrices;

targetCI(msIndGeneric) = [mobilestation(msIndGeneric).EbNoDL]+lin2log([mobilestation(msIndGeneric).RDL]/W);
ifhoCounter(msIndGeneric) = ifhoCounter(msIndGeneric)+1;
