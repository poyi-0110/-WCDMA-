%DISTTRAF   MOBILESTATION = DISTTRAF(NUM, AREA, CARRIER) creates NUM equally distributed users
%           in AREA, using CARRIER
%
%Inputs:
%   NUM          : amount of mobilest to be distributed
%   AREA         : (square) area dimensions
%   CARRIER      : the carrier to be used
%Outputs:
%   MOBILESTATION: structure holding the MSs data
%
%Author : Achim Wacker (AWa)
%
%Revision: 5.0.0web   Date: 17-Jul-2005
%
%needed m-files: npswini.m

function ms = DistTraf(num, area1, carrier);
                                                
npswini;
xmin = area1(1);
xmax = area1(2);
ymin = area1(3);
ymax = area1(4);
xRand = num2cell(xmin+(xmax-xmin)*rand(num, 1));
yRand = num2cell(ymin+(ymax-ymin)*rand(num, 1));

[ms(1:num).x] = deal(xRand{:});
[ms(1:num).y] = deal(yRand{:});
[ms(1:num).groundHeight] = deal(0);
[ms(1:num).antennaHeight] = deal(1.5);
[ms(1:num).maxTxPower] = deal(21);
[ms(1:num).minTxPower] = deal(-50);
[ms(1:num).antennaGain] = deal(mobilestationAntennaGain);
[ms(1:num).bodyLoss] = deal(mobilestationBodyLoss);

[ms(1:num).RUL] = deal(wideAreaCovR);
[ms(1:num).RDL] = deal(wideAreaCovR);

[ms(1:num).usedCarr] = deal(carrier);
[ms(1:num).speed] = deal(5);
